import React, { useEffect, useState } from 'react';
import {
  Plus,
  Search,
  Filter,
  ArrowRight,
  LayoutGrid,
  List,
  Target,
  Clock,
  Layers,
  Trash2,
} from 'lucide-react';
import type { Campaign, CampaignGoal, CampaignStatus } from '../types.js';
import { api } from '../services/api.js';
import { useToast } from '../components/Toast.js';

interface CampaignsListPageProps {
  onNavigate: (path: string) => void;
  onOpenCampaign: (id: string) => void;
}

export function CampaignsListPage({ onNavigate, onOpenCampaign }: CampaignsListPageProps) {
  const { showToast } = useToast();
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [goalFilter, setGoalFilter] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [sortBy, setSortBy] = useState<'updated' | 'created' | 'progress'>('updated');

  const loadData = async () => {
    try {
      const data = await api.getCampaigns();
      setCampaigns(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleDelete = async (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if (!confirm('Are you sure you want to delete this campaign?')) return;
    try {
      await api.deleteCampaign(id);
      showToast('Campaign deleted successfully', 'success');
      loadData();
    } catch (err) {
      showToast('Failed to delete campaign', 'error');
    }
  };

  const filteredCampaigns = campaigns
    .filter((c) => {
      const matchSearch =
        c.name.toLowerCase().includes(search.toLowerCase()) ||
        c.businessName.toLowerCase().includes(search.toLowerCase()) ||
        c.productName.toLowerCase().includes(search.toLowerCase());
      const matchStatus = statusFilter === 'all' || c.status === statusFilter;
      const matchGoal = goalFilter === 'all' || c.goal === goalFilter;
      return matchSearch && matchStatus && matchGoal;
    })
    .sort((a, b) => {
      if (sortBy === 'progress') return b.progressPercentage - a.progressPercentage;
      if (sortBy === 'created') return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
    });

  const getStatusBadge = (status: CampaignStatus) => {
    switch (status) {
      case 'in_progress':
        return <span className="text-[11px] font-semibold text-emerald-700">In Progress</span>;
      case 'planning':
        return <span className="text-[11px] font-semibold text-indigo-700">Planning</span>;
      case 'review':
        return <span className="text-[11px] font-semibold text-amber-700">Under Review</span>;
      case 'completed':
        return <span className="text-[11px] font-semibold text-slate-700">Completed</span>;
      case 'archived':
        return <span className="text-[11px] font-semibold text-slate-400">Archived</span>;
      default:
        return <span className="text-[11px] font-semibold text-slate-500">Draft</span>;
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Page Title & Action */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
            Marketing Campaigns
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Manage your AI-powered campaign strategies, tasks, and content assets.
          </p>
        </div>

        <button
          onClick={() => onNavigate('/campaigns/new')}
          className="inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs transition-colors cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Create Campaign</span>
        </button>
      </div>

      {/* Filter & Search Bar */}
      <div className="p-4 bg-white border border-slate-200 rounded-xl shadow-2xs space-y-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by campaign name, product, or business..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:outline-hidden focus:ring-1 focus:ring-indigo-500 text-slate-900"
            />
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {/* Status Filter */}
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              aria-label="Filter by status"
              className="px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
            >
              <option value="all">All Statuses</option>
              <option value="draft">Draft</option>
              <option value="planning">Planning</option>
              <option value="in_progress">In Progress</option>
              <option value="review">Review</option>
              <option value="completed">Completed</option>
              <option value="archived">Archived</option>
            </select>

            {/* Goal Filter */}
            <select
              value={goalFilter}
              onChange={(e) => setGoalFilter(e.target.value)}
              aria-label="Filter by marketing goal"
              className="px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
            >
              <option value="all">All Goals</option>
              <option value="Product Launch">Product Launch</option>
              <option value="Lead Generation">Lead Generation</option>
              <option value="Brand Awareness">Brand Awareness</option>
              <option value="Sales">Sales</option>
              <option value="Website Traffic">Website Traffic</option>
              <option value="Customer Retention">Customer Retention</option>
            </select>

            {/* Sort */}
            <select
              value={sortBy}
              onChange={(e: any) => setSortBy(e.target.value)}
              aria-label="Sort campaigns by"
              className="px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
            >
              <option value="updated">Recently Updated</option>
              <option value="created">Recently Created</option>
              <option value="progress">Highest Progress</option>
            </select>

            {/* View Mode Toggle */}
            <div className="flex items-center border border-slate-200 rounded-lg overflow-hidden bg-slate-50 p-0.5">
              <button
                onClick={() => setViewMode('grid')}
                className={`p-1 rounded ${viewMode === 'grid' ? 'bg-white text-indigo-600 shadow-2xs' : 'text-slate-400 hover:text-slate-700'}`}
                aria-label="Grid view"
              >
                <LayoutGrid className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-1 rounded ${viewMode === 'list' ? 'bg-white text-indigo-600 shadow-2xs' : 'text-slate-400 hover:text-slate-700'}`}
                aria-label="List view"
              >
                <List className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Campaigns Listing */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-48 bg-slate-100 rounded-xl animate-pulse" />
          ))}
        </div>
      ) : filteredCampaigns.length === 0 ? (
        <div className="text-center py-16 bg-white border border-slate-200 rounded-xl p-8">
          <Layers className="w-10 h-10 text-slate-300 mx-auto mb-3" />
          <h3 className="text-sm font-bold text-slate-900">No campaigns match your filters</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            Try adjusting your search criteria or create a fresh campaign strategy with our AI wizard.
          </p>
          <button
            onClick={() => onNavigate('/campaigns/new')}
            className="mt-4 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors cursor-pointer"
          >
            Create New Campaign
          </button>
        </div>
      ) : viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredCampaigns.map((camp) => (
            <div
              key={camp.id}
              onClick={() => onOpenCampaign(camp.id)}
              className="p-5 rounded-xl bg-white border border-slate-200 hover:border-indigo-300 hover:shadow-xs transition-all cursor-pointer flex flex-col justify-between text-left group"
            >
              <div>
                <div className="flex items-start justify-between gap-3 mb-2">
                  <span className="text-[11px] font-semibold text-indigo-700 bg-indigo-50/70 px-2 py-0.5 rounded">
                    {camp.goal}
                  </span>
                  <div className="flex items-center gap-1.5">
                    {getStatusBadge(camp.status)}
                    <button
                      onClick={(e) => handleDelete(e, camp.id)}
                      className="opacity-0 group-hover:opacity-100 p-1 text-slate-300 hover:text-rose-600 hover:bg-rose-50 rounded transition-all"
                      title="Delete Campaign"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <h3 className="text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                  {camp.name}
                </h3>
                <p className="text-xs text-slate-600 line-clamp-2 mt-1">
                  {camp.productDescription || camp.description}
                </p>

                <div className="mt-3 text-[11px] text-slate-500 space-y-1">
                  <div>Channel: <span className="font-semibold text-slate-700">{camp.primaryChannel}</span></div>
                  <div>Budget: <span className="font-semibold text-slate-700">{camp.budget}</span> · <span className="font-tabular">{camp.durationDays}d</span></div>
                </div>
              </div>

              <div className="mt-5 pt-3 border-t border-slate-100">
                <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1.5">
                  <span>Progress</span>
                  <span className="font-bold text-slate-800 font-tabular">{camp.progressPercentage}%</span>
                </div>
                <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-indigo-600 rounded-full"
                    style={{ width: `${camp.progressPercentage}%` }}
                  />
                </div>

                <div className="mt-3 flex items-center justify-between text-[10px] text-slate-400">
                  <span className="font-tabular">Updated {new Date(camp.updatedAt).toLocaleDateString()}</span>
                  <span className="font-semibold text-indigo-600 group-hover:translate-x-0.5 transition-transform flex items-center gap-1">
                    Open Workspace →
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* List View */
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-2xs divide-y divide-slate-100">
          {filteredCampaigns.map((camp) => (
            <div
              key={camp.id}
              onClick={() => onOpenCampaign(camp.id)}
              className="p-4 sm:p-5 hover:bg-slate-50/70 transition-colors cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-4"
            >
              <div className="space-y-1 flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-xs sm:text-sm font-bold text-slate-900 hover:text-indigo-600">
                    {camp.name}
                  </h3>
                  <span className="text-slate-300">·</span>
                  <span className="text-[11px] text-slate-600">{camp.goal}</span>
                  <span className="text-slate-300">·</span>
                  {getStatusBadge(camp.status)}
                </div>
                <p className="text-xs text-slate-500 line-clamp-1 max-w-xl">
                  {camp.productDescription || camp.description}
                </p>
              </div>

              <div className="flex items-center gap-6 text-xs text-slate-500 shrink-0">
                <div className="text-right">
                  <span className="font-bold text-slate-800 font-tabular">{camp.progressPercentage}%</span>
                  <div className="w-20 h-1 bg-slate-100 rounded-full overflow-hidden mt-1">
                    <div className="h-full bg-indigo-600" style={{ width: `${camp.progressPercentage}%` }} />
                  </div>
                </div>

                <div className="text-right text-[11px]">
                  <span className="block font-medium text-slate-700">{camp.primaryChannel}</span>
                  <span className="block text-slate-400 font-tabular">{new Date(camp.updatedAt).toLocaleDateString()}</span>
                </div>

                <button
                  onClick={() => onOpenCampaign(camp.id)}
                  className="px-3 py-1.5 text-xs font-semibold text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                >
                  Open →
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
