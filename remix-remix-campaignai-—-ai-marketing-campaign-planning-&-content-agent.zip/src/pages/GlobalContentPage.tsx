import React, { useEffect, useState } from 'react';
import { PenTool, Sparkles, CheckCircle2, BarChart2, ArrowRight } from 'lucide-react';
import type { CampaignContent, Campaign } from '../types.js';
import { api } from '../services/api.js';

interface GlobalContentPageProps {
  onOpenCampaign: (campaignId: string) => void;
  onNavigate: (path: string) => void;
}

export function GlobalContentPage({ onOpenCampaign, onNavigate }: GlobalContentPageProps) {
  const [contentList, setContentList] = useState<CampaignContent[]>([]);
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [loading, setLoading] = useState(true);
  const [categoryFilter, setCategoryFilter] = useState('all');

  useEffect(() => {
    async function loadData() {
      try {
        const [cList, campList] = await Promise.all([
          api.getContent(),
          api.getCampaigns(),
        ]);
        setContentList(cList);
        setCampaigns(campList);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, []);

  const getCampaignName = (campaignId: string) => {
    return campaigns.find((c) => c.id === campaignId)?.name || 'Active Campaign';
  };

  const filtered = contentList.filter((item) =>
    categoryFilter === 'all' ? true : item.category === categoryFilter
  );

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6 text-left">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
            Global Content Studio
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Omni-channel marketing copy drafts, evaluated and ready for multi-platform delivery.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-hidden"
          >
            <option value="all">All Content Types</option>
            <option value="social">Social Media (Reels, Posts)</option>
            <option value="marketing">Marketing (Emails, Ads, Landing)</option>
          </select>
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-44 bg-slate-100 rounded-xl animate-pulse" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="py-16 text-center bg-white border border-slate-200 rounded-xl">
          <PenTool className="w-8 h-8 text-slate-300 mx-auto mb-2" />
          <p className="text-xs text-slate-500">No content items generated yet.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filtered.map((item) => (
            <div
              key={item.id}
              onClick={() => onOpenCampaign(item.campaignId)}
              className="p-5 rounded-xl bg-white border border-slate-200 hover:border-indigo-300 hover:shadow-xs transition-all cursor-pointer flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <span className="text-[11px] font-bold text-indigo-700 bg-indigo-50/70 px-2 py-0.5 rounded">
                    {item.type}
                  </span>
                  <span
                    className={`text-[10px] font-semibold px-2 py-0.5 rounded ${
                      item.status === 'approved'
                        ? 'text-emerald-700 bg-emerald-100/60'
                        : 'text-amber-700 bg-amber-100/60'
                    }`}
                  >
                    {item.status === 'approved' ? 'Approved' : 'Pending Review'}
                  </span>
                </div>

                <h3 className="text-xs sm:text-sm font-bold text-slate-900 line-clamp-1">
                  {item.title}
                </h3>

                <p className="text-[11px] text-slate-500 font-medium mt-0.5">
                  Campaign: <strong className="text-slate-700">{getCampaignName(item.campaignId)}</strong>
                </p>

                <div className="mt-3 p-2.5 rounded-lg bg-slate-50 border border-slate-100 text-xs text-slate-700 line-clamp-3 leading-relaxed whitespace-pre-wrap font-sans">
                  {item.headline ? `Hook: ${item.headline}\n` : ''}
                  {item.body}
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                {item.evaluation ? (
                  <div className="flex items-center gap-1.5 text-emerald-700 font-semibold font-tabular text-[11px]">
                    <BarChart2 className="w-3.5 h-3.5" />
                    <span>Quality: {item.evaluation.overallScore}/100</span>
                  </div>
                ) : (
                  <span className="text-[11px] text-slate-400">Not evaluated</span>
                )}

                <span className="font-semibold text-indigo-600 flex items-center gap-1 text-[11px]">
                  Open in Workspace →
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
