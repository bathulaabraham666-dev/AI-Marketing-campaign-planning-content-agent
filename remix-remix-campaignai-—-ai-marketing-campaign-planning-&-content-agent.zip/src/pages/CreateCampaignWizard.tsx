import React, { useState } from 'react';
import {
  Sparkles,
  ArrowRight,
  ArrowLeft,
  Check,
  Building,
  Target,
  Users,
  Calendar,
  Volume2,
  CheckCircle2,
  Loader2,
} from 'lucide-react';
import type { CampaignGoal, BrandVoice, MarketingChannel, Campaign } from '../types.js';
import { api } from '../services/api.js';
import { useToast } from '../components/Toast.js';

interface CreateCampaignWizardProps {
  onCancel: () => void;
  onCampaignCreated: (campaignId: string) => void;
}

export function CreateCampaignWizard({ onCancel, onCampaignCreated }: CreateCampaignWizardProps) {
  const { showToast } = useToast();
  const [currentStep, setCurrentStep] = useState(1);
  const [generating, setGenerating] = useState(false);
  const [generationStep, setGenerationStep] = useState(0);

  // Form State
  const [businessName, setBusinessName] = useState('Zenith AI Workflows');
  const [website, setWebsite] = useState('https://zenithworkflow.com');
  const [industry, setIndustry] = useState('B2B SaaS / Enterprise Automation');
  const [productName, setProductName] = useState('Zenith Orchestrate');
  const [productDescription, setProductDescription] = useState('An intelligent autonomous operations platform that orchestrates enterprise engineering tickets, reviews, and cross-department handoffs.');
  const [valueProposition, setValueProposition] = useState('Cut engineering coordination overhead by 70% with intelligent autonomous issue triage.');

  const [goal, setGoal] = useState<CampaignGoal>('Lead Generation');
  const [primaryObjective, setPrimaryObjective] = useState('Generate 350+ enterprise demo requests from VP of Engineering and DevOps leads within 45 days.');

  const [audienceAgeRange, setAudienceAgeRange] = useState('28 - 50 years old');
  const [audienceLocation, setAudienceLocation] = useState('North America & Europe');
  const [audienceOccupation, setAudienceOccupation] = useState('VPs of Engineering, CTOs, Engineering Directors, DevOps Leads');
  const [audienceInterests, setAudienceInterests] = useState('Developer productivity, CI/CD pipelines, autonomous workflows, team velocity');
  const [audiencePainPoints, setAudiencePainPoints] = useState('Context switching between Jira, Slack, and GitHub; missed release dates due to manual approval bottlenecks');
  const [audienceBuyingBehavior, setAudienceBuyingBehavior] = useState('Requires technical validation, security SOC2 compliance, and measurable developer hour savings');
  const [audienceDescription, setAudienceDescription] = useState('Technical leaders managing engineering teams of 20-500 developers who are frustrated by coordination latency.');

  const [campaignName, setCampaignName] = useState('Q3 Enterprise Developer Velocity Sprint');
  const [durationDays, setDurationDays] = useState(45);
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState(new Date(Date.now() + 45 * 86400000).toISOString().split('T')[0]);
  const [budget, setBudget] = useState('$28,000');
  const [primaryChannel, setPrimaryChannel] = useState<MarketingChannel>('LinkedIn');
  const [secondaryChannels, setSecondaryChannels] = useState<MarketingChannel[]>(['Email', 'Website']);

  const [brandVoice, setBrandVoice] = useState<BrandVoice>('Professional');
  const [customBrandVoice, setCustomBrandVoice] = useState('Authoritative, data-backed, engineered for engineers, zero fluff');

  const goalsList: { label: CampaignGoal; desc: string }[] = [
    { label: 'Lead Generation', desc: 'Capture qualified demo requests and enterprise contacts.' },
    { label: 'Product Launch', desc: 'Maximize impact for a new feature, platform, or version.' },
    { label: 'Brand Awareness', desc: 'Establish strategic authority and mindshare in your category.' },
    { label: 'Sales', desc: 'Direct revenue conversion and time-sensitive purchase drives.' },
    { label: 'Website Traffic', desc: 'Funnel high-intent organic and referral visitors to your domain.' },
    { label: 'Customer Retention', desc: 'Deepen feature adoption, upgrades, and referral loops.' },
    { label: 'Engagement', desc: 'Spark community discussions, viral shares, and feedback.' },
    { label: 'Other', desc: 'Custom bespoke marketing objectives and experimental sprints.' },
  ];

  const channelsList: MarketingChannel[] = [
    'LinkedIn',
    'Email',
    'Instagram',
    'X',
    'YouTube',
    'Google Ads',
    'Blog',
    'Website',
    'Facebook',
  ];

  const brandVoicesList: { label: BrandVoice; desc: string }[] = [
    { label: 'Professional', desc: 'Credible, articulate, and enterprise-grade.' },
    { label: 'Bold', desc: 'High energy, provocative, category-challenging.' },
    { label: 'Friendly', desc: 'Warm, approachable, empathetic, and conversational.' },
    { label: 'Educational', desc: 'Insightful, pedagogical, structured, data-driven.' },
    { label: 'Luxury', desc: 'Sophisticated, understated, minimalist prestige.' },
    { label: 'Playful', desc: 'Witty, vibrant, modern, and punchy.' },
    { label: 'Minimal', desc: 'Hyper-concise, direct, high-signal, zero excess.' },
    { label: 'Custom', desc: 'Define your unique bespoke tone profile.' },
  ];

  const toggleSecondaryChannel = (ch: MarketingChannel) => {
    if (ch === primaryChannel) return;
    if (secondaryChannels.includes(ch)) {
      setSecondaryChannels(secondaryChannels.filter((c) => c !== ch));
    } else {
      setSecondaryChannels([...secondaryChannels, ch]);
    }
  };

  const handleLaunchWorkflow = async () => {
    setGenerating(true);
    setGenerationStep(0);

    const stepsText = [
      'Understanding business & value proposition...',
      'Analyzing target audience & psychographics...',
      'Synthesizing full-funnel marketing strategy...',
      'Decomposing strategic pillars into operational tasks...',
      'Preparing multi-channel publication content...',
      'Evaluating draft quality and conversion scores...',
    ];

    try {
      // 1. Create campaign in DB
      const newCamp = await api.createCampaign({
        userId: 'user_default',
        name: campaignName,
        description: `${productName} marketing activation for ${goal}`,
        businessName,
        website,
        industry,
        productName,
        productDescription,
        valueProposition,
        goal,
        primaryObjective,
        audienceAgeRange,
        audienceLocation,
        audienceOccupation,
        audienceInterests,
        audiencePainPoints,
        audienceBuyingBehavior,
        audienceDescription,
        budget,
        durationDays,
        startDate,
        endDate,
        primaryChannel,
        secondaryChannels,
        brandVoice,
        customBrandVoice,
        status: 'planning',
      });

      // Advance through generation animation steps
      for (let i = 0; i < stepsText.length; i++) {
        setGenerationStep(i);
        await new Promise((r) => setTimeout(r, 600));
      }

      // 2. Trigger the automated AI workflow run
      await api.runWorkflow(newCamp.id);

      showToast('Campaign successfully planned & initialized!', 'success');
      onCampaignCreated(newCamp.id);
    } catch (err: any) {
      console.error(err);
      showToast(err.message || 'Error creating campaign', 'error');
      setGenerating(false);
    }
  };

  // Generation Loading Screen
  if (generating) {
    const steps = [
      'Understanding business & value proposition',
      'Analyzing target audience & psychographics',
      'Synthesizing full-funnel marketing strategy',
      'Decomposing strategic pillars into operational tasks',
      'Preparing multi-channel publication content',
      'Evaluating draft quality and conversion scores',
    ];

    return (
      <div className="max-w-2xl mx-auto py-20 px-4 text-center space-y-8 animate-in fade-in duration-300">
        <div className="w-14 h-14 rounded-2xl bg-indigo-600 text-white flex items-center justify-center mx-auto shadow-lg shadow-indigo-200">
          <Sparkles className="w-7 h-7 animate-pulse" />
        </div>

        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
            Building Your Campaign Strategy...
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-md mx-auto">
            Our multi-agent system is researching your category, architecting the funnel, and decomposing tasks.
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs text-left max-w-md mx-auto space-y-3.5">
          {steps.map((step, idx) => {
            const isDone = generationStep > idx;
            const isCurrent = generationStep === idx;

            return (
              <div key={step} className="flex items-center gap-3 text-xs">
                {isDone ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                ) : isCurrent ? (
                  <Loader2 className="w-4 h-4 text-indigo-600 animate-spin shrink-0" />
                ) : (
                  <div className="w-4 h-4 rounded-full border border-slate-300 shrink-0" />
                )}
                <span
                  className={`${
                    isDone
                      ? 'text-slate-800 font-medium'
                      : isCurrent
                      ? 'text-indigo-600 font-bold'
                      : 'text-slate-400'
                  }`}
                >
                  {step}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-4xl mx-auto space-y-6">
      {/* Wizard Header & Progress */}
      <div className="flex items-center justify-between border-b border-slate-200 pb-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">
            Campaign Setup Wizard
          </span>
          <h2 className="text-lg font-bold text-slate-900">
            Step {currentStep} of 6:{' '}
            {currentStep === 1 && 'Business & Product Profile'}
            {currentStep === 2 && 'Marketing Goal & Objective'}
            {currentStep === 3 && 'Target Audience Profile'}
            {currentStep === 4 && 'Parameters & Channels'}
            {currentStep === 5 && 'Brand Voice & Tone'}
            {currentStep === 6 && 'Review & Generate'}
          </h2>
        </div>
        <button
          onClick={onCancel}
          className="text-xs font-medium text-slate-500 hover:text-slate-800"
        >
          Cancel
        </button>
      </div>

      {/* Stepper Dots */}
      <div className="grid grid-cols-6 gap-2">
        {[1, 2, 3, 4, 5, 6].map((step) => (
          <div
            key={step}
            className={`h-1.5 rounded-full transition-all ${
              step <= currentStep ? 'bg-indigo-600' : 'bg-slate-200'
            }`}
          />
        ))}
      </div>

      {/* STEP 1: BUSINESS */}
      {currentStep === 1 && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-2xs space-y-4 text-left">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Business / Company Name *
              </label>
              <input
                type="text"
                required
                value={businessName}
                onChange={(e) => setBusinessName(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
                placeholder="Zenith AI Workflows"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Website URL
              </label>
              <input
                type="text"
                value={website}
                onChange={(e) => setWebsite(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
                placeholder="https://zenithworkflow.com"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Industry / Category *
            </label>
            <input
              type="text"
              required
              value={industry}
              onChange={(e) => setIndustry(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
              placeholder="e.g. B2B SaaS, HealthTech, Sustainable Fashion"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Product / Service Name *
              </label>
              <input
                type="text"
                required
                value={productName}
                onChange={(e) => setProductName(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
                placeholder="Zenith Orchestrate"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Core Value Proposition *
              </label>
              <input
                type="text"
                required
                value={valueProposition}
                onChange={(e) => setValueProposition(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
                placeholder="What single outcome does your customer achieve?"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Product / Service Description *
            </label>
            <textarea
              rows={3}
              required
              value={productDescription}
              onChange={(e) => setProductDescription(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
              placeholder="Describe the product, core features, and problems it solves..."
            />
          </div>
        </div>
      )}

      {/* STEP 2: GOAL */}
      {currentStep === 2 && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-2xs space-y-5 text-left">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-2">
              Select Primary Campaign Goal *
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {goalsList.map((g) => (
                <div
                  key={g.label}
                  onClick={() => setGoal(g.label)}
                  className={`p-3.5 rounded-lg border text-left cursor-pointer transition-all ${
                    goal === g.label
                      ? 'border-indigo-600 bg-indigo-50/50 ring-1 ring-indigo-600'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-slate-900">{g.label}</span>
                    {goal === g.label && <Check className="w-3.5 h-3.5 text-indigo-600" />}
                  </div>
                  <p className="text-[11px] text-slate-500 line-clamp-2">{g.desc}</p>
                </div>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Specific Campaign Objective *
            </label>
            <input
              type="text"
              required
              value={primaryObjective}
              onChange={(e) => setPrimaryObjective(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
              placeholder="e.g. Generate 300 demo signups at sub-$20 CAC"
            />
            <p className="text-[11px] text-slate-400 mt-1">
              The clearer your quantifiable target, the more precise the AI KPI model will be.
            </p>
          </div>
        </div>
      )}

      {/* STEP 3: TARGET AUDIENCE */}
      {currentStep === 3 && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-2xs space-y-4 text-left">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Age Range
              </label>
              <input
                type="text"
                value={audienceAgeRange}
                onChange={(e) => setAudienceAgeRange(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
                placeholder="25 - 45"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Geographic Location
              </label>
              <input
                type="text"
                value={audienceLocation}
                onChange={(e) => setAudienceLocation(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
                placeholder="North America, Global, etc."
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Target Role / Occupation *
              </label>
              <input
                type="text"
                required
                value={audienceOccupation}
                onChange={(e) => setAudienceOccupation(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
                placeholder="VPs of Engineering, Product Managers, Founders"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Interests & Triggers
              </label>
              <input
                type="text"
                value={audienceInterests}
                onChange={(e) => setAudienceInterests(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
                placeholder="Developer velocity, automation, AI tooling"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Audience Pain Points & Frustrations *
            </label>
            <input
              type="text"
              required
              value={audiencePainPoints}
              onChange={(e) => setAudiencePainPoints(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
              placeholder="What keeps them up at night? What breaks their workflow?"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Audience Persona Narrative *
            </label>
            <textarea
              rows={2}
              required
              value={audienceDescription}
              onChange={(e) => setAudienceDescription(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
              placeholder="Synthesize who this customer is in 1-2 sentences..."
            />
          </div>
        </div>
      )}

      {/* STEP 4: CAMPAIGN PARAMETERS */}
      {currentStep === 4 && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-2xs space-y-5 text-left">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Campaign Name *
              </label>
              <input
                type="text"
                required
                value={campaignName}
                onChange={(e) => setCampaignName(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
                placeholder="e.g. Q3 Velocity Activation"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Allocated Budget
              </label>
              <input
                type="text"
                value={budget}
                onChange={(e) => setBudget(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
                placeholder="$25,000"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Duration (Days)
              </label>
              <input
                type="number"
                min={7}
                max={365}
                value={durationDays}
                onChange={(e) => setDurationDays(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Start Date
              </label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                End Date
              </label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-2">
              Primary Channel *
            </label>
            <div className="flex flex-wrap gap-2">
              {channelsList.map((ch) => (
                <button
                  key={ch}
                  type="button"
                  onClick={() => {
                    setPrimaryChannel(ch);
                    setSecondaryChannels(secondaryChannels.filter((c) => c !== ch));
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                    primaryChannel === ch
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {ch}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-2">
              Secondary Distribution Channels
            </label>
            <div className="flex flex-wrap gap-2">
              {channelsList
                .filter((ch) => ch !== primaryChannel)
                .map((ch) => (
                  <button
                    key={ch}
                    type="button"
                    onClick={() => toggleSecondaryChannel(ch)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                      secondaryChannels.includes(ch)
                        ? 'bg-indigo-100 text-indigo-800 border border-indigo-300 font-semibold'
                        : 'bg-slate-50 text-slate-600 border border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {secondaryChannels.includes(ch) ? `✓ ${ch}` : `+ ${ch}`}
                  </button>
                ))}
            </div>
          </div>
        </div>
      )}

      {/* STEP 5: BRAND VOICE */}
      {currentStep === 5 && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-2xs space-y-5 text-left">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-2">
              Select Dominant Brand Tone *
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {brandVoicesList.map((bv) => (
                <div
                  key={bv.label}
                  onClick={() => setBrandVoice(bv.label)}
                  className={`p-3.5 rounded-lg border text-left cursor-pointer transition-all ${
                    brandVoice === bv.label
                      ? 'border-indigo-600 bg-indigo-50/50 ring-1 ring-indigo-600'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-slate-900">{bv.label}</span>
                    {brandVoice === bv.label && <Check className="w-3.5 h-3.5 text-indigo-600" />}
                  </div>
                  <p className="text-[11px] text-slate-500">{bv.desc}</p>
                </div>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Custom Brand Voice & Editorial Guidance
            </label>
            <input
              type="text"
              value={customBrandVoice}
              onChange={(e) => setCustomBrandVoice(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
              placeholder="e.g. Authoritative, direct, avoids generic hype words like 'synergy' or 'game-changer'"
            />
          </div>
        </div>
      )}

      {/* STEP 6: REVIEW */}
      {currentStep === 6 && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-2xs space-y-6 text-left">
          <div className="border-b border-slate-100 pb-4">
            <span className="text-xs font-bold text-emerald-700 uppercase tracking-wider block mb-1">
              ✓ Ready for Synthesis
            </span>
            <h3 className="text-base font-extrabold text-slate-900">
              {campaignName}
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Review your inputs before launching the autonomous strategy and task engine.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-100 space-y-1.5">
              <span className="font-bold text-slate-700 block">Product & Proposition</span>
              <div>Product: <strong>{productName}</strong> ({businessName})</div>
              <div>Industry: {industry}</div>
              <div>Value Prop: <em>"{valueProposition}"</em></div>
            </div>

            <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-100 space-y-1.5">
              <span className="font-bold text-slate-700 block">Campaign Scope</span>
              <div>Goal: <strong>{goal}</strong></div>
              <div>Primary Objective: {primaryObjective}</div>
              <div>Budget: {budget} · {durationDays} days</div>
            </div>

            <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-100 space-y-1.5">
              <span className="font-bold text-slate-700 block">Audience Persona</span>
              <div>Role: <strong>{audienceOccupation}</strong></div>
              <div>Pain: {audiencePainPoints}</div>
              <div>Location: {audienceLocation}</div>
            </div>

            <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-100 space-y-1.5">
              <span className="font-bold text-slate-700 block">Distribution & Voice</span>
              <div>Primary Channel: <strong>{primaryChannel}</strong></div>
              <div>Secondary: {secondaryChannels.join(', ') || 'None'}</div>
              <div>Voice: {brandVoice} ({customBrandVoice})</div>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-indigo-50/70 border border-indigo-100 flex items-start gap-3">
            <Sparkles className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
            <div className="text-xs text-indigo-900">
              <span className="font-bold block">Autonomous Generation Ready</span>
              <span>
                Clicking the button below will immediately launch our multi-agent workflow to construct your funnel, populate initial Kanban tasks, draft your launch copy, and calculate quality metrics.
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Wizard Footer Controls */}
      <div className="flex items-center justify-between pt-2">
        <button
          onClick={() => setCurrentStep((prev) => Math.max(1, prev - 1))}
          disabled={currentStep === 1}
          className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 disabled:opacity-30 disabled:hover:text-slate-600 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Previous Step</span>
        </button>

        {currentStep < 6 ? (
          <button
            onClick={() => setCurrentStep((prev) => Math.min(6, prev + 1))}
            className="flex items-center gap-1.5 px-5 py-2.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs transition-colors cursor-pointer"
          >
            <span>Next Step</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        ) : (
          <button
            onClick={handleLaunchWorkflow}
            className="flex items-center gap-2 px-6 py-2.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm transition-all cursor-pointer"
          >
            <Sparkles className="w-4 h-4" />
            <span>Generate Campaign Strategy</span>
          </button>
        )}
      </div>
    </div>
  );
}
