import React, { useState } from 'react';
import {
  Sparkles,
  ArrowRight,
  CheckCircle2,
  Layers,
  ListTodo,
  PenTool,
  BarChart2,
  Brain,
  Workflow,
  ChevronDown,
  Shield,
  Zap,
} from 'lucide-react';

interface LandingPageProps {
  onNavigate: (path: string) => void;
}

export function LandingPage({ onNavigate }: LandingPageProps) {
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const workflowSteps = [
    { num: '01', name: 'Business Goal', desc: 'Define target objective & audience' },
    { num: '02', name: 'AI Research', desc: 'Market & competitor landscape audit' },
    { num: '03', name: 'Strategy', desc: 'Full-funnel positioning & pillars' },
    { num: '04', name: 'Task Board', desc: 'Decomposed operational Kanban' },
    { num: '05', name: 'Content Studio', desc: 'Multi-channel publication copy' },
    { num: '06', name: 'Evaluation', desc: '6-factor AI conversion scoring' },
    { num: '07', name: 'Approval', desc: 'Memory persistence & team handoff' },
  ];

  const features = [
    {
      title: 'AI Campaign Planning',
      desc: 'Turn a brief product description into full-funnel positioning, core narratives, and audience segmentation tailored for your industry.',
      icon: Layers,
    },
    {
      title: 'Smart Task Decomposition',
      desc: 'Never wonder what to do next. Automatically break strategic goals into prioritized, assignable tasks on an agile Kanban board.',
      icon: ListTodo,
    },
    {
      title: 'Multi-Channel Content Generation',
      desc: 'Draft publication-ready Instagram reels, LinkedIn articles, high-conversion emails, landing page headlines, and ad copy simultaneously.',
      icon: PenTool,
    },
    {
      title: 'Rigorous Content Evaluation',
      desc: 'Audit drafts across 6 strategic dimensions: Clarity, Brand Alignment, Audience Fit, Platform Fit, CTA Strength, and Readability.',
      icon: BarChart2,
    },
    {
      title: 'Continuous Campaign Memory',
      desc: 'Preserve voice preferences, rejected tropes, and strategic decisions so future campaign iterations inherit deep brand context.',
      icon: Brain,
    },
    {
      title: 'Sequential AI Workflow Engine',
      desc: 'Orchestrate transparent 10-step AI pipelines from research through execution with verifiable outputs at every milestone.',
      icon: Workflow,
    },
  ];

  const useCases = [
    { title: 'Product Launches', desc: 'Coordinate multi-phase teaser, launch day, and VIP onboarding sequences.' },
    { title: 'Lead Generation', desc: 'Produce high-converting lead magnets, landing copy, and nurture funnels.' },
    { title: 'Social Media Campaigns', desc: 'Plan weekly viral video concepts, carousel hooks, and engagement prompts.' },
    { title: 'Brand Awareness', desc: 'Establish category leadership with opinionated editorial thought leadership.' },
    { title: 'Lifecycle & Email', desc: 'Deploy automated onboarding, retention sprints, and re-activation triggers.' },
    { title: 'Content Marketing', desc: 'Deconstruct complex topics into comprehensive SEO and social-first guides.' },
  ];

  const faqs = [
    {
      q: 'How does CampaignAI differ from generic chat assistants?',
      a: 'Unlike generic chatbots, CampaignAI is an end-to-end strategic marketing operating system. It decomposes high-level goals into tactical Kanban tasks, generates channel-specific copy, scores drafts against 6 conversion criteria, and maintains persistent brand memory across sessions.',
    },
    {
      q: 'Can I edit and approve generated content?',
      a: 'Yes. Every generated asset includes an inline editor, version history tracking, human approval workflows, and one-click AI improvement prompts grounded in evaluation feedback.',
    },
    {
      q: 'Does it require an API key to test?',
      a: 'No. CampaignAI ships with an intelligent built-in domain strategist that runs fully offline or in demo mode. When a Google Gemini API key is supplied, it automatically activates flagship Gemini 3.8 Flash intelligence.',
    },
    {
      q: 'Can I export complete campaign blueprints?',
      a: 'Yes. You can export complete campaign manifests including strategy, Kanban task tables, evaluated content drafts, and memory notes into standard Markdown or JSON with a single click.',
    },
  ];

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-[#0F172A]">
      {/* Top Navbar */}
      <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white shadow-xs">
              <Sparkles className="w-4 h-4" />
            </div>
            <span className="font-bold text-lg tracking-tight text-slate-900">
              CampaignAI
            </span>
          </div>

          <nav className="hidden md:flex items-center gap-8 text-xs font-semibold text-slate-600">
            <a href="#features" className="hover:text-indigo-600 transition-colors">Features</a>
            <a href="#workflow" className="hover:text-indigo-600 transition-colors">How It Works</a>
            <a href="#use-cases" className="hover:text-indigo-600 transition-colors">Use Cases</a>
            <a href="#faq" className="hover:text-indigo-600 transition-colors">FAQ</a>
          </nav>

          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigate('/login')}
              className="text-xs font-semibold text-slate-700 hover:text-indigo-600 px-3 py-1.5 transition-colors cursor-pointer"
            >
              Log in
            </button>
            <button
              onClick={() => onNavigate('/dashboard')}
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              <span>Get Started</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="pt-16 pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-50 border border-indigo-100 rounded-full text-indigo-700 text-xs font-medium mb-6">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Next-Generation Autonomous Marketing Agent</span>
        </div>

        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight max-w-4xl mx-auto leading-tight sm:leading-tight">
          Plan. Create. Evaluate.{' '}
          <span className="bg-gradient-to-r from-indigo-600 to-violet-600 bg-clip-text text-transparent">
            Your entire marketing campaign,
          </span>{' '}
          powered by AI.
        </h1>

        <p className="mt-6 text-base sm:text-lg text-slate-600 max-w-2xl mx-auto leading-relaxed">
          CampaignAI turns your business goals into complete marketing strategies, actionable tasks, high-quality content, and measurable campaign plans.
        </p>

        <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
          <button
            onClick={() => onNavigate('/campaigns/new')}
            className="w-full sm:w-auto px-6 py-3 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>Start Creating</span>
            <ArrowRight className="w-4 h-4" />
          </button>
          <button
            onClick={() => onNavigate('/dashboard')}
            className="w-full sm:w-auto px-6 py-3 text-sm font-semibold text-slate-700 hover:text-slate-900 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg transition-colors cursor-pointer"
          >
            Open Live Demo App
          </button>
        </div>

        {/* Dashboard Preview */}
        <div className="mt-14 max-w-5xl mx-auto rounded-xl border border-slate-200 bg-white shadow-xl overflow-hidden">
          <div className="h-9 bg-slate-100 border-b border-slate-200 px-4 flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-rose-400" />
            <div className="w-2.5 h-2.5 rounded-full bg-amber-400" />
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
            <span className="ml-2 text-[11px] text-slate-400 font-mono">
              campaignai.app/campaigns/summer-fitness-launch
            </span>
          </div>

          <div className="relative aspect-16/9 bg-slate-900 overflow-hidden">
            <img
              src="/src/assets/images/hero_campaign_dashboard_1790788068047.jpg"
              alt="CampaignAI Strategic Marketing Workspace"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent flex items-end p-6">
              <div className="text-left text-white">
                <span className="text-xs uppercase tracking-wider text-indigo-300 font-bold block mb-1">
                  Active Campaign Execution
                </span>
                <p className="text-base sm:text-lg font-bold">
                  Summer Fitness App Launch · 68% Completed · 93/100 Content Quality Score
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* AI Workflow Visualization */}
      <section id="workflow" className="py-20 bg-white border-y border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 block mb-2">
              Autonomous Intelligence
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              The End-to-End AI Campaign Pipeline
            </h2>
            <p className="mt-3 text-sm text-slate-600">
              Not a prompt generator. A disciplined sequential agent workflow that validates inputs, structures strategy, and prepares execution assets.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-7 gap-3">
            {workflowSteps.map((step, idx) => (
              <div
                key={step.num}
                className="p-4 rounded-lg bg-slate-50 border border-slate-200 hover:border-indigo-300 transition-colors text-left flex flex-col justify-between"
              >
                <div>
                  <span className="text-[11px] font-mono text-indigo-600 font-bold block mb-1">
                    {step.num}
                  </span>
                  <h3 className="text-xs font-bold text-slate-900 mb-1">
                    {step.name}
                  </h3>
                  <p className="text-[11px] text-slate-500 leading-relaxed">
                    {step.desc}
                  </p>
                </div>
                {idx < workflowSteps.length - 1 && (
                  <div className="hidden md:block mt-3 text-right">
                    <span className="text-slate-300 text-xs">→</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section id="features" className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 block mb-2">
            Platform Capabilities
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Built for High-Velocity Marketing Teams
          </h2>
          <p className="mt-3 text-sm text-slate-600">
            Everything modern growth marketers, founders, and agencies need to deploy high-converting campaigns.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feat) => {
            const Icon = feat.icon;
            return (
              <div
                key={feat.title}
                className="p-6 rounded-xl bg-white border border-slate-200 hover:border-indigo-300 hover:shadow-xs transition-all text-left"
              >
                <div className="w-9 h-9 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center mb-4">
                  <Icon className="w-5 h-5" />
                </div>
                <h3 className="text-sm font-bold text-slate-900 mb-2">
                  {feat.title}
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {feat.desc}
                </p>
              </div>
            );
          })}
        </div>
      </section>

      {/* Social Proof / Built For Teams */}
      <section className="py-20 bg-slate-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-400 block mb-2">
              Demonstrated ROI
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Trusted by Ambitious Marketing Leaders
            </h2>
            <p className="mt-3 text-sm text-slate-400">
              Transforming campaign ideation from a 3-week marathon into a 30-minute strategic sprint.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            <div className="p-6 rounded-xl bg-slate-800/80 border border-slate-700 text-left">
              <p className="text-sm text-slate-300 leading-relaxed italic mb-6">
                "CampaignAI solved our biggest bottleneck: bridging the gap between strategy and execution. Having tasks automatically populate into a Kanban board with pre-evaluated copy saved our team over 20 hours on our latest product rollout."
              </p>
              <div className="flex items-center gap-3">
                <img
                  src="/src/assets/images/avatar_marketing_lead_1790788241650.jpg"
                  alt="Elena Rostova"
                  referrerPolicy="no-referrer"
                  className="w-10 h-10 rounded-full object-cover border border-slate-600"
                />
                <div>
                  <h4 className="text-xs font-bold text-white">Elena Rostova</h4>
                  <span className="text-[11px] text-slate-400">VP of Marketing · ScaleFlow</span>
                </div>
              </div>
            </div>

            <div className="p-6 rounded-xl bg-slate-800/80 border border-slate-700 text-left">
              <p className="text-sm text-slate-300 leading-relaxed italic mb-6">
                "The 6-dimension content evaluation is phenomenal. It flags weak calls-to-action and tone mismatches before anything goes live. It’s like having a senior creative director reviewing every draft in real time."
              </p>
              <div className="flex items-center gap-3">
                <img
                  src="/src/assets/images/avatar_growth_lead_1790788265040.jpg"
                  alt="Marcus Vance"
                  referrerPolicy="no-referrer"
                  className="w-10 h-10 rounded-full object-cover border border-slate-600"
                />
                <div>
                  <h4 className="text-xs font-bold text-white">Marcus Vance</h4>
                  <span className="text-[11px] text-slate-400">Head of Growth · Veloce Studio</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Use Cases */}
      <section id="use-cases" className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 block mb-2">
            Tailored Playbooks
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Engineered for Every Marketing Objective
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {useCases.map((uc) => (
            <div
              key={uc.title}
              className="p-5 rounded-lg bg-white border border-slate-200 text-left"
            >
              <div className="flex items-center gap-2 mb-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <h3 className="text-xs font-bold text-slate-900">{uc.title}</h3>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">{uc.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="py-20 bg-white border-t border-slate-200">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">
              Frequently Asked Questions
            </h2>
          </div>

          <div className="space-y-3">
            {faqs.map((faq, index) => {
              const isOpen = openFaq === index;
              return (
                <div
                  key={index}
                  className="rounded-lg border border-slate-200 overflow-hidden"
                >
                  <button
                    onClick={() => setOpenFaq(isOpen ? null : index)}
                    className="w-full p-4 text-left flex items-center justify-between text-xs font-bold text-slate-900 hover:bg-slate-50 transition-colors"
                  >
                    <span>{faq.q}</span>
                    <ChevronDown
                      className={`w-4 h-4 text-slate-500 transition-transform ${
                        isOpen ? 'rotate-180 text-indigo-600' : ''
                      }`}
                    />
                  </button>
                  {isOpen && (
                    <div className="p-4 pt-0 text-xs text-slate-600 leading-relaxed border-t border-slate-100 bg-slate-50/50">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Footer Banner */}
      <section className="py-16 bg-indigo-600 text-white text-center px-4">
        <div className="max-w-2xl mx-auto">
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Ready to Plan Your Next Campaign?
          </h2>
          <p className="mt-3 text-xs sm:text-sm text-indigo-100">
            Experience the complete end-to-end strategic marketing workflow with instant AI planning.
          </p>
          <div className="mt-6 flex justify-center gap-3">
            <button
              onClick={() => onNavigate('/campaigns/new')}
              className="px-6 py-2.5 text-xs font-bold text-indigo-900 bg-white hover:bg-indigo-50 rounded-lg shadow-sm transition-colors cursor-pointer"
            >
              Create First Campaign
            </button>
            <button
              onClick={() => onNavigate('/dashboard')}
              className="px-6 py-2.5 text-xs font-bold text-white bg-indigo-700 hover:bg-indigo-800 rounded-lg transition-colors cursor-pointer"
            >
              Open Dashboard
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-10 bg-white border-t border-slate-200 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded-sm bg-indigo-600 flex items-center justify-center text-white">
              <Sparkles className="w-3 h-3" />
            </div>
            <span className="font-bold text-slate-800">CampaignAI</span>
            <span>· Enterprise AI Marketing Orchestration</span>
          </div>

          <div className="flex items-center gap-6">
            <button onClick={() => onNavigate('/dashboard')} className="hover:text-slate-900">Dashboard</button>
            <button onClick={() => onNavigate('/admin/evaluations')} className="hover:text-slate-900">System Tests</button>
            <button onClick={() => onNavigate('/settings')} className="hover:text-slate-900">Settings</button>
          </div>
        </div>
      </footer>
    </div>
  );
}
