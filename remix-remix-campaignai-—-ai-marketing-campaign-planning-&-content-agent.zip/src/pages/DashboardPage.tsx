import React, { useEffect, useState } from 'react';
import {
  Plus,
  ArrowRight,
  TrendingUp,
  CheckCircle2,
  Clock,
  FileText,
  Sparkles,
  Layers,
  ChevronRight,
  Target,
} from 'lucide-react';
import type { Campaign, CampaignTask, CampaignContent, UserProfile } from '../types.js';
import { api } from '../services/api.js';

interface DashboardPageProps {
  user: UserProfile | null;
  onNavigate: (path: string) => void;
  onOpenCampaign: (id: string) => void;
}

export function DashboardPage({ user, onNavigate, onOpenCampaign }: DashboardPageProps) {
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [tasks, setTasks] = useState<CampaignTask[]>([]);
  const [contentItems, setContentItems] = useState<CampaignContent[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadDashboard() {
      try {
        const [cList, tList, cntList] = await Promise.all([
          api.getCampaigns(),
          api.getTasks(),
          api.getContent(),
        ]);
        setCampaigns(cList);
        setTasks(tList);
        setContentItems(cntList);
      } catch (e) {
        console.error('Error loading dashboard data:', e);
      } finally {
        setLoading(false);
      }
    }
    loadDashboard();
  }, []);

  const activeCampaigns = campaigns.filter(c => c.status !== 'completed' && c.status !== 'archived');
  const completedCampaigns = campaigns.filter(c => c.status === 'completed');
  const pendingTasks = tasks.filter(t => t.status !== 'done');
  const pendingContent = contentItems.filter(c => c.status === 'pending_review');

  const getStatusBadge = (status: Campaign['status']) => {
    switch (status) {
      case 'in_progress':
        return <span className="text-[11px] font-semibold text-emerald-700">In Progress</span>;
      case 'planning':
        return <span className="text-[11px] font-semibold text-indigo-700">Planning</span>;
      case 'review':
        return <span className="text-[11px] font-semibold text-amber-700">Under Review</span>;
      case 'completed':
        return <span className="text-[11px] font-semibold text-slate-700">Completed</span>;
      default:
        return <span className="text-[11px] font-semibold text-slate-500">Draft</span>;
    }
  };

  if (loading) {
    return (
      <div className="p-8 max-w-7xl mx-auto space-y-6">
        <div className="h-8 w-64 bg-slate-200 animate-pulse rounded-md" />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="h-28 bg-slate-100 rounded-xl animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-8">
      {/* Greeting Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
            Good morning, {user?.name || 'Marketer'} 👋
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Here's what's happening with your marketing campaigns today.
          </p>
        </div>

        <button
          onClick={() => onNavigate('/campaigns/new')}
          className="inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs transition-colors cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>New Campaign</span>
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Active Campaigns</span>
            <div className="p-1.5 rounded-md bg-indigo-50 text-indigo-600">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-slate-900 font-tabular">
              {activeCampaigns.length}
            </span>
            <span className="text-[11px] text-slate-400">orchestrations</span>
          </div>
        </div>

        <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Completed Campaigns</span>
            <div className="p-1.5 rounded-md bg-emerald-50 text-emerald-600">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-slate-900 font-tabular">
              {completedCampaigns.length}
            </span>
            <span className="text-[11px] text-emerald-600 font-medium">deployed</span>
          </div>
        </div>

        <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Pending Tasks</span>
            <div className="p-1.5 rounded-md bg-amber-50 text-amber-600">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-slate-900 font-tabular">
              {pendingTasks.length}
            </span>
            <span className="text-[11px] text-slate-400">across boards</span>
          </div>
        </div>

        <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Content to Review</span>
            <div className="p-1.5 rounded-md bg-violet-50 text-violet-600">
              <FileText className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-slate-900 font-tabular">
              {pendingContent.length}
            </span>
            <span className="text-[11px] text-indigo-600 font-medium">ready for sign-off</span>
          </div>
        </div>
      </div>

      {/* Main Grid: Active Campaigns + Activity Feed */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column (2 cols): Campaign Overview */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Active Campaigns</h3>
              <p className="text-xs text-slate-500">Track progress, strategy deliverables, and task velocity.</p>
            </div>
            <button
              onClick={() => onNavigate('/campaigns')}
              className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
            >
              <span>View All</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {campaigns.map((camp) => (
              <div
                key={camp.id}
                onClick={() => onOpenCampaign(camp.id)}
                className="p-5 rounded-xl bg-white border border-slate-200 hover:border-indigo-300 hover:shadow-xs transition-all cursor-pointer text-left"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-bold text-slate-900 hover:text-indigo-600 transition-colors">
                        {camp.name}
                      </h4>
                      <span className="text-slate-300 font-light">·</span>
                      {getStatusBadge(camp.status)}
                    </div>
                    <p className="text-xs text-slate-600 line-clamp-1">
                      {camp.productDescription || camp.description}
                    </p>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenCampaign(camp.id);
                    }}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 transition-colors"
                  >
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>

                {/* Progress bar */}
                <div className="mt-4 space-y-1.5">
                  <div className="flex items-center justify-between text-[11px] text-slate-500">
                    <div className="flex items-center gap-2">
                      <span>Goal: <strong className="text-slate-700">{camp.goal}</strong></span>
                      <span>·</span>
                      <span>Channel: <strong className="text-slate-700">{camp.primaryChannel}</strong></span>
                      <span>·</span>
                      <span><strong className="text-slate-700">{camp.taskCount ?? 5}</strong> tasks</span>
                    </div>
                    <span className="font-semibold text-slate-700 font-tabular">
                      {camp.progressPercentage}%
                    </span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-indigo-600 rounded-full transition-all duration-500"
                      style={{ width: `${camp.progressPercentage}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Pending Review Section */}
          {pendingContent.length > 0 && (
            <div className="pt-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-bold text-slate-900">Pending Content Approvals</h3>
                <span className="text-xs text-slate-500">{pendingContent.length} drafts awaiting review</span>
              </div>
              <div className="space-y-2">
                {pendingContent.slice(0, 3).map((item) => (
                  <div
                    key={item.id}
                    onClick={() => onOpenCampaign(item.campaignId)}
                    className="p-3.5 rounded-lg bg-white border border-slate-200 hover:border-slate-300 transition-colors flex items-center justify-between cursor-pointer"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-900">{item.title}</span>
                        <span className="text-slate-300">·</span>
                        <span className="text-[11px] text-slate-500">{item.type}</span>
                        {item.evaluation && (
                          <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">
                            Score: {item.evaluation.overallScore}/100
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-500 truncate max-w-md mt-0.5">
                        {item.headline || item.body.slice(0, 80)}
                      </p>
                    </div>
                    <button className="text-xs font-semibold text-indigo-600 hover:text-indigo-800">
                      Review & Approve →
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Recent AI Activity & Quick Shortcuts */}
        <div className="space-y-6">
          <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-2xs space-y-4">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-600" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900">
                Recent AI Activity
              </h3>
            </div>

            <div className="space-y-3.5">
              <div className="flex items-start gap-3 text-xs">
                <div className="w-2 h-2 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                <div>
                  <p className="font-semibold text-slate-800">
                    Strategy synthesized for Summer Launch
                  </p>
                  <p className="text-[11px] text-slate-500">
                    Positioned recovery-first value proposition across Instagram & Email.
                  </p>
                  <span className="text-[10px] text-slate-400 font-tabular">2 hours ago</span>
                </div>
              </div>

              <div className="flex items-start gap-3 text-xs">
                <div className="w-2 h-2 rounded-full bg-indigo-500 mt-1.5 shrink-0" />
                <div>
                  <p className="font-semibold text-slate-800">
                    Instagram Reel draft evaluated (93/100)
                  </p>
                  <p className="text-[11px] text-slate-500">
                    High narrative velocity with verified biometric hooks.
                  </p>
                  <span className="text-[10px] text-slate-400 font-tabular">4 hours ago</span>
                </div>
              </div>

              <div className="flex items-start gap-3 text-xs">
                <div className="w-2 h-2 rounded-full bg-purple-500 mt-1.5 shrink-0" />
                <div>
                  <p className="font-semibold text-slate-800">
                    Tasks decomposed from Strategy
                  </p>
                  <p className="text-[11px] text-slate-500">
                    5 operational milestones mapped onto agile Kanban.
                  </p>
                  <span className="text-[10px] text-slate-400 font-tabular">Yesterday</span>
                </div>
              </div>

              <div className="flex items-start gap-3 text-xs">
                <div className="w-2 h-2 rounded-full bg-amber-500 mt-1.5 shrink-0" />
                <div>
                  <p className="font-semibold text-slate-800">
                    Campaign memory consolidated
                  </p>
                  <p className="text-[11px] text-slate-500">
                    4 strategic mandates stored for automated recall.
                  </p>
                  <span className="text-[10px] text-slate-400 font-tabular">2 days ago</span>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Playbook Launch Card */}
          <div className="p-5 rounded-xl bg-gradient-to-br from-indigo-900 to-slate-900 text-white space-y-3">
            <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-300">
              Ready for your next initiative?
            </span>
            <h4 className="text-sm font-bold">Launch a Strategic Sprint</h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              Define your business goal in under 2 minutes and let our multi-agent engine generate strategy, tasks, and copy.
            </p>
            <button
              onClick={() => onNavigate('/campaigns/new')}
              className="w-full mt-2 py-2 px-3 bg-indigo-500 hover:bg-indigo-600 text-white font-semibold text-xs rounded-lg transition-colors cursor-pointer"
            >
              Start New Campaign Wizard →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
