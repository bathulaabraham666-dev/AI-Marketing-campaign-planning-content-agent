import React, { useEffect, useState } from 'react';
import {
  BarChart3,
  TrendingUp,
  CheckCircle2,
  Layers,
  FileText,
  Clock,
  PieChart,
  ShieldCheck,
  Target,
} from 'lucide-react';
import type { AnalyticsSummary } from '../types.js';
import { api } from '../services/api.js';

export function AnalyticsPage() {
  const [data, setData] = useState<AnalyticsSummary | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadStats() {
      try {
        const stats = await api.getAnalytics();
        setData(stats);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    }
    loadStats();
  }, []);

  if (loading || !data) {
    return (
      <div className="p-8 max-w-7xl mx-auto space-y-6">
        <div className="h-8 w-48 bg-slate-200 animate-pulse rounded" />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-28 bg-slate-100 rounded-xl animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  const completionRate = data.totalTasks > 0 ? Math.round((data.tasksCompleted / data.totalTasks) * 100) : 0;
  const approvalRate = data.contentGenerated > 0 ? Math.round((data.contentApproved / data.contentGenerated) * 100) : 0;

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-8 text-left">
      <div>
        <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
          Campaign Planning & Operational Telemetry
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
          Quantifiable execution metrics measuring strategic turnaround, quality indices, and task velocity.
        </p>
      </div>

      {/* Primary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-2xs">
          <span className="text-xs font-semibold text-slate-500 block">Total Active Campaigns</span>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900 font-tabular">
              {data.activeCampaigns}
            </span>
            <span className="text-xs text-indigo-600 font-semibold">{data.completedCampaigns} completed</span>
          </div>
          <span className="text-[11px] text-slate-400 block mt-2">
            High-intent marketing blueprints
          </span>
        </div>

        <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-2xs">
          <span className="text-xs font-semibold text-slate-500 block">Task Completion Velocity</span>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900 font-tabular">
              {completionRate}%
            </span>
            <span className="text-xs text-slate-400 font-tabular">({data.tasksCompleted}/{data.totalTasks})</span>
          </div>
          <div className="mt-2 h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
            <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${completionRate}%` }} />
          </div>
        </div>

        <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-2xs">
          <span className="text-xs font-semibold text-slate-500 block">Content Approval Rate</span>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900 font-tabular">
              {approvalRate}%
            </span>
            <span className="text-xs text-emerald-600 font-semibold font-tabular">{data.contentApproved} signed-off</span>
          </div>
          <div className="mt-2 h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
            <div className="h-full bg-indigo-600 rounded-full" style={{ width: `${approvalRate}%` }} />
          </div>
        </div>

        <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-2xs">
          <span className="text-xs font-semibold text-slate-500 block">Average Quality Score</span>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900 font-tabular">
              {data.avgAiQualityScore}
            </span>
            <span className="text-xs text-slate-400">/ 100 index</span>
          </div>
          <span className="text-[11px] text-slate-400 block mt-2">
            Weighted across 6 evaluation factors
          </span>
        </div>
      </div>

      {/* Distribution Breakdown Charts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Channel Breakdown */}
        <div className="p-6 bg-white border border-slate-200 rounded-xl shadow-2xs space-y-4">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-indigo-600" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900">
              Distribution Channels Deployed
            </h3>
          </div>

          <div className="space-y-3">
            {data.channelBreakdown.map((item) => (
              <div key={item.channel} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-700">{item.channel}</span>
                  <span className="font-bold text-slate-900 font-tabular">{item.count} activations</span>
                </div>
                <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-indigo-600 rounded-full"
                    style={{ width: `${Math.min(100, item.count * 25)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Goal Breakdown */}
        <div className="p-6 bg-white border border-slate-200 rounded-xl shadow-2xs space-y-4">
          <div className="flex items-center gap-2">
            <Target className="w-4 h-4 text-indigo-600" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900">
              Strategic Goal Objectives
            </h3>
          </div>

          <div className="space-y-3">
            {data.goalBreakdown.map((item) => (
              <div key={item.goal} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-700">{item.goal}</span>
                  <span className="font-bold text-slate-900 font-tabular">{item.count} campaigns</span>
                </div>
                <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-emerald-500 rounded-full"
                    style={{ width: `${Math.min(100, item.count * 35)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
