import React, { useEffect, useState } from 'react';
import {
  User,
  Building,
  Volume2,
  Sparkles,
  Shield,
  Save,
  CheckCircle2,
} from 'lucide-react';
import type { UserProfile, BrandVoice } from '../types.js';
import { api } from '../services/api.js';
import { useToast } from '../components/Toast.js';

export function SettingsPage() {
  const { showToast } = useToast();
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  // Form State
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [businessName, setBusinessName] = useState('');
  const [industry, setIndustry] = useState('');
  const [website, setWebsite] = useState('');
  const [defaultBrandVoice, setDefaultBrandVoice] = useState<BrandVoice>('Bold');
  const [defaultAudience, setDefaultAudience] = useState('');
  const [aiModel, setAiModel] = useState('gemini-3.8-flash');

  useEffect(() => {
    async function loadSettings() {
      try {
        const u = await api.getSettings();
        setUser(u);
        setName(u.name);
        setEmail(u.email);
        setBusinessName(u.businessName || '');
        setIndustry(u.industry || '');
        setWebsite(u.website || '');
        if (u.defaultBrandVoice) setDefaultBrandVoice(u.defaultBrandVoice);
        setDefaultAudience(u.defaultAudience || '');
        if (u.aiModel) setAiModel(u.aiModel);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    }
    loadSettings();
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const updated = await api.updateSettings({
        name,
        email,
        businessName,
        industry,
        website,
        defaultBrandVoice,
        defaultAudience,
        aiModel,
      });
      setUser(updated);
      showToast('Settings saved successfully', 'success');
    } catch (e) {
      showToast('Failed to save settings', 'error');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="p-8 max-w-4xl mx-auto space-y-4">
        <div className="h-8 w-48 bg-slate-200 animate-pulse rounded" />
        <div className="h-64 bg-slate-100 rounded-xl animate-pulse" />
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-4xl mx-auto space-y-6 text-left">
      <div>
        <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
          Account & Strategic Preferences
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
          Configure organization defaults, persistent brand voice, and model orchestration settings.
        </p>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Profile Card */}
        <div className="p-6 bg-white border border-slate-200 rounded-xl shadow-2xs space-y-4">
          <div className="flex items-center gap-2 text-indigo-600">
            <User className="w-4 h-4" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900">
              User Profile
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Full Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Email Address</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
              />
            </div>
          </div>
        </div>

        {/* Business & Brand Card */}
        <div className="p-6 bg-white border border-slate-200 rounded-xl shadow-2xs space-y-4">
          <div className="flex items-center gap-2 text-indigo-600">
            <Building className="w-4 h-4" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900">
              Organization & Default Brand Voice
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Business Name</label>
              <input
                type="text"
                value={businessName}
                onChange={(e) => setBusinessName(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Industry</label>
              <input
                type="text"
                value={industry}
                onChange={(e) => setIndustry(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Website URL</label>
              <input
                type="text"
                value={website}
                onChange={(e) => setWebsite(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Default Brand Voice</label>
              <select
                value={defaultBrandVoice}
                onChange={(e: any) => setDefaultBrandVoice(e.target.value)}
                className="w-full px-2.5 py-2 border border-slate-200 rounded-lg text-slate-800"
              >
                <option value="Professional">Professional</option>
                <option value="Bold">Bold</option>
                <option value="Friendly">Friendly</option>
                <option value="Educational">Educational</option>
                <option value="Luxury">Luxury</option>
                <option value="Playful">Playful</option>
                <option value="Minimal">Minimal</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Default Target Persona</label>
              <input
                type="text"
                value={defaultAudience}
                onChange={(e) => setDefaultAudience(e.target.value)}
                placeholder="e.g. Urban professionals aged 25-42"
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
              />
            </div>
          </div>
        </div>

        {/* AI Model Preferences */}
        <div className="p-6 bg-white border border-slate-200 rounded-xl shadow-2xs space-y-4">
          <div className="flex items-center gap-2 text-indigo-600">
            <Sparkles className="w-4 h-4" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900">
              Autonomous Intelligence Engine
            </h3>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Configured Model</label>
              <select
                value={aiModel}
                onChange={(e) => setAiModel(e.target.value)}
                className="w-full px-2.5 py-2 border border-slate-200 rounded-lg text-slate-800 font-mono text-xs"
              >
                <option value="gemini-3.8-flash">gemini-3.8-flash (Recommended: Low Latency, High Reasoning)</option>
              </select>
              <p className="text-[11px] text-slate-400 mt-1">
                Gemini API calls are executed securely on the backend server. No API secrets are exposed to the client.
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-end">
          <button
            type="submit"
            disabled={saving}
            className="flex items-center gap-2 px-5 py-2.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 rounded-lg shadow-xs transition-colors cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>{saving ? 'Saving...' : 'Save Settings'}</span>
          </button>
        </div>
      </form>
    </div>
  );
}
