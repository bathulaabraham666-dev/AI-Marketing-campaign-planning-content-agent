import React, { useState } from 'react';
import { Sparkles, ArrowRight, Lock, Mail, User, Building, Check } from 'lucide-react';
import { api } from '../services/api.js';
import { useToast } from '../components/Toast.js';

interface AuthPageProps {
  mode: 'login' | 'signup' | 'forgot-password';
  onNavigate: (path: string) => void;
  onSuccess: () => void;
}

export function AuthPage({ mode, onNavigate, onSuccess }: AuthPageProps) {
  const { showToast } = useToast();
  const [email, setEmail] = useState('sarah.chen@campaignai.co');
  const [password, setPassword] = useState('••••••••••••');
  const [confirmPassword, setConfirmPassword] = useState('••••••••••••');
  const [name, setName] = useState('Sarah Chen');
  const [businessName, setBusinessName] = useState('FitPulse Technologies');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (mode === 'login') {
        await api.login(email);
        showToast('Welcome back to CampaignAI!', 'success');
        onSuccess();
      } else if (mode === 'signup') {
        if (password !== confirmPassword) {
          showToast('Passwords do not match', 'error');
          setLoading(false);
          return;
        }
        await api.signup({ name, email, businessName });
        showToast('Account created successfully!', 'success');
        onSuccess();
      } else {
        showToast('Password reset link sent to your email.', 'info');
        onNavigate('/login');
      }
    } catch (err: any) {
      showToast(err.message || 'Authentication error', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleDemoSignIn = async () => {
    setLoading(true);
    try {
      await api.login('sarah.chen@campaignai.co');
      showToast('Signed in as Sarah Chen (Demo CMO)', 'success');
      onSuccess();
    } catch (err: any) {
      showToast('Demo login failed', 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-center items-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center mb-6">
        <button
          onClick={() => onNavigate('/')}
          className="inline-flex items-center gap-2 mb-4 hover:opacity-80 transition-opacity"
        >
          <div className="w-9 h-9 rounded-lg bg-indigo-600 flex items-center justify-center text-white shadow-xs">
            <Sparkles className="w-5 h-5" />
          </div>
          <span className="font-bold text-xl tracking-tight text-slate-900">
            CampaignAI
          </span>
        </button>

        <h2 className="text-xl font-bold tracking-tight text-slate-900">
          {mode === 'login' && 'Sign in to your campaign workspace'}
          {mode === 'signup' && 'Create your marketing workspace'}
          {mode === 'forgot-password' && 'Reset your password'}
        </h2>
        <p className="mt-1 text-xs text-slate-500">
          {mode === 'login' && 'Enter your credentials to access active campaigns'}
          {mode === 'signup' && 'Start deploying AI-powered campaign workflows in seconds'}
          {mode === 'forgot-password' && 'Enter your verified account email to receive instructions'}
        </p>
      </div>

      <div className="w-full sm:max-w-md bg-white p-8 border border-slate-200 rounded-xl shadow-xs">
        {/* Quick Demo Access banner */}
        {mode === 'login' && (
          <div className="mb-6 p-3 bg-indigo-50 border border-indigo-100 rounded-lg flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-indigo-900 block">
                Instant Demo Access
              </span>
              <span className="text-[11px] text-indigo-700 block">
                Preloaded with "Summer Fitness Launch"
              </span>
            </div>
            <button
              onClick={handleDemoSignIn}
              type="button"
              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-md transition-colors shadow-2xs"
            >
              1-Click Demo
            </button>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === 'signup' && (
            <>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Full Name
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-indigo-500 text-slate-900"
                    placeholder="Sarah Chen"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Business / Company Name
                </label>
                <div className="relative">
                  <Building className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={businessName}
                    onChange={(e) => setBusinessName(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-indigo-500 text-slate-900"
                    placeholder="FitPulse Technologies"
                  />
                </div>
              </div>
            </>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Email Address
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-indigo-500 text-slate-900"
                placeholder="name@company.com"
              />
            </div>
          </div>

          {mode !== 'forgot-password' && (
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-semibold text-slate-700">
                  Password
                </label>
                {mode === 'login' && (
                  <button
                    type="button"
                    onClick={() => onNavigate('/forgot-password')}
                    className="text-[11px] text-indigo-600 hover:text-indigo-800"
                  >
                    Forgot password?
                  </button>
                )}
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-indigo-500 text-slate-900"
                  placeholder="••••••••••••"
                />
              </div>
            </div>
          )}

          {mode === 'signup' && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Confirm Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-indigo-500 text-slate-900"
                  placeholder="••••••••••••"
                />
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full mt-4 flex items-center justify-center gap-2 py-2.5 px-4 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 rounded-lg shadow-xs transition-colors cursor-pointer"
          >
            {loading ? (
              <span>Processing...</span>
            ) : (
              <>
                <span>
                  {mode === 'login' && 'Sign in to Workspace'}
                  {mode === 'signup' && 'Create Account & Workspace'}
                  {mode === 'forgot-password' && 'Send Reset Link'}
                </span>
                <ArrowRight className="w-3.5 h-3.5" />
              </>
            )}
          </button>
        </form>

        <div className="mt-6 pt-4 border-t border-slate-100 text-center text-xs text-slate-500">
          {mode === 'login' && (
            <p>
              Don't have an account?{' '}
              <button
                onClick={() => onNavigate('/signup')}
                className="font-semibold text-indigo-600 hover:text-indigo-800"
              >
                Sign up
              </button>
            </p>
          )}
          {mode === 'signup' && (
            <p>
              Already have an account?{' '}
              <button
                onClick={() => onNavigate('/login')}
                className="font-semibold text-indigo-600 hover:text-indigo-800"
              >
                Log in
              </button>
            </p>
          )}
          {mode === 'forgot-password' && (
            <button
              onClick={() => onNavigate('/login')}
              className="font-semibold text-indigo-600 hover:text-indigo-800"
            >
              Return to log in
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
