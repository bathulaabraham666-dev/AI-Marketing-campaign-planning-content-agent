import React, { useEffect, useState } from 'react';
import { Bot, Sparkles, Send, Brain, ArrowRight } from 'lucide-react';
import type { Campaign, ChatMessage } from '../types.js';
import { api } from '../services/api.js';
import { AssistantTab } from './CampaignWorkspace/AssistantTab.js';

interface GlobalAssistantPageProps {
  onNavigate: (path: string) => void;
}

export function GlobalAssistantPage({ onNavigate }: GlobalAssistantPageProps) {
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [selectedCampaignId, setSelectedCampaignId] = useState<string>('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadCampaigns() {
      try {
        const list = await api.getCampaigns();
        setCampaigns(list);
        if (list.length > 0) {
          setSelectedCampaignId(list[0].id);
        }
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    }
    loadCampaigns();
  }, []);

  const selectedCampaign = campaigns.find((c) => c.id === selectedCampaignId) || campaigns[0];

  if (loading) {
    return (
      <div className="p-8 max-w-4xl mx-auto space-y-4">
        <div className="h-8 w-48 bg-slate-200 animate-pulse rounded" />
        <div className="h-96 bg-slate-100 rounded-xl animate-pulse" />
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-5xl mx-auto space-y-6 text-left">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
            Strategic AI Marketing Assistant
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Your dedicated autonomous CMO grounded in active campaign data and memory bank.
          </p>
        </div>

        {campaigns.length > 1 && (
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-500">Context:</span>
            <select
              value={selectedCampaignId}
              onChange={(e) => setSelectedCampaignId(e.target.value)}
              className="px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg text-slate-800 font-semibold focus:outline-hidden"
            >
              {campaigns.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} ({c.goal})
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      {selectedCampaign ? (
        <AssistantTab campaign={selectedCampaign} />
      ) : (
        <div className="py-16 text-center bg-white border border-slate-200 rounded-xl p-8">
          <Bot className="w-8 h-8 text-slate-300 mx-auto mb-2" />
          <p className="text-xs text-slate-500">Create a campaign first to ground the assistant.</p>
        </div>
      )}
    </div>
  );
}
