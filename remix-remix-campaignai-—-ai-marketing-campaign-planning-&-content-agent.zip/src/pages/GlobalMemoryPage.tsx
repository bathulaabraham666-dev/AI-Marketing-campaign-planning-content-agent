import React, { useEffect, useState } from 'react';
import { Brain, Trash2, Plus, Sparkles, Filter } from 'lucide-react';
import type { CampaignMemory, Campaign, MemoryCategory } from '../types.js';
import { api } from '../services/api.js';
import { useToast } from '../components/Toast.js';

interface GlobalMemoryPageProps {
  onOpenCampaign: (campaignId: string) => void;
}

export function GlobalMemoryPage({ onOpenCampaign }: GlobalMemoryPageProps) {
  const { showToast } = useToast();
  const [memories, setMemories] = useState<CampaignMemory[]>([]);
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [loading, setLoading] = useState(true);
  const [categoryFilter, setCategoryFilter] = useState('all');

  useEffect(() => {
    async function loadData() {
      try {
        const [memList, campList] = await Promise.all([
          api.getMemories(),
          api.getCampaigns(),
        ]);
        setMemories(memList);
        setCampaigns(campList);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, []);

  const handleDelete = async (id: string, campaignId?: string) => {
    if (!confirm('Forget this memory item?')) return;
    try {
      await api.deleteMemory(campaignId || 'global', id);
      setMemories(memories.filter((m) => m.id !== id));
      showToast('Memory item deleted', 'info');
    } catch (e) {
      showToast('Failed to delete memory', 'error');
    }
  };

  const getCampaignName = (campaignId?: string) => {
    if (!campaignId) return 'Global User Memory';
    const found = campaigns.find((c) => c.id === campaignId);
    return found ? found.name : 'Campaign Memory';
  };

  const filtered = memories.filter((m) =>
    categoryFilter === 'all' ? true : m.category === categoryFilter
  );

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6 text-left">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
            Campaign Memory Bank
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Decisions, approved copy, brand voice mandates, and strategic learnings remembered across sessions.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-hidden"
          >
            <option value="all">All Memory Types</option>
            <option value="user">User & Brand Info</option>
            <option value="campaign">Strategic Campaign Decisions</option>
            <option value="conversation">Chat & Instruction Mandates</option>
          </select>
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-36 bg-slate-100 rounded-xl animate-pulse" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="py-16 text-center bg-white border border-slate-200 rounded-xl p-8">
          <Brain className="w-8 h-8 text-slate-300 mx-auto mb-2" />
          <p className="text-xs text-slate-500">No memory anchors stored yet.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {filtered.map((mem) => (
            <div
              key={mem.id}
              className="p-5 bg-white border border-slate-200 rounded-xl shadow-2xs space-y-3 flex flex-col justify-between hover:border-indigo-300 transition-colors group"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded">
                    {mem.category} memory
                  </span>
                  <button
                    onClick={() => handleDelete(mem.id, mem.campaignId)}
                    className="opacity-0 group-hover:opacity-100 p-1 text-slate-300 hover:text-rose-600 rounded transition-all"
                    title="Forget this memory"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                <h4 className="text-xs font-bold text-slate-900 leading-snug">
                  {mem.key}
                </h4>

                <p className="text-xs text-slate-700 leading-relaxed bg-slate-50 p-3 rounded-lg border border-slate-100">
                  {mem.content}
                </p>
              </div>

              <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                <span className="truncate pr-2">
                  Scope: <strong className="text-slate-600">{getCampaignName(mem.campaignId)}</strong>
                </span>
                <span className="font-tabular shrink-0">
                  {new Date(mem.createdAt).toLocaleDateString()}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
