import React, { useState } from 'react';
import {
  Brain,
  Plus,
  Trash2,
  Bookmark,
  Sparkles,
  ShieldCheck,
  Tag,
  Clock,
} from 'lucide-react';
import type { Campaign, CampaignMemory, MemoryCategory } from '../../types.js';
import { api } from '../../services/api.js';
import { useToast } from '../../components/Toast.js';

interface MemoryTabProps {
  campaign: Campaign;
  memories: CampaignMemory[];
  onMemoriesUpdated: (memories: CampaignMemory[]) => void;
}

export function MemoryTab({
  campaign,
  memories,
  onMemoriesUpdated,
}: MemoryTabProps) {
  const { showToast } = useToast();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [newKey, setNewKey] = useState('');
  const [newContent, setNewContent] = useState('');
  const [newCategory, setNewCategory] = useState<MemoryCategory>('campaign');

  const filteredMemories = memories.filter((m) =>
    selectedCategory === 'all' ? true : m.category === selectedCategory
  );

  const handleDelete = async (memoryId: string) => {
    if (!confirm('Forget this memory item?')) return;
    try {
      await api.deleteMemory(campaign.id, memoryId);
      onMemoriesUpdated(memories.filter((m) => m.id !== memoryId));
      showToast('Memory item deleted', 'info');
    } catch (e) {
      showToast('Failed to delete memory', 'error');
    }
  };

  const handleCreateMemory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKey.trim() || !newContent.trim()) return;

    try {
      const created = await api.createMemory(campaign.id, {
        category: newCategory,
        key: newKey,
        content: newContent,
        source: 'User Custom Strategic Mandate',
      });
      onMemoriesUpdated([created, ...memories]);
      setShowAddModal(false);
      setNewKey('');
      setNewContent('');
      showToast('Saved to persistent campaign intelligence', 'success');
    } catch (e) {
      showToast('Failed to save memory', 'error');
    }
  };

  const getCategoryBadge = (cat: MemoryCategory) => {
    switch (cat) {
      case 'user':
        return <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded">User Memory</span>;
      case 'campaign':
        return <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">Campaign Memory</span>;
      case 'conversation':
        return <span className="text-[10px] font-bold uppercase tracking-wider text-violet-700 bg-violet-50 px-2 py-0.5 rounded">Conversation Memory</span>;
    }
  };

  return (
    <div className="space-y-6 text-left">
      {/* Memory Intelligence Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 bg-white border border-slate-200 rounded-xl shadow-2xs">
        <div>
          <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-600">
            Persistent Context Engine
          </span>
          <h3 className="text-sm font-bold text-slate-900">
            Campaign Memory & Strategic Mandates ({memories.length} Stored Anchors)
          </h3>
        </div>

        <div className="flex items-center gap-2">
          {/* Category Filter */}
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-700 focus:outline-hidden"
          >
            <option value="all">All Categories</option>
            <option value="campaign">Campaign Decisions</option>
            <option value="user">User & Brand Defaults</option>
            <option value="conversation">Chat Directives</option>
          </select>

          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-2xs transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Store Memory</span>
          </button>
        </div>
      </div>

      {/* Memory Info Explanation */}
      <div className="p-4 bg-indigo-50/50 border border-indigo-100 rounded-xl flex items-start gap-3 text-xs text-indigo-950">
        <Brain className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
        <p className="leading-relaxed">
          CampaignAI uses these persistent memories to anchor future strategy regenerations, content drafts, and assistant chats. When you approve content or set brand constraints, they are permanently stored here.
        </p>
      </div>

      {/* Memories Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredMemories.map((mem) => (
          <div
            key={mem.id}
            className="p-5 bg-white border border-slate-200 rounded-xl shadow-2xs space-y-3 flex flex-col justify-between hover:border-indigo-300 transition-colors group"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                {getCategoryBadge(mem.category)}
                <button
                  onClick={() => handleDelete(mem.id)}
                  className="opacity-0 group-hover:opacity-100 p-1 text-slate-300 hover:text-rose-600 rounded transition-all"
                  title="Forget this memory"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>

              <h4 className="text-xs font-bold text-slate-900 leading-snug">
                {mem.key}
              </h4>

              <p className="text-xs text-slate-700 leading-relaxed bg-slate-50 p-3 rounded-lg border border-slate-100">
                {mem.content}
              </p>
            </div>

            <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
              <span className="truncate pr-2">Source: {mem.source}</span>
              <span className="font-tabular shrink-0">
                {new Date(mem.createdAt).toLocaleDateString()}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Add Memory Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl p-6 max-w-md w-full shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h4 className="text-sm font-bold text-slate-900">Add Strategic Memory Anchor</h4>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-700">
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateMemory} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Memory Category</label>
                <select
                  value={newCategory}
                  onChange={(e: any) => setNewCategory(e.target.value)}
                  className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg text-slate-800"
                >
                  <option value="campaign">Campaign Memory (Rules, positioning mandates)</option>
                  <option value="user">User Memory (Global company / voice facts)</option>
                  <option value="conversation">Conversation Directives</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Key Label / Directive *</label>
                <input
                  type="text"
                  required
                  value={newKey}
                  onChange={(e) => setNewKey(e.target.value)}
                  placeholder="e.g. Forbidden Jargon: Avoid 'disruptive'"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Mandate Details *</label>
                <textarea
                  rows={3}
                  required
                  value={newContent}
                  onChange={(e) => setNewContent(e.target.value)}
                  placeholder="Never use corporate buzzwords; focus exclusively on verifiable developer hours saved..."
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs"
                >
                  Save Memory Anchor
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
