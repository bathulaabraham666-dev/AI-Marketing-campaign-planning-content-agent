import React, { useState } from 'react';
import {
  Sparkles,
  BarChart2,
  CheckCircle2,
  AlertTriangle,
  Lightbulb,
  Wand2,
  RotateCcw,
  Check,
  ShieldAlert,
} from 'lucide-react';
import type { Campaign, CampaignContent, ContentEvaluation } from '../../types.js';
import { api } from '../../services/api.js';
import { useToast } from '../../components/Toast.js';

interface EvaluationTabProps {
  campaign: Campaign;
  content: CampaignContent[];
  onContentUpdated: (content: CampaignContent[]) => void;
}

export function EvaluationTab({
  campaign,
  content,
  onContentUpdated,
}: EvaluationTabProps) {
  const { showToast } = useToast();
  const [selectedContentId, setSelectedContentId] = useState<string>(content[0]?.id || '');
  const [reEvaluating, setReEvaluating] = useState(false);
  const [improving, setImproving] = useState(false);

  const selectedItem = content.find((c) => c.id === selectedContentId) || content[0];
  const evalData = selectedItem?.evaluation;

  const handleReEvaluate = async () => {
    if (!selectedItem) return;
    setReEvaluating(true);
    try {
      const evaluation = await api.evaluateContent(campaign.id, selectedItem.id);
      const updated = { ...selectedItem, evaluation };
      onContentUpdated(content.map((c) => (c.id === selectedItem.id ? updated : c)));
      showToast('Quality scores re-evaluated!', 'success');
    } catch (e) {
      showToast('Re-evaluation failed', 'error');
    } finally {
      setReEvaluating(false);
    }
  };

  const handleApplySuggestions = async () => {
    if (!selectedItem || !evalData) return;
    setImproving(true);
    try {
      const suggestionText = evalData.suggestions.join('. ');
      const improved = await api.improveContent(
        campaign.id,
        selectedItem.id,
        `Address these evaluation points: ${suggestionText}`
      );
      onContentUpdated(content.map((c) => (c.id === selectedItem.id ? improved : c)));
      showToast('Applied AI recommendations to draft!', 'success');
    } catch (e) {
      showToast('Failed to apply improvements', 'error');
    } finally {
      setImproving(false);
    }
  };

  const metricCards = evalData
    ? [
        { label: 'Clarity', score: evalData.clarity, desc: 'Unambiguous value proposition & concise sentence structure' },
        { label: 'Brand Alignment', score: evalData.brandAlignment, desc: `Faithful to ${campaign.brandVoice} tone and brand standards` },
        { label: 'Audience Fit', score: evalData.audienceFit, desc: 'Addresses primary customer pain points & psychographics' },
        { label: 'Platform Resonance', score: evalData.platformFit, desc: `Adheres to reading format of ${selectedItem?.platform || 'Channel'}` },
        { label: 'CTA Strength', score: evalData.ctaStrength, desc: 'Action-oriented conversion clarity with low user friction' },
        { label: 'Readability', score: evalData.readability, desc: 'Rhythmic line breaks, scannability, and syntax velocity' },
      ]
    : [];

  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-emerald-600 bg-emerald-500';
    if (score >= 80) return 'text-indigo-600 bg-indigo-500';
    if (score >= 70) return 'text-amber-600 bg-amber-500';
    return 'text-rose-600 bg-rose-500';
  };

  if (!selectedItem) {
    return (
      <div className="py-16 text-center bg-white border border-slate-200 rounded-xl p-8 max-w-md mx-auto">
        <BarChart2 className="w-8 h-8 text-slate-300 mx-auto mb-2" />
        <p className="text-xs text-slate-500">No content available to evaluate.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 text-left">
      {/* Header with Asset Selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 bg-white border border-slate-200 rounded-xl shadow-2xs">
        <div>
          <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-600">
            Conversion & Quality Audit
          </span>
          <h3 className="text-sm font-bold text-slate-900">
            Strategic Evaluation Framework
          </h3>
        </div>

        <div className="flex items-center gap-3">
          <select
            value={selectedContentId}
            onChange={(e) => setSelectedContentId(e.target.value)}
            className="px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-indigo-500 max-w-xs"
          >
            {content.map((item) => (
              <option key={item.id} value={item.id}>
                {item.title} ({item.type})
              </option>
            ))}
          </select>

          <button
            onClick={handleReEvaluate}
            disabled={reEvaluating}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors cursor-pointer"
          >
            <RotateCcw className={`w-3.5 h-3.5 ${reEvaluating ? 'animate-spin' : ''}`} />
            <span>{reEvaluating ? 'Evaluating...' : 'Re-Evaluate'}</span>
          </button>
        </div>
      </div>

      {/* Mandatory Disclaimer Badge */}
      <div className="px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg flex items-center gap-2 text-xs text-slate-600">
        <ShieldAlert className="w-4 h-4 text-indigo-500 shrink-0" />
        <span>
          <strong>AI Quality Indicators:</strong> These evaluation scores are synthesized by LLM benchmark heuristics to guide conversion optimization. They are not statistically guaranteed financial projections.
        </span>
      </div>

      {evalData ? (
        <div className="space-y-6">
          {/* Overall Score Highlight Banner */}
          <div className="p-6 bg-white border border-slate-200 rounded-xl shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="flex items-center gap-5">
              <div className="w-20 h-20 rounded-2xl bg-indigo-50 border border-indigo-100 flex flex-col items-center justify-center">
                <span className="text-3xl font-black text-indigo-700 font-tabular">
                  {evalData.overallScore}
                </span>
                <span className="text-[10px] font-bold text-indigo-500 uppercase tracking-wider">
                  OVERALL
                </span>
              </div>

              <div>
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                  Selected Asset Assessment
                </span>
                <h4 className="text-base font-extrabold text-slate-900 mt-0.5">
                  {selectedItem.title}
                </h4>
                <p className="text-xs text-slate-500 mt-0.5">
                  Format: {selectedItem.type} · Evaluated against {campaign.brandVoice} tone standards
                </p>
              </div>
            </div>

            <button
              onClick={handleApplySuggestions}
              disabled={improving}
              className="flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 rounded-lg shadow-xs transition-colors cursor-pointer self-start md:self-auto"
            >
              <Wand2 className="w-4 h-4" />
              <span>{improving ? 'Applying AI Suggestions...' : 'Apply Suggested Improvements'}</span>
            </button>
          </div>

          {/* 6 Metric Breakdown Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {metricCards.map((m) => {
              const colorCls = getScoreColor(m.score);
              return (
                <div
                  key={m.label}
                  className="p-4 bg-white border border-slate-200 rounded-xl shadow-2xs space-y-2.5"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-800">{m.label}</span>
                    <span className={`text-xs font-black font-tabular px-2 py-0.5 rounded ${colorCls.split(' ')[0]} bg-slate-50`}>
                      {m.score}/100
                    </span>
                  </div>

                  <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full ${colorCls.split(' ')[1]} rounded-full`}
                      style={{ width: `${m.score}%` }}
                    />
                  </div>

                  <p className="text-[11px] text-slate-500 leading-snug">{m.desc}</p>
                </div>
              );
            })}
          </div>

          {/* Detailed Feedback: Strengths, Potential Issues, and Actionable Suggestions */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Strengths */}
            <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-2xs space-y-3">
              <div className="flex items-center gap-2 text-emerald-700">
                <CheckCircle2 className="w-4 h-4" />
                <h4 className="text-xs font-bold uppercase tracking-wider">
                  Strategic Strengths ({evalData.strengths.length})
                </h4>
              </div>
              <ul className="space-y-2 text-xs text-slate-700">
                {evalData.strengths.map((s, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-emerald-600 font-bold shrink-0">✓</span>
                    <span className="leading-relaxed">{s}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Potential Issues */}
            <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-2xs space-y-3">
              <div className="flex items-center gap-2 text-amber-700">
                <AlertTriangle className="w-4 h-4" />
                <h4 className="text-xs font-bold uppercase tracking-wider">
                  Potential Friction Points ({evalData.issues.length})
                </h4>
              </div>
              <ul className="space-y-2 text-xs text-slate-700">
                {evalData.issues.map((issue, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-amber-500 font-bold shrink-0">!</span>
                    <span className="leading-relaxed">{issue}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Suggestions */}
            <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-2xs space-y-3">
              <div className="flex items-center gap-2 text-indigo-700">
                <Lightbulb className="w-4 h-4" />
                <h4 className="text-xs font-bold uppercase tracking-wider">
                  Actionable Improvements ({evalData.suggestions.length})
                </h4>
              </div>
              <ul className="space-y-2 text-xs text-slate-700">
                {evalData.suggestions.map((sug, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-indigo-600 font-bold shrink-0">→</span>
                    <span className="leading-relaxed">{sug}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      ) : (
        <div className="py-16 text-center bg-white border border-slate-200 rounded-xl p-8 max-w-md mx-auto space-y-3">
          <BarChart2 className="w-8 h-8 text-indigo-600 mx-auto" />
          <h4 className="text-sm font-bold text-slate-900">Not Evaluated Yet</h4>
          <p className="text-xs text-slate-500">
            Run an AI evaluation audit on this content draft to get conversion and readability indicators.
          </p>
          <button
            onClick={handleReEvaluate}
            className="px-4 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg"
          >
            Run Evaluation Audit
          </button>
        </div>
      )}
    </div>
  );
}
