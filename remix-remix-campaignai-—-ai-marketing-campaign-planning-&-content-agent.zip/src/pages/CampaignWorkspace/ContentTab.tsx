import React, { useState } from 'react';
import {
  Sparkles,
  PenTool,
  Copy,
  Check,
  CheckCircle2,
  Trash2,
  History,
  RotateCcw,
  Wand2,
  Download,
  Share2,
  BarChart2,
} from 'lucide-react';
import type { Campaign, CampaignContent, ContentType } from '../../types.js';
import { api } from '../../services/api.js';
import { useToast } from '../../components/Toast.js';

interface ContentTabProps {
  campaign: Campaign;
  content: CampaignContent[];
  onContentUpdated: (content: CampaignContent[]) => void;
  onNavigateTab: (tab: string) => void;
}

export function ContentTab({
  campaign,
  content,
  onContentUpdated,
  onNavigateTab,
}: ContentTabProps) {
  const { showToast } = useToast();
  const [selectedContentId, setSelectedContentId] = useState<string>(content[0]?.id || '');
  const [generating, setGenerating] = useState(false);
  const [copied, setCopied] = useState(false);
  const [showImproveModal, setShowImproveModal] = useState(false);
  const [improveInstruction, setImproveInstruction] = useState('');
  const [improving, setImproving] = useState(false);

  // New Generation Form State
  const [selectedType, setSelectedType] = useState<ContentType>('Instagram Reel');
  const [targetPlatform, setTargetPlatform] = useState(campaign.primaryChannel);
  const [customTone, setCustomTone] = useState(campaign.brandVoice);
  const [contentLength, setContentLength] = useState<'short' | 'medium' | 'long'>('medium');
  const [keywords, setKeywords] = useState('');
  const [extraInstructions, setExtraInstructions] = useState('');

  const selectedItem = content.find((c) => c.id === selectedContentId) || content[0];

  const contentTypes: { group: string; types: ContentType[] }[] = [
    {
      group: 'Social Platforms',
      types: ['Instagram Reel', 'Instagram Post', 'Instagram Story', 'LinkedIn Post', 'Facebook Post', 'X Post'],
    },
    {
      group: 'Marketing Funnel Copy',
      types: ['Ad Copy', 'Email', 'Landing Page', 'Blog Article', 'Product Description', 'Headline', 'CTA'],
    },
  ];

  const handleGenerate = async () => {
    setGenerating(true);
    try {
      const created = await api.generateContent(campaign.id, {
        type: selectedType,
        platform: targetPlatform,
        tone: customTone,
        length: contentLength,
        keywords: keywords.split(',').map((k) => k.trim()).filter(Boolean),
        additionalInstructions: extraInstructions,
      });

      onContentUpdated([created, ...content]);
      setSelectedContentId(created.id);
      showToast(`${selectedType} generated & evaluated!`, 'success');
      setExtraInstructions('');
    } catch (err: any) {
      showToast(err.message || 'Content generation failed', 'error');
    } finally {
      setGenerating(false);
    }
  };

  const handleCopyBody = () => {
    if (!selectedItem) return;
    navigator.clipboard.writeText(selectedItem.body);
    setCopied(true);
    showToast('Copied content to clipboard', 'info');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleApprove = async () => {
    if (!selectedItem) return;
    try {
      const updated = await api.updateContent(campaign.id, selectedItem.id, { status: 'approved' });
      onContentUpdated(content.map((c) => (c.id === selectedItem.id ? updated : c)));
      showToast('Asset officially approved and saved to campaign memory!', 'success');
    } catch (e) {
      showToast('Approval failed', 'error');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this content draft?')) return;
    try {
      await api.deleteContent(campaign.id, id);
      const remaining = content.filter((c) => c.id !== id);
      onContentUpdated(remaining);
      if (selectedContentId === id) {
        setSelectedContentId(remaining[0]?.id || '');
      }
      showToast('Content removed', 'success');
    } catch (e) {
      showToast('Failed to delete content', 'error');
    }
  };

  const handleImproveWithAI = async () => {
    if (!selectedItem) return;
    setImproving(true);
    try {
      const improved = await api.improveContent(campaign.id, selectedItem.id, improveInstruction);
      onContentUpdated(content.map((c) => (c.id === selectedItem.id ? improved : c)));
      setShowImproveModal(false);
      setImproveInstruction('');
      showToast('Content successfully revised with AI!', 'success');
    } catch (e) {
      showToast('Improvement failed', 'error');
    } finally {
      setImproving(false);
    }
  };

  return (
    <div className="space-y-6 text-left">
      {/* Studio Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 bg-white border border-slate-200 rounded-xl shadow-2xs">
        <div>
          <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-600">
            Multi-Channel Content Studio
          </span>
          <h3 className="text-sm font-bold text-slate-900">
            Copy Generation & Version History ({content.length} Assets)
          </h3>
        </div>

        <div className="flex items-center gap-2">
          {selectedItem?.evaluation && (
            <button
              onClick={() => onNavigateTab('evaluation')}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg transition-colors cursor-pointer"
            >
              <BarChart2 className="w-3.5 h-3.5 text-emerald-600" />
              <span>Score: {selectedItem.evaluation.overallScore}/100</span>
            </button>
          )}

          {selectedItem && (
            <button
              onClick={handleApprove}
              disabled={selectedItem.status === 'approved'}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-lg shadow-2xs transition-colors cursor-pointer ${
                selectedItem.status === 'approved'
                  ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                  : 'bg-emerald-600 hover:bg-emerald-700 text-white'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>{selectedItem.status === 'approved' ? 'Approved ✓' : 'Approve Asset'}</span>
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column (4 cols): Generation Form & Asset Switcher */}
        <div className="lg:col-span-4 space-y-6">
          {/* New Asset Generator Card */}
          <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-2xs space-y-4">
            <div className="flex items-center gap-2 text-indigo-600">
              <Sparkles className="w-4 h-4" />
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900">
                Generate New Copy Asset
              </h4>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Content Type</label>
                <select
                  value={selectedType}
                  onChange={(e: any) => setSelectedType(e.target.value)}
                  className="w-full px-2.5 py-2 border border-slate-200 rounded-lg text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
                >
                  {contentTypes.map((grp) => (
                    <optgroup key={grp.group} label={grp.group}>
                      {grp.types.map((t) => (
                        <option key={t} value={t}>
                          {t}
                        </option>
                      ))}
                    </optgroup>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Target Tone</label>
                  <input
                    type="text"
                    value={customTone}
                    onChange={(e) => setCustomTone(e.target.value as any)}
                    className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg text-slate-800"
                    placeholder="e.g. Bold, Direct"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Length</label>
                  <select
                    value={contentLength}
                    onChange={(e: any) => setContentLength(e.target.value)}
                    className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg text-slate-800"
                  >
                    <option value="short">Short</option>
                    <option value="medium">Medium</option>
                    <option value="long">Long</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Target Keywords (optional)</label>
                <input
                  type="text"
                  value={keywords}
                  onChange={(e) => setKeywords(e.target.value)}
                  className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg text-slate-800"
                  placeholder="e.g. recovery, adaptive, velocity"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Specific Prompt or Hook Angle</label>
                <textarea
                  rows={2}
                  value={extraInstructions}
                  onChange={(e) => setExtraInstructions(e.target.value)}
                  className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
                  placeholder="e.g. Emphasize Apple Watch biometric sync..."
                />
              </div>

              <button
                onClick={handleGenerate}
                disabled={generating}
                className="w-full py-2.5 px-4 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 rounded-lg shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <Sparkles className="w-4 h-4" />
                <span>{generating ? 'Drafting Content...' : 'Generate Content Draft'}</span>
              </button>
            </div>
          </div>

          {/* Existing Content Drafts List */}
          <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-2xs space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900">
              Drafts in this Campaign ({content.length})
            </h4>

            <div className="space-y-2 max-h-[360px] overflow-y-auto">
              {content.map((item) => (
                <div
                  key={item.id}
                  onClick={() => setSelectedContentId(item.id)}
                  className={`p-3 rounded-lg border text-left cursor-pointer transition-all ${
                    selectedItem?.id === item.id
                      ? 'border-indigo-600 bg-indigo-50/50'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[11px] font-bold text-slate-900 truncate pr-2">
                      {item.title}
                    </span>
                    <span
                      className={`text-[10px] font-semibold px-1.5 py-0.5 rounded ${
                        item.status === 'approved'
                          ? 'text-emerald-700 bg-emerald-100/60'
                          : 'text-amber-700 bg-amber-100/60'
                      }`}
                    >
                      {item.status === 'approved' ? 'Approved' : 'Pending'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-500">
                    <span>{item.type}</span>
                    {item.evaluation && (
                      <span className="font-mono text-emerald-700 font-semibold">
                        {item.evaluation.overallScore}/100
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column (8 cols): Content Preview & Rich Actions */}
        <div className="lg:col-span-8 space-y-4">
          {selectedItem ? (
            <div className="p-6 bg-white border border-slate-200 rounded-xl shadow-2xs space-y-4 text-left">
              {/* Asset Title Bar */}
              <div className="flex items-start justify-between gap-4 border-b border-slate-100 pb-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded">
                      {selectedItem.type}
                    </span>
                    <span className="text-slate-300">·</span>
                    <span className="text-xs text-slate-500">{selectedItem.platform || campaign.primaryChannel}</span>
                  </div>
                  <h3 className="text-base font-extrabold text-slate-900">
                    {selectedItem.title}
                  </h3>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={handleCopyBody}
                    className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
                    title="Copy copy to clipboard"
                  >
                    {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                  </button>

                  <button
                    onClick={() => setShowImproveModal(true)}
                    className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition-colors cursor-pointer"
                  >
                    <Wand2 className="w-3.5 h-3.5" />
                    <span>Improve with AI</span>
                  </button>

                  <button
                    onClick={() => handleDelete(selectedItem.id)}
                    className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                    title="Delete Draft"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Headline Bar if present */}
              {selectedItem.headline && (
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                  <span className="text-[10px] font-bold text-slate-400 uppercase block mb-0.5">
                    Headline / Subject Line / Hook
                  </span>
                  <p className="text-xs font-bold text-slate-800">
                    {selectedItem.headline}
                  </p>
                </div>
              )}

              {/* Main Body */}
              <div className="p-4 rounded-lg bg-slate-50/60 border border-slate-200">
                <span className="text-[10px] font-bold text-slate-400 uppercase block mb-2">
                  Publication Copy
                </span>
                <div className="text-xs text-slate-800 whitespace-pre-wrap leading-relaxed font-sans">
                  {selectedItem.body}
                </div>
              </div>

              {/* CTA footer */}
              {selectedItem.callToAction && (
                <div className="p-3 bg-indigo-50/50 border border-indigo-100 rounded-lg flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-bold text-indigo-700 uppercase block">
                      Call to Action
                    </span>
                    <span className="text-xs font-bold text-indigo-950">
                      {selectedItem.callToAction}
                    </span>
                  </div>
                  <span className="text-[11px] font-semibold text-indigo-600">Active CTA Target</span>
                </div>
              )}

              {/* Versions History */}
              {selectedItem.versions && selectedItem.versions.length > 0 && (
                <div className="pt-4 border-t border-slate-100">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700 mb-2">
                    <History className="w-3.5 h-3.5 text-slate-400" />
                    <span>Version History ({selectedItem.versions.length} revisions)</span>
                  </div>
                  <div className="space-y-1.5">
                    {selectedItem.versions.map((ver) => (
                      <div
                        key={ver.id}
                        className="p-2.5 rounded-md bg-slate-50 border border-slate-200 text-xs flex items-center justify-between"
                      >
                        <div className="truncate pr-4">
                          <span className="font-semibold text-slate-800">v{ver.versionNumber}</span>
                          <span className="text-slate-400 mx-2">·</span>
                          <span className="text-slate-500 italic">{ver.note || 'Revised draft'}</span>
                        </div>
                        <span className="text-[10px] text-slate-400 font-tabular shrink-0">
                          {new Date(ver.createdAt).toLocaleTimeString()}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="p-12 text-center bg-white border border-slate-200 rounded-xl">
              <PenTool className="w-8 h-8 text-slate-300 mx-auto mb-2" />
              <p className="text-xs text-slate-500">No content asset selected.</p>
            </div>
          )}
        </div>
      </div>

      {/* Improve with AI Modal */}
      {showImproveModal && selectedItem && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl p-6 max-w-lg w-full shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <Wand2 className="w-4 h-4 text-indigo-600" />
                <h4 className="text-sm font-bold text-slate-900">Improve Draft with AI</h4>
              </div>
              <button onClick={() => setShowImproveModal(false)} className="text-slate-400 hover:text-slate-700">
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-600">
              Provide instructions to enhance this {selectedItem.type}. The evaluator report and brand guidelines will be applied automatically.
            </p>

            <div className="space-y-2">
              <textarea
                rows={3}
                value={improveInstruction}
                onChange={(e) => setImproveInstruction(e.target.value)}
                placeholder="e.g. Make the hook more urgent, shorten the middle paragraph, and emphasize the 30-day money back guarantee..."
                className="w-full p-3 text-xs border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setShowImproveModal(false)}
                className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-900"
              >
                Cancel
              </button>
              <button
                onClick={handleImproveWithAI}
                disabled={improving}
                className="px-4 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 rounded-lg shadow-xs"
              >
                {improving ? 'Rewriting...' : 'Apply AI Improvement'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
