import React, { useState } from 'react';
import {
  Plus,
  Sparkles,
  Clock,
  User,
  Trash2,
  CheckCircle2,
  AlertCircle,
  MoreVertical,
  X,
} from 'lucide-react';
import type { CampaignTask, TaskPriority, TaskStatus } from '../../types.js';
import { api } from '../../services/api.js';
import { useToast } from '../../components/Toast.js';

interface TasksTabProps {
  campaignId: string;
  tasks: CampaignTask[];
  onTasksUpdated: (tasks: CampaignTask[]) => void;
  onDecompose: () => void;
  decomposing: boolean;
}

export function TasksTab({
  campaignId,
  tasks,
  onTasksUpdated,
  onDecompose,
  decomposing,
}: TasksTabProps) {
  const { showToast } = useToast();
  const [showAddModal, setShowAddModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newPriority, setNewPriority] = useState<TaskPriority>('medium');
  const [newStatus, setNewStatus] = useState<TaskStatus>('todo');
  const [newDueDate, setNewDueDate] = useState(new Date().toISOString().split('T')[0]);
  const [newAssignee, setNewAssignee] = useState('Marketing Lead');

  const columns: { status: TaskStatus; label: string; count: number }[] = [
    { status: 'todo', label: 'To Do', count: tasks.filter((t) => t.status === 'todo').length },
    { status: 'in_progress', label: 'In Progress', count: tasks.filter((t) => t.status === 'in_progress').length },
    { status: 'review', label: 'In Review', count: tasks.filter((t) => t.status === 'review').length },
    { status: 'done', label: 'Done', count: tasks.filter((t) => t.status === 'done').length },
  ];

  const handleStatusChange = async (taskId: string, targetStatus: TaskStatus) => {
    try {
      const updated = await api.updateTask(campaignId, taskId, { status: targetStatus });
      onTasksUpdated(tasks.map((t) => (t.id === taskId ? updated : t)));
      showToast(`Task moved to ${targetStatus.replace('_', ' ')}`, 'info');
    } catch (e) {
      showToast('Failed to update task', 'error');
    }
  };

  const handleDeleteTask = async (taskId: string) => {
    if (!confirm('Delete this task?')) return;
    try {
      await api.deleteTask(campaignId, taskId);
      onTasksUpdated(tasks.filter((t) => t.id !== taskId));
      showToast('Task removed', 'success');
    } catch (e) {
      showToast('Failed to delete task', 'error');
    }
  };

  const handleCreateTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    try {
      const created = await api.createTask(campaignId, {
        title: newTitle,
        description: newDesc,
        priority: newPriority,
        status: newStatus,
        dueDate: newDueDate,
        aiGenerated: false,
        dependencies: [],
        assignee: newAssignee,
      });
      onTasksUpdated([...tasks, created]);
      setShowAddModal(false);
      setNewTitle('');
      setNewDesc('');
      showToast('Task created successfully', 'success');
    } catch (e) {
      showToast('Failed to create task', 'error');
    }
  };

  const getPriorityStyle = (p: TaskPriority) => {
    switch (p) {
      case 'urgent':
        return 'text-rose-700 bg-rose-50 border-rose-200';
      case 'high':
        return 'text-amber-700 bg-amber-50 border-amber-200';
      case 'medium':
        return 'text-indigo-700 bg-indigo-50 border-indigo-200';
      case 'low':
        return 'text-slate-600 bg-slate-50 border-slate-200';
    }
  };

  return (
    <div className="space-y-6 text-left">
      {/* Task Board Action Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 bg-white border border-slate-200 rounded-xl shadow-2xs">
        <div>
          <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-600">
            Agile Execution Board
          </span>
          <h3 className="text-sm font-bold text-slate-900">
            Operational Workstreams ({tasks.length} Total Tasks)
          </h3>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onDecompose}
            disabled={decomposing}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors cursor-pointer"
          >
            <Sparkles className={`w-3.5 h-3.5 ${decomposing ? 'animate-spin text-indigo-600' : 'text-indigo-600'}`} />
            <span>{decomposing ? 'Decomposing Tasks...' : 'Generate Tasks from Strategy'}</span>
          </button>

          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-2xs transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Task</span>
          </button>
        </div>
      </div>

      {/* Kanban Board Columns */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-start">
        {columns.map((col) => {
          const colTasks = tasks.filter((t) => t.status === col.status);

          return (
            <div
              key={col.status}
              className="bg-slate-50/80 border border-slate-200 rounded-xl p-3.5 flex flex-col min-h-[480px]"
            >
              {/* Column Header */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-200/80 mb-3">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-900">{col.label}</span>
                  <span className="px-1.5 py-0.5 text-[10px] font-mono font-bold bg-white text-slate-600 border border-slate-200 rounded-md">
                    {col.count}
                  </span>
                </div>
              </div>

              {/* Tasks List */}
              <div className="space-y-3 flex-1 overflow-y-auto">
                {colTasks.length === 0 ? (
                  <div className="py-12 text-center text-slate-400 text-xs italic">
                    No tasks in {col.label.toLowerCase()}
                  </div>
                ) : (
                  colTasks.map((task) => (
                    <div
                      key={task.id}
                      className="p-4 bg-white border border-slate-200 rounded-lg shadow-2xs hover:border-indigo-300 transition-all space-y-2 group"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <span
                          className={`text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded border ${getPriorityStyle(
                            task.priority
                          )}`}
                        >
                          {task.priority}
                        </span>

                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button
                            onClick={() => handleDeleteTask(task.id)}
                            className="p-1 text-slate-300 hover:text-rose-600 rounded transition-colors"
                            title="Delete task"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      <h4 className="text-xs font-bold text-slate-900 leading-snug">
                        {task.title}
                      </h4>

                      <p className="text-[11px] text-slate-500 line-clamp-2 leading-relaxed">
                        {task.description}
                      </p>

                      {task.relatedContentType && (
                        <div className="text-[10px] text-indigo-700 bg-indigo-50/70 px-2 py-0.5 rounded w-fit font-medium">
                          Asset: {task.relatedContentType}
                        </div>
                      )}

                      <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                        <span className="flex items-center gap-1 font-tabular">
                          <Clock className="w-3 h-3" />
                          {task.dueDate}
                        </span>

                        <span className="truncate max-w-[110px] text-slate-600 font-medium">
                          {task.assignee}
                        </span>
                      </div>

                      {/* Status Selector Dropdown */}
                      <div className="pt-2 flex items-center justify-between">
                        <span className="text-[10px] text-slate-400">Move to:</span>
                        <select
                          value={task.status}
                          onChange={(e) => handleStatusChange(task.id, e.target.value as TaskStatus)}
                          className="text-[10px] font-medium bg-slate-50 border border-slate-200 rounded px-1.5 py-0.5 text-slate-700 focus:outline-hidden"
                        >
                          <option value="todo">To Do</option>
                          <option value="in_progress">In Progress</option>
                          <option value="review">Review</option>
                          <option value="done">Done</option>
                        </select>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Task Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl p-6 max-w-md w-full shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h4 className="text-sm font-bold text-slate-900">Add Operational Task</h4>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-700">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateTask} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Task Title *</label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Script and record founder teaser video"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Description</label>
                <textarea
                  rows={2}
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  placeholder="Acceptance criteria and deliverables..."
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Priority</label>
                  <select
                    value={newPriority}
                    onChange={(e: any) => setNewPriority(e.target.value)}
                    className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg text-slate-800"
                  >
                    <option value="urgent">Urgent</option>
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                    <option value="low">Low</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Column</label>
                  <select
                    value={newStatus}
                    onChange={(e: any) => setNewStatus(e.target.value)}
                    className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg text-slate-800"
                  >
                    <option value="todo">To Do</option>
                    <option value="in_progress">In Progress</option>
                    <option value="review">Review</option>
                    <option value="done">Done</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Due Date</label>
                  <input
                    type="date"
                    value={newDueDate}
                    onChange={(e) => setNewDueDate(e.target.value)}
                    className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg text-slate-800"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Assignee</label>
                  <input
                    type="text"
                    value={newAssignee}
                    onChange={(e) => setNewAssignee(e.target.value)}
                    className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg text-slate-800"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs"
                >
                  Create Task
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
