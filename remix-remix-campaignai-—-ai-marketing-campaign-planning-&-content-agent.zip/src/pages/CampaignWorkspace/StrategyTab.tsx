import React, { useState } from 'react';
import {
  Sparkles,
  RefreshCw,
  Edit2,
  Check,
  Target,
  Layers,
  Flame,
  TrendingUp,
  MessageSquare,
  Compass,
} from 'lucide-react';
import type { Campaign, CampaignStrategy } from '../../types.js';
import { api } from '../../services/api.js';
import { useToast } from '../../components/Toast.js';

interface StrategyTabProps {
  campaign: Campaign;
  strategy: CampaignStrategy | null;
  onStrategyUpdated: (newStrat: CampaignStrategy) => void;
  onDecomposeTasks: () => void;
  decomposing: boolean;
}

export function StrategyTab({
  campaign,
  strategy,
  onStrategyUpdated,
  onDecomposeTasks,
  decomposing,
}: StrategyTabProps) {
  const { showToast } = useToast();
  const [regenerating, setRegenerating] = useState(false);
  const [editingPillars, setEditingPillars] = useState(false);
  const [pillarsInput, setPillarsInput] = useState(strategy?.contentPillars.join('\n') || '');

  const handleRegenerate = async () => {
    setRegenerating(true);
    try {
      const generated = await api.generateStrategy(campaign.id);
      onStrategyUpdated(generated);
      showToast('AI Strategy regenerated with updated intelligence!', 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to regenerate strategy', 'error');
    } finally {
      setRegenerating(false);
    }
  };

  const handleSavePillars = async () => {
    if (!strategy) return;
    const newPillars = pillarsInput.split('\n').map((p) => p.trim()).filter(Boolean);
    try {
      const updated = await api.updateStrategy(campaign.id, { contentPillars: newPillars });
      onStrategyUpdated(updated);
      setEditingPillars(false);
      showToast('Content pillars updated', 'success');
    } catch (e) {
      showToast('Failed to update pillars', 'error');
    }
  };

  if (!strategy) {
    return (
      <div className="py-16 text-center bg-white border border-slate-200 rounded-xl p-8 max-w-md mx-auto space-y-4">
        <Sparkles className="w-10 h-10 text-indigo-500 mx-auto" />
        <h3 className="text-sm font-bold text-slate-900">No Strategy Generated Yet</h3>
        <p className="text-xs text-slate-500">
          Synthesize full-funnel positioning, core messages, and content pillars for this campaign.
        </p>
        <button
          onClick={handleRegenerate}
          disabled={regenerating}
          className="px-5 py-2.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 rounded-lg shadow-xs transition-colors cursor-pointer"
        >
          {regenerating ? 'Synthesizing...' : 'Generate AI Strategy'}
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6 text-left">
      {/* Strategy Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 bg-white border border-slate-200 rounded-xl shadow-2xs">
        <div>
          <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-600">
            Campaign Blueprint
          </span>
          <h3 className="text-sm font-bold text-slate-900">
            Strategic Architecture & Funnel Decomposition
          </h3>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleRegenerate}
            disabled={regenerating}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${regenerating ? 'animate-spin text-indigo-600' : 'text-slate-500'}`} />
            <span>{regenerating ? 'Regenerating...' : 'Regenerate Strategy'}</span>
          </button>

          <button
            onClick={onDecomposeTasks}
            disabled={decomposing}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 rounded-lg shadow-2xs transition-colors cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{decomposing ? 'Decomposing...' : 'Decompose into Tasks'}</span>
          </button>
        </div>
      </div>

      {/* Grid of Strategy Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Core Theme & Positioning */}
        <div className="p-6 bg-white border border-slate-200 rounded-xl shadow-2xs space-y-4">
          <div className="flex items-center gap-2 text-indigo-600">
            <Compass className="w-4 h-4" />
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900">
              Creative Theme & Market Positioning
            </h4>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <span className="text-[11px] font-bold text-slate-500 block mb-0.5">Campaign Theme</span>
              <p className="text-sm font-extrabold text-indigo-900 bg-indigo-50/70 p-3 rounded-lg border border-indigo-100">
                "{strategy.campaignTheme}"
              </p>
            </div>

            <div>
              <span className="text-[11px] font-bold text-slate-500 block mb-0.5">Core Narrative Anchor</span>
              <p className="text-xs font-medium text-slate-800 bg-slate-50 p-3 rounded-lg">
                {strategy.coreMessage}
              </p>
            </div>

            <div>
              <span className="text-[11px] font-bold text-slate-500 block mb-0.5">Market Positioning</span>
              <p className="text-xs text-slate-700 leading-relaxed bg-slate-50 p-3 rounded-lg">
                {strategy.positioning}
              </p>
            </div>
          </div>
        </div>

        {/* Objective & Persona Alignment */}
        <div className="p-6 bg-white border border-slate-200 rounded-xl shadow-2xs space-y-4">
          <div className="flex items-center gap-2 text-indigo-600">
            <Target className="w-4 h-4" />
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900">
              Objective & Audience Resonance
            </h4>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <span className="text-[11px] font-bold text-slate-500 block mb-0.5">Strategic Objective</span>
              <p className="text-xs font-medium text-slate-800 bg-slate-50 p-3 rounded-lg">
                {strategy.objective}
              </p>
            </div>

            <div>
              <span className="text-[11px] font-bold text-slate-500 block mb-0.5">Target Audience Persona</span>
              <p className="text-xs text-slate-700 leading-relaxed bg-slate-50 p-3 rounded-lg">
                {strategy.targetAudience}
              </p>
            </div>

            <div>
              <span className="text-[11px] font-bold text-slate-500 block mb-0.5">Refined Value Proposition</span>
              <p className="text-xs font-medium text-slate-800 bg-slate-50 p-3 rounded-lg">
                "{strategy.valueProposition}"
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Full Marketing Funnel Card */}
      <div className="p-6 bg-white border border-slate-200 rounded-xl shadow-2xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-indigo-600">
            <Layers className="w-4 h-4" />
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900">
              Full-Funnel Activation Architecture
            </h4>
          </div>
          <span className="text-[11px] text-slate-400">TOFU → MOFU → BOFU</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-indigo-700 text-xs">Top of Funnel (Awareness)</span>
              <span className="text-[10px] uppercase font-mono text-slate-400">TOFU</span>
            </div>
            <p className="text-xs text-slate-700 leading-relaxed">
              {strategy.marketingFunnel.top}
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-indigo-700 text-xs">Middle of Funnel (Consideration)</span>
              <span className="text-[10px] uppercase font-mono text-slate-400">MOFU</span>
            </div>
            <p className="text-xs text-slate-700 leading-relaxed">
              {strategy.marketingFunnel.middle}
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-indigo-700 text-xs">Bottom of Funnel (Conversion)</span>
              <span className="text-[10px] uppercase font-mono text-slate-400">BOFU</span>
            </div>
            <p className="text-xs text-slate-700 leading-relaxed">
              {strategy.marketingFunnel.bottom}
            </p>
          </div>
        </div>
      </div>

      {/* Content Pillars & CTA Strategy */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Content Pillars */}
        <div className="p-6 bg-white border border-slate-200 rounded-xl shadow-2xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-indigo-600">
              <Flame className="w-4 h-4" />
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900">
                Core Content Pillars
              </h4>
            </div>
            <button
              onClick={() => {
                if (editingPillars) handleSavePillars();
                else setEditingPillars(true);
              }}
              className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
            >
              {editingPillars ? <Check className="w-3.5 h-3.5" /> : <Edit2 className="w-3.5 h-3.5" />}
              <span>{editingPillars ? 'Save Pillars' : 'Edit'}</span>
            </button>
          </div>

          {editingPillars ? (
            <textarea
              rows={4}
              value={pillarsInput}
              onChange={(e) => setPillarsInput(e.target.value)}
              className="w-full p-3 text-xs border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500 font-sans"
              placeholder="One content pillar per line..."
            />
          ) : (
            <div className="space-y-2.5">
              {strategy.contentPillars.map((pillar, idx) => (
                <div
                  key={idx}
                  className="p-3 rounded-lg bg-slate-50 border border-slate-100 flex items-start gap-2.5 text-xs"
                >
                  <span className="font-mono text-indigo-600 font-bold">0{idx + 1}.</span>
                  <span className="font-medium text-slate-800">{pillar}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* CTA Strategy & KPIs */}
        <div className="p-6 bg-white border border-slate-200 rounded-xl shadow-2xs space-y-4">
          <div className="flex items-center gap-2 text-indigo-600">
            <TrendingUp className="w-4 h-4" />
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900">
              CTA Strategy & Measurable KPIs
            </h4>
          </div>

          <div className="space-y-4 text-xs">
            <div>
              <span className="text-[11px] font-bold text-slate-500 block mb-1">
                Conversion Call-to-Action Strategy
              </span>
              <p className="text-xs font-medium text-slate-800 bg-slate-50 p-3 rounded-lg leading-relaxed">
                {strategy.ctaStrategy}
              </p>
            </div>

            <div>
              <span className="text-[11px] font-bold text-slate-500 block mb-1">
                Key Performance Indicators (KPIs)
              </span>
              <div className="space-y-1.5">
                {strategy.kpis.map((kpi, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-slate-700">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                    <span>{kpi}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
