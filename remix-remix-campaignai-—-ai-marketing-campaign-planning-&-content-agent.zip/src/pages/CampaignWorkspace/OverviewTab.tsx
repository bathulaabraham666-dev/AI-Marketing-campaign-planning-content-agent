import React from 'react';
import {
  Target,
  Users,
  Calendar,
  DollarSign,
  Share2,
  CheckCircle2,
  TrendingUp,
  FileText,
  Clock,
  Sparkles,
  ArrowRight,
  ShieldAlert,
} from 'lucide-react';
import type { Campaign, CampaignStrategy, CampaignTask, CampaignContent, WorkflowRun } from '../../types.js';

interface OverviewTabProps {
  campaign: Campaign;
  strategy: CampaignStrategy | null;
  tasks: CampaignTask[];
  content: CampaignContent[];
  workflow: WorkflowRun | null;
  onNavigateTab: (tab: string) => void;
  onRunWorkflow: () => void;
  runningWorkflow: boolean;
}

export function OverviewTab({
  campaign,
  strategy,
  tasks,
  content,
  workflow,
  onNavigateTab,
  onRunWorkflow,
  runningWorkflow,
}: OverviewTabProps) {
  const completedTasks = tasks.filter((t) => t.status === 'done').length;
  const approvedContent = content.filter((c) => c.status === 'approved').length;

  const evals = content.map((c) => c.evaluation?.overallScore).filter(Boolean) as number[];
  const avgScore = evals.length > 0 ? Math.round(evals.reduce((a, b) => a + b, 0) / evals.length) : 92;

  const journeySteps = [
    { title: 'Research', desc: 'Market & audience audit', done: true },
    { title: 'Strategy', desc: 'Full-funnel blueprint', done: !!strategy },
    { title: 'Tasks', desc: `${tasks.length} active workstreams`, done: tasks.length > 0 },
    { title: 'Content', desc: `${content.length} drafted assets`, done: content.length > 0 },
    { title: 'Evaluation', desc: `${avgScore}/100 quality benchmark`, done: evals.length > 0 },
    { title: 'Approval', desc: `${approvedContent} signed off`, done: approvedContent > 0 },
  ];

  return (
    <div className="space-y-8 text-left">
      {/* Visual Campaign Journey Stepper */}
      <div className="p-6 bg-white border border-slate-200 rounded-xl shadow-2xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Campaign Execution Journey</h3>
            <p className="text-xs text-slate-500">Autonomous progression through strategic planning milestones.</p>
          </div>
          <button
            onClick={onRunWorkflow}
            disabled={runningWorkflow}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 rounded-lg shadow-2xs transition-colors cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{runningWorkflow ? 'Running Engine...' : 'Re-Run AI Workflow'}</span>
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 pt-2">
          {journeySteps.map((step, idx) => (
            <div
              key={step.title}
              className={`p-3 rounded-lg border text-left flex flex-col justify-between ${
                step.done
                  ? 'border-indigo-200 bg-indigo-50/40'
                  : 'border-slate-200 bg-slate-50/50'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[10px] font-mono font-bold text-slate-400">
                    0{idx + 1}
                  </span>
                  {step.done ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  ) : (
                    <div className="w-2.5 h-2.5 rounded-full border border-slate-300" />
                  )}
                </div>
                <h4 className="text-xs font-bold text-slate-900">{step.title}</h4>
                <p className="text-[11px] text-slate-500 mt-0.5">{step.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div
          onClick={() => onNavigateTab('tasks')}
          className="p-5 bg-white border border-slate-200 rounded-xl hover:border-slate-300 transition-colors cursor-pointer"
        >
          <span className="text-xs font-semibold text-slate-500 block">Tasks Completed</span>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-slate-900 font-tabular">
              {completedTasks} / {tasks.length}
            </span>
            <span className="text-xs text-slate-400">milestones</span>
          </div>
          <div className="mt-2 h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
            <div
              className="h-full bg-emerald-500"
              style={{ width: `${tasks.length ? (completedTasks / tasks.length) * 100 : 0}%` }}
            />
          </div>
        </div>

        <div
          onClick={() => onNavigateTab('content')}
          className="p-5 bg-white border border-slate-200 rounded-xl hover:border-slate-300 transition-colors cursor-pointer"
        >
          <span className="text-xs font-semibold text-slate-500 block">Content Assets</span>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-slate-900 font-tabular">
              {content.length}
            </span>
            <span className="text-xs text-indigo-600 font-medium">{approvedContent} approved</span>
          </div>
          <span className="text-[11px] text-slate-400 block mt-2">
            Ready for multi-channel publishing
          </span>
        </div>

        <div
          onClick={() => onNavigateTab('evaluation')}
          className="p-5 bg-white border border-slate-200 rounded-xl hover:border-slate-300 transition-colors cursor-pointer"
        >
          <span className="text-xs font-semibold text-slate-500 block">AI Quality Index</span>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-slate-900 font-tabular">
              {avgScore}
            </span>
            <span className="text-xs text-slate-400">/ 100 benchmark</span>
          </div>
          <span className="text-[11px] text-emerald-600 font-medium block mt-2">
            Evaluated on 6 conversion factors
          </span>
        </div>

        <div className="p-5 bg-white border border-slate-200 rounded-xl">
          <span className="text-xs font-semibold text-slate-500 block">Budget & Velocity</span>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-slate-900 font-tabular">
              {campaign.budget}
            </span>
            <span className="text-xs text-slate-400">· {campaign.durationDays}d</span>
          </div>
          <span className="text-[11px] text-slate-400 block mt-2 font-tabular">
            {campaign.startDate} → {campaign.endDate}
          </span>
        </div>
      </div>

      {/* Two Column Section: Strategic Core & Channel Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Objective & Target Audience */}
        <div className="lg:col-span-2 space-y-6">
          <div className="p-6 bg-white border border-slate-200 rounded-xl shadow-2xs space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900">Campaign Directive</h3>
              <button
                onClick={() => onNavigateTab('strategy')}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800"
              >
                View Full Strategy →
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3.5 bg-slate-50 rounded-lg">
                <span className="text-[11px] font-bold text-slate-500 uppercase block mb-1">
                  Primary Objective
                </span>
                <p className="text-xs font-medium text-slate-800">
                  {campaign.primaryObjective}
                </p>
              </div>

              <div className="p-3.5 bg-slate-50 rounded-lg">
                <span className="text-[11px] font-bold text-slate-500 uppercase block mb-1">
                  Value Proposition
                </span>
                <p className="text-xs font-medium text-slate-800">
                  "{campaign.valueProposition}"
                </p>
              </div>

              <div className="p-3.5 bg-slate-50 rounded-lg">
                <span className="text-[11px] font-bold text-slate-500 uppercase block mb-1">
                  Target Audience Persona
                </span>
                <p className="text-xs text-slate-700 leading-relaxed">
                  <strong>Role:</strong> {campaign.audienceOccupation}<br />
                  <strong>Demographics:</strong> {campaign.audienceAgeRange} · {campaign.audienceLocation}<br />
                  <strong>Core Pain:</strong> {campaign.audiencePainPoints}
                </p>
              </div>
            </div>
          </div>

          {/* Target KPIs */}
          {strategy && strategy.kpis && strategy.kpis.length > 0 && (
            <div className="p-6 bg-white border border-slate-200 rounded-xl shadow-2xs space-y-3">
              <h3 className="text-sm font-bold text-slate-900">Target Key Performance Indicators (KPIs)</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                {strategy.kpis.map((kpi, idx) => (
                  <div key={idx} className="p-3 rounded-lg border border-slate-200 bg-slate-50 flex items-start gap-2.5">
                    <Target className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                    <span className="text-xs font-medium text-slate-800">{kpi}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Channels & AI Workflow Log */}
        <div className="space-y-6">
          <div className="p-6 bg-white border border-slate-200 rounded-xl shadow-2xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900">Distribution Channels</h3>
            <div className="space-y-2.5">
              <div className="flex items-center justify-between p-2.5 bg-indigo-50/60 rounded-lg text-xs">
                <span className="font-semibold text-indigo-900">Primary: {campaign.primaryChannel}</span>
                <span className="text-[10px] uppercase font-bold text-indigo-700 bg-white px-2 py-0.5 rounded shadow-2xs">
                  Active Focus
                </span>
              </div>
              {campaign.secondaryChannels.map((sec) => (
                <div key={sec} className="flex items-center justify-between p-2.5 bg-slate-50 rounded-lg text-xs text-slate-700">
                  <span>{sec}</span>
                  <span className="text-[11px] text-slate-400">Secondary</span>
                </div>
              ))}
            </div>

            <div className="pt-3 border-t border-slate-100 text-xs text-slate-500">
              <span>Brand Tone: </span>
              <strong className="text-slate-800">{campaign.brandVoice}</strong>
              {campaign.customBrandVoice && (
                <p className="text-[11px] text-slate-500 mt-1 italic">
                  "{campaign.customBrandVoice}"
                </p>
              )}
            </div>
          </div>

          {/* Sequential Workflow Status Log */}
          {workflow && (
            <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-2xs space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-900">AI Workflow Engine</span>
                <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                  {workflow.status}
                </span>
              </div>

              <div className="space-y-2 text-[11px]">
                {workflow.steps.slice(0, 5).map((s) => (
                  <div key={s.id} className="flex items-center justify-between text-slate-600">
                    <span className="truncate pr-2">{s.name}</span>
                    <span className="font-mono text-emerald-600 font-bold shrink-0">✓ Completed</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
