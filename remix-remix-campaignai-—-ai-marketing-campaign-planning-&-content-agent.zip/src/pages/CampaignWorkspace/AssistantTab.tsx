import React, { useEffect, useRef, useState } from 'react';
import {
  Send,
  Bot,
  User,
  Sparkles,
  Trash2,
  Brain,
  Layers,
  ArrowRight,
} from 'lucide-react';
import type { Campaign, ChatMessage } from '../../types.js';
import { api } from '../../services/api.js';
import { useToast } from '../../components/Toast.js';

interface AssistantTabProps {
  campaign: Campaign;
}

export function AssistantTab({ campaign }: AssistantTabProps) {
  const { showToast } = useToast();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const loadChat = async () => {
    try {
      const history = await api.getChat(campaign.id);
      if (history.length === 0) {
        setMessages([
          {
            id: 'msg_welcome',
            campaignId: campaign.id,
            role: 'assistant',
            content: `I am your dedicated strategist for **${campaign.name}**.\n\nI have complete contextual memory over your objective (*${campaign.goal}*), distribution channel (*${campaign.primaryChannel}*), and brand voice (*${campaign.brandVoice}*).\n\nAsk me to brainstorm alternative themes, refine copy hooks, or adjust campaign strategy.`,
            timestamp: new Date().toISOString(),
            suggestedActions: [
              'Make this campaign more professional',
              'Suggest 3 alternative campaign themes',
              'Give me a stronger email CTA hook',
              'Review overall campaign readiness',
            ],
          },
        ]);
      } else {
        setMessages(history);
      }
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    loadChat();
  }, [campaign.id]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async (messageText?: string) => {
    const textToSend = messageText || input;
    if (!textToSend.trim() || sending) return;

    const userMsg: ChatMessage = {
      id: `msg_u_${Date.now()}`,
      campaignId: campaign.id,
      role: 'user',
      content: textToSend,
      timestamp: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setSending(true);

    try {
      const assistantMsg = await api.sendMessage(campaign.id, textToSend);
      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err: any) {
      showToast(err.message || 'Assistant failed to respond', 'error');
    } finally {
      setSending(false);
    }
  };

  const handleClear = async () => {
    if (!confirm('Clear conversation history?')) return;
    try {
      await api.clearChat(campaign.id);
      showToast('Chat history cleared', 'info');
      loadChat();
    } catch (e) {
      showToast('Failed to clear chat', 'error');
    }
  };

  const latestAssistantMessage = [...messages].reverse().find((m) => m.role === 'assistant');
  const suggestions = latestAssistantMessage?.suggestedActions || [
    'Make this campaign more professional',
    'Suggest 3 alternative campaign themes',
    'Review conversion bottleneck in landing page',
  ];

  return (
    <div className="space-y-4 text-left max-w-4xl mx-auto">
      {/* Context Bar */}
      <div className="p-3.5 bg-white border border-slate-200 rounded-xl shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 text-indigo-700 font-semibold">
          <Brain className="w-4 h-4 text-indigo-600" />
          <span>Active Strategic Grounding:</span>
          <span className="text-slate-600 font-normal truncate max-w-xs sm:max-w-md">
            {campaign.name} · {campaign.goal} · {campaign.brandVoice}
          </span>
        </div>

        <button
          onClick={handleClear}
          className="text-slate-400 hover:text-rose-600 flex items-center gap-1 self-end sm:self-auto transition-colors"
          title="Clear chat history"
        >
          <Trash2 className="w-3.5 h-3.5" />
          <span>Clear Chat</span>
        </button>
      </div>

      {/* Chat Messages Log */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-6 shadow-2xs min-h-[460px] max-h-[560px] flex flex-col justify-between">
        <div className="overflow-y-auto space-y-4 pr-1 flex-1">
          {messages.map((msg) => {
            const isUser = msg.role === 'user';

            return (
              <div
                key={msg.id}
                className={`flex gap-3 text-xs leading-relaxed ${
                  isUser ? 'justify-end' : 'justify-start'
                }`}
              >
                {!isUser && (
                  <div className="w-7 h-7 rounded-lg bg-indigo-600 text-white flex items-center justify-center shrink-0 mt-0.5 shadow-2xs">
                    <Bot className="w-4 h-4" />
                  </div>
                )}

                <div
                  className={`p-3.5 rounded-xl max-w-lg whitespace-pre-wrap ${
                    isUser
                      ? 'bg-indigo-600 text-white font-medium rounded-tr-xs'
                      : 'bg-slate-50 border border-slate-200 text-slate-900 rounded-tl-xs'
                  }`}
                >
                  {msg.content}
                </div>

                {isUser && (
                  <div className="w-7 h-7 rounded-full bg-slate-900 text-white flex items-center justify-center shrink-0 mt-0.5 text-[11px] font-bold">
                    U
                  </div>
                )}
              </div>
            );
          })}

          {sending && (
            <div className="flex items-center gap-3 text-xs text-slate-500 italic pl-10">
              <Sparkles className="w-3.5 h-3.5 text-indigo-500 animate-spin" />
              <span>Strategist is synthesizing context & memories...</span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Suggested Prompts */}
        <div className="pt-4 border-t border-slate-100 mt-4 space-y-2">
          <div className="flex flex-wrap gap-1.5">
            {suggestions.map((promptText, i) => (
              <button
                key={i}
                onClick={() => handleSend(promptText)}
                className="px-2.5 py-1 text-[11px] bg-indigo-50 hover:bg-indigo-100 text-indigo-800 rounded-md transition-colors text-left flex items-center gap-1 cursor-pointer"
              >
                <span>{promptText}</span>
                <ArrowRight className="w-2.5 h-2.5 opacity-60" />
              </button>
            ))}
          </div>

          {/* Input Box */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-center gap-2 pt-1"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={`Ask anything about ${campaign.name}...`}
              className="flex-1 px-3.5 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:bg-white focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
            />
            <button
              type="submit"
              disabled={!input.trim() || sending}
              className="p-2 text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 rounded-lg shadow-xs transition-colors cursor-pointer"
              aria-label="Send message"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
