import React, { useEffect, useState } from 'react';
import {
  ArrowLeft,
  Sparkles,
  Download,
  Share2,
  Edit2,
  Trash2,
  CheckCircle2,
  Clock,
  Layers,
  FileText,
  Bot,
  Brain,
  ListTodo,
  BarChart2,
  X,
} from 'lucide-react';
import type {
  Campaign,
  CampaignStrategy,
  CampaignTask,
  CampaignContent,
  CampaignMemory,
  WorkflowRun,
} from '../../types.js';
import { api } from '../../services/api.js';
import { useToast } from '../../components/Toast.js';
import { OverviewTab } from './OverviewTab.js';
import { StrategyTab } from './StrategyTab.js';
import { TasksTab } from './TasksTab.js';
import { ContentTab } from './ContentTab.js';
import { EvaluationTab } from './EvaluationTab.js';
import { AssistantTab } from './AssistantTab.js';
import { MemoryTab } from './MemoryTab.js';

interface CampaignWorkspaceProps {
  campaignId: string;
  onBack: () => void;
  onNavigate: (path: string) => void;
}

export function CampaignWorkspace({ campaignId, onBack, onNavigate }: CampaignWorkspaceProps) {
  const { showToast } = useToast();
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [campaign, setCampaign] = useState<Campaign | null>(null);
  const [strategy, setStrategy] = useState<CampaignStrategy | null>(null);
  const [tasks, setTasks] = useState<CampaignTask[]>([]);
  const [content, setContent] = useState<CampaignContent[]>([]);
  const [memories, setMemories] = useState<CampaignMemory[]>([]);
  const [workflow, setWorkflow] = useState<WorkflowRun | null>(null);
  const [loading, setLoading] = useState(true);
  const [runningWorkflow, setRunningWorkflow] = useState(false);
  const [decomposing, setDecomposing] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);

  // Edit Campaign State
  const [editName, setEditName] = useState('');
  const [editObjective, setEditObjective] = useState('');
  const [editBudget, setEditBudget] = useState('');
  const [editStatus, setEditStatus] = useState<Campaign['status']>('in_progress');

  const loadAllData = async () => {
    try {
      const [campData, stratData, taskData, cntData, memData, wfData] = await Promise.all([
        api.getCampaign(campaignId),
        api.getStrategy(campaignId),
        api.getTasks(campaignId),
        api.getContent(campaignId),
        api.getMemories(campaignId),
        api.getWorkflow(campaignId),
      ]);
      setCampaign(campData);
      setStrategy(stratData);
      setTasks(taskData);
      setContent(cntData);
      setMemories(memData);
      setWorkflow(wfData);

      setEditName(campData.name);
      setEditObjective(campData.primaryObjective);
      setEditBudget(campData.budget);
      setEditStatus(campData.status);
    } catch (err: any) {
      console.error(err);
      showToast(err.message || 'Failed to load campaign workspace', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAllData();
  }, [campaignId]);

  const handleRunWorkflow = async () => {
    setRunningWorkflow(true);
    try {
      const run = await api.runWorkflow(campaignId);
      setWorkflow(run);
      showToast('AI multi-agent workflow completed successfully!', 'success');
      loadAllData();
    } catch (e: any) {
      showToast(e.message || 'Workflow run failed', 'error');
    } finally {
      setRunningWorkflow(false);
    }
  };

  const handleDecomposeTasks = async () => {
    setDecomposing(true);
    try {
      const newTasks = await api.decomposeTasks(campaignId);
      setTasks(newTasks);
      showToast('Agile tasks decomposed from strategy!', 'success');
      setActiveTab('tasks');
    } catch (e: any) {
      showToast(e.message || 'Failed to decompose tasks', 'error');
    } finally {
      setDecomposing(false);
    }
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!campaign) return;

    try {
      const updated = await api.updateCampaign(campaign.id, {
        name: editName,
        primaryObjective: editObjective,
        budget: editBudget,
        status: editStatus,
      });
      setCampaign(updated);
      setShowEditModal(false);
      showToast('Campaign parameters updated', 'success');
    } catch (err) {
      showToast('Update failed', 'error');
    }
  };

  const handleExport = (format: 'markdown' | 'json') => {
    window.location.href = api.getExportUrl(campaignId, format);
    showToast(`Downloading campaign blueprint as ${format.toUpperCase()}...`, 'info');
  };

  if (loading || !campaign) {
    return (
      <div className="p-8 max-w-7xl mx-auto space-y-6">
        <div className="h-6 w-48 bg-slate-200 animate-pulse rounded" />
        <div className="h-20 bg-slate-100 rounded-xl animate-pulse" />
        <div className="h-96 bg-slate-50 rounded-xl animate-pulse" />
      </div>
    );
  }

  const tabs = [
    { id: 'overview', label: 'Overview', icon: Layers },
    { id: 'strategy', label: 'Strategy', icon: Sparkles },
    { id: 'tasks', label: 'Tasks', icon: ListTodo, badge: tasks.length },
    { id: 'content', label: 'Content Studio', icon: FileText, badge: content.length },
    { id: 'evaluation', label: 'Evaluation', icon: BarChart2 },
    { id: 'assistant', label: 'AI Assistant', icon: Bot },
    { id: 'memory', label: 'Memory Bank', icon: Brain, badge: memories.length },
  ];

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Top Breadcrumb & Return Action */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Campaigns</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={() => handleExport('markdown')}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg shadow-2xs transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span>Export Plan (.md)</span>
          </button>

          <button
            onClick={() => handleExport('json')}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg shadow-2xs transition-colors cursor-pointer"
          >
            <span>JSON</span>
          </button>
        </div>
      </div>

      {/* Main Campaign Workspace Hero Card */}
      <div className="p-6 bg-white border border-slate-200 rounded-xl shadow-2xs space-y-4 text-left">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2.5 flex-wrap">
              <span className="text-xs font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded">
                {campaign.goal}
              </span>
              <span className="text-slate-300">·</span>
              <span className="text-xs text-slate-500 font-semibold">{campaign.productName}</span>
              <span className="text-slate-300">·</span>
              <span className="text-xs font-semibold capitalize text-emerald-700">
                {campaign.status.replace('_', ' ')}
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              {campaign.name}
            </h2>
            <p className="text-xs text-slate-600 max-w-2xl">
              {campaign.productDescription || campaign.description}
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setShowEditModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors cursor-pointer"
            >
              <Edit2 className="w-3.5 h-3.5 text-slate-500" />
              <span>Edit Details</span>
            </button>
          </div>
        </div>

        {/* Progress bar */}
        <div className="pt-2 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-slate-500">
          <div className="flex items-center gap-4 flex-wrap">
            <span>Primary Channel: <strong className="text-slate-700">{campaign.primaryChannel}</strong></span>
            <span>·</span>
            <span>Duration: <strong className="text-slate-700 font-tabular">{campaign.durationDays} days</strong></span>
            <span>·</span>
            <span>Budget: <strong className="text-slate-700 font-tabular">{campaign.budget}</strong></span>
          </div>

          <div className="flex items-center gap-2.5 self-end sm:self-auto">
            <span className="font-semibold text-slate-700 font-tabular">
              {campaign.progressPercentage}% Complete
            </span>
            <div className="w-28 h-2 bg-slate-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-indigo-600 rounded-full transition-all duration-500"
                style={{ width: `${campaign.progressPercentage}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Tabs Navigation Bar */}
      <div className="flex items-center gap-1 border-b border-slate-200 overflow-x-auto pb-px">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors cursor-pointer ${
                isActive
                  ? 'border-indigo-600 text-indigo-700 bg-white rounded-t-lg'
                  : 'border-transparent text-slate-500 hover:text-slate-800 hover:border-slate-300'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-indigo-600' : 'text-slate-400'}`} />
              <span>{tab.label}</span>
              {tab.badge !== undefined && (
                <span
                  className={`text-[10px] font-mono font-bold px-1.5 py-0.2 rounded-full ${
                    isActive ? 'bg-indigo-100 text-indigo-800' : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Active Tab View */}
      <div className="pt-2">
        {activeTab === 'overview' && (
          <OverviewTab
            campaign={campaign}
            strategy={strategy}
            tasks={tasks}
            content={content}
            workflow={workflow}
            onNavigateTab={setActiveTab}
            onRunWorkflow={handleRunWorkflow}
            runningWorkflow={runningWorkflow}
          />
        )}

        {activeTab === 'strategy' && (
          <StrategyTab
            campaign={campaign}
            strategy={strategy}
            onStrategyUpdated={(newStrat) => {
              setStrategy(newStrat);
              loadAllData();
            }}
            onDecomposeTasks={handleDecomposeTasks}
            decomposing={decomposing}
          />
        )}

        {activeTab === 'tasks' && (
          <TasksTab
            campaignId={campaign.id}
            tasks={tasks}
            onTasksUpdated={setTasks}
            onDecompose={handleDecomposeTasks}
            decomposing={decomposing}
          />
        )}

        {activeTab === 'content' && (
          <ContentTab
            campaign={campaign}
            content={content}
            onContentUpdated={setContent}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'evaluation' && (
          <EvaluationTab
            campaign={campaign}
            content={content}
            onContentUpdated={setContent}
          />
        )}

        {activeTab === 'assistant' && (
          <AssistantTab campaign={campaign} />
        )}

        {activeTab === 'memory' && (
          <MemoryTab
            campaign={campaign}
            memories={memories}
            onMemoriesUpdated={setMemories}
          />
        )}
      </div>

      {/* Edit Details Modal */}
      {showEditModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl p-6 max-w-md w-full shadow-xl space-y-4 text-left">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h4 className="text-sm font-bold text-slate-900">Edit Campaign Parameters</h4>
              <button onClick={() => setShowEditModal(false)} className="text-slate-400 hover:text-slate-700">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Campaign Name</label>
                <input
                  type="text"
                  required
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Primary Objective</label>
                <textarea
                  rows={2}
                  required
                  value={editObjective}
                  onChange={(e) => setEditObjective(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Budget Allocation</label>
                  <input
                    type="text"
                    value={editBudget}
                    onChange={(e) => setEditBudget(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-slate-900"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Status</label>
                  <select
                    value={editStatus}
                    onChange={(e: any) => setEditStatus(e.target.value)}
                    className="w-full px-2.5 py-2 border border-slate-200 rounded-lg text-slate-900"
                  >
                    <option value="draft">Draft</option>
                    <option value="planning">Planning</option>
                    <option value="in_progress">In Progress</option>
                    <option value="review">Review</option>
                    <option value="completed">Completed</option>
                    <option value="archived">Archived</option>
                  </select>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowEditModal(false)}
                  className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
