import React, { useEffect, useState } from 'react';
import { CheckSquare, Clock, Filter, Plus, User, Sparkles } from 'lucide-react';
import type { CampaignTask, Campaign } from '../types.js';
import { api } from '../services/api.js';
import { useToast } from '../components/Toast.js';

interface GlobalTasksPageProps {
  onOpenCampaign: (campaignId: string) => void;
  onNavigate: (path: string) => void;
}

export function GlobalTasksPage({ onOpenCampaign, onNavigate }: GlobalTasksPageProps) {
  const { showToast } = useToast();
  const [tasks, setTasks] = useState<CampaignTask[]>([]);
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [loading, setLoading] = useState(true);
  const [priorityFilter, setPriorityFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');

  useEffect(() => {
    async function loadData() {
      try {
        const [taskList, campList] = await Promise.all([
          api.getTasks(),
          api.getCampaigns(),
        ]);
        setTasks(taskList);
        setCampaigns(campList);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, []);

  const handleStatusChange = async (taskId: string, campaignId: string, status: any) => {
    try {
      const updated = await api.updateTask(campaignId, taskId, { status });
      setTasks(tasks.map((t) => (t.id === taskId ? updated : t)));
      showToast(`Task status updated to ${status}`, 'info');
    } catch (e) {
      showToast('Failed to update status', 'error');
    }
  };

  const getCampaignName = (campaignId: string) => {
    const found = campaigns.find((c) => c.id === campaignId);
    return found ? found.name : 'Active Campaign';
  };

  const filteredTasks = tasks.filter((t) => {
    const matchPriority = priorityFilter === 'all' || t.priority === priorityFilter;
    const matchStatus = statusFilter === 'all' || t.status === statusFilter;
    return matchPriority && matchStatus;
  });

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6 text-left">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
            Global Task Operations
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Cross-campaign execution queue decomposed by AI and assigned to workstreams.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-hidden"
          >
            <option value="all">All Statuses</option>
            <option value="todo">To Do</option>
            <option value="in_progress">In Progress</option>
            <option value="review">Review</option>
            <option value="done">Done</option>
          </select>

          <select
            value={priorityFilter}
            onChange={(e) => setPriorityFilter(e.target.value)}
            className="px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-hidden"
          >
            <option value="all">All Priorities</option>
            <option value="urgent">Urgent</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>
        </div>
      </div>

      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-16 bg-slate-100 rounded-lg animate-pulse" />
          ))}
        </div>
      ) : filteredTasks.length === 0 ? (
        <div className="py-16 text-center bg-white border border-slate-200 rounded-xl">
          <CheckSquare className="w-8 h-8 text-slate-300 mx-auto mb-2" />
          <p className="text-xs text-slate-500">No tasks match your criteria.</p>
        </div>
      ) : (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-2xs divide-y divide-slate-100">
          {filteredTasks.map((task) => (
            <div
              key={task.id}
              className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-slate-50/60 transition-colors"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span
                    className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded border ${
                      task.priority === 'urgent'
                        ? 'text-rose-700 bg-rose-50 border-rose-200'
                        : task.priority === 'high'
                        ? 'text-amber-700 bg-amber-50 border-amber-200'
                        : 'text-indigo-700 bg-indigo-50 border-indigo-200'
                    }`}
                  >
                    {task.priority}
                  </span>
                  <span className="text-slate-300">·</span>
                  <button
                    onClick={() => onOpenCampaign(task.campaignId)}
                    className="text-xs font-semibold text-indigo-600 hover:text-indigo-800"
                  >
                    {getCampaignName(task.campaignId)}
                  </button>
                  {task.aiGenerated && (
                    <span className="text-[10px] text-indigo-600 bg-indigo-50/60 px-1.5 py-0.5 rounded font-medium flex items-center gap-1">
                      <Sparkles className="w-2.5 h-2.5" /> AI
                    </span>
                  )}
                </div>

                <h4 className="text-xs sm:text-sm font-bold text-slate-900">
                  {task.title}
                </h4>
                <p className="text-xs text-slate-500 line-clamp-1 max-w-xl">
                  {task.description}
                </p>
              </div>

              <div className="flex items-center gap-4 text-xs shrink-0 self-end sm:self-auto">
                <div className="text-right text-[11px] text-slate-500">
                  <span className="block font-medium text-slate-700">{task.assignee}</span>
                  <span className="block text-slate-400 font-tabular">{task.dueDate}</span>
                </div>

                <select
                  value={task.status}
                  onChange={(e) => handleStatusChange(task.id, task.campaignId, e.target.value)}
                  className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-800"
                >
                  <option value="todo">To Do</option>
                  <option value="in_progress">In Progress</option>
                  <option value="review">Review</option>
                  <option value="done">Done</option>
                </select>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
