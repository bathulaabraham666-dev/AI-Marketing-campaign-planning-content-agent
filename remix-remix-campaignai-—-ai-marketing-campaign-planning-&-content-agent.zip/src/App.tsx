/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import type { UserProfile } from './types.js';
import { api } from './services/api.js';
import { ToastProvider } from './components/Toast.js';
import { Sidebar } from './components/Sidebar.js';
import { TopBar } from './components/TopBar.js';
import { LandingPage } from './pages/LandingPage.js';
import { AuthPage } from './pages/AuthPages.js';
import { DashboardPage } from './pages/DashboardPage.js';
import { CampaignsListPage } from './pages/CampaignsListPage.js';
import { CreateCampaignWizard } from './pages/CreateCampaignWizard.js';
import { CampaignWorkspace } from './pages/CampaignWorkspace/index.js';
import { GlobalTasksPage } from './pages/GlobalTasksPage.js';
import { GlobalContentPage } from './pages/GlobalContentPage.js';
import { GlobalAssistantPage } from './pages/GlobalAssistantPage.js';
import { GlobalMemoryPage } from './pages/GlobalMemoryPage.js';
import { AnalyticsPage } from './pages/AnalyticsPage.js';
import { AdminEvaluationsPage } from './pages/AdminEvaluationsPage.js';
import { SettingsPage } from './pages/SettingsPage.js';

export default function App() {
  const [currentPath, setCurrentPath] = useState<string>(() => {
    return window.location.pathname || '/';
  });
  const [user, setUser] = useState<UserProfile | null>(null);
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Handle client-side routing
  const navigate = (path: string) => {
    window.history.pushState({}, '', path);
    setCurrentPath(path);
    window.scrollTo(0, 0);
  };

  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname || '/');
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  // Load current user profile
  useEffect(() => {
    async function loadUser() {
      try {
        const u = await api.getCurrentUser();
        setUser(u);
      } catch (e) {
        console.error('Failed to load user:', e);
      }
    }
    loadUser();
  }, []);

  const handleLogout = async () => {
    navigate('/login');
  };

  // Determine active view & title
  const isAuthRoute = currentPath === '/login' || currentPath === '/signup' || currentPath === '/forgot-password';
  const isLandingRoute = currentPath === '/';

  // Check if route is a campaign workspace: /campaigns/:id
  const campaignMatch = currentPath.match(/^\/campaigns\/(camp_[a-zA-Z0-9_-]+)/);
  const activeCampaignId = campaignMatch ? campaignMatch[1] : null;

  const getPageMeta = () => {
    if (currentPath === '/dashboard') return { title: 'Dashboard', subtitle: 'Campaign Overview' };
    if (currentPath === '/campaigns') return { title: 'Campaigns', subtitle: 'Manage Strategic Initiatives' };
    if (currentPath === '/campaigns/new') return { title: 'New Campaign', subtitle: 'Multi-Agent Wizard' };
    if (activeCampaignId) return { title: 'Campaign Workspace', subtitle: 'Strategic Control Center' };
    if (currentPath === '/tasks') return { title: 'Global Tasks', subtitle: 'Kanban Workstreams' };
    if (currentPath === '/content') return { title: 'Content Studio', subtitle: 'Generated Assets' };
    if (currentPath === '/assistant') return { title: 'AI Assistant', subtitle: 'Autonomous Marketing CMO' };
    if (currentPath === '/analytics') return { title: 'Analytics', subtitle: 'Operational Telemetry' };
    if (currentPath === '/memory') return { title: 'Memory Bank', subtitle: 'Strategic Context' };
    if (currentPath === '/admin/evaluations') return { title: 'System Tests', subtitle: 'AI Validation Suite' };
    if (currentPath === '/settings') return { title: 'Settings', subtitle: 'Preferences & Models' };
    return { title: 'CampaignAI', subtitle: 'Autonomous Marketing Platform' };
  };

  const meta = getPageMeta();

  return (
    <ToastProvider>
      {/* 1. Landing Page */}
      {isLandingRoute && (
        <LandingPage onNavigate={navigate} />
      )}

      {/* 2. Authentication Pages */}
      {isAuthRoute && (
        <AuthPage
          mode={currentPath === '/signup' ? 'signup' : currentPath === '/forgot-password' ? 'forgot-password' : 'login'}
          onNavigate={navigate}
          onSuccess={() => navigate('/dashboard')}
        />
      )}

      {/* 3. Main Authenticated SaaS Shell */}
      {!isLandingRoute && !isAuthRoute && (
        <div className="min-h-screen bg-[#F8FAFC] flex">
          {/* Sidebar */}
          <Sidebar
            currentPath={currentPath}
            onNavigate={navigate}
            user={user}
            onLogout={handleLogout}
            isMobileOpen={isMobileOpen}
            onCloseMobile={() => setIsMobileOpen(false)}
          />

          {/* Main Content Area */}
          <div className="flex-1 md:ml-64 flex flex-col min-w-0">
            <TopBar
              title={meta.title}
              subtitle={meta.subtitle}
              onOpenMobileMenu={() => setIsMobileOpen(true)}
              onNavigate={navigate}
              user={user}
              searchQuery={searchQuery}
              onSearchChange={setSearchQuery}
            />

            <main className="flex-1 pb-16">
              {currentPath === '/dashboard' && (
                <DashboardPage
                  user={user}
                  onNavigate={navigate}
                  onOpenCampaign={(id) => navigate(`/campaigns/${id}`)}
                />
              )}

              {currentPath === '/campaigns' && (
                <CampaignsListPage
                  onNavigate={navigate}
                  onOpenCampaign={(id) => navigate(`/campaigns/${id}`)}
                />
              )}

              {currentPath === '/campaigns/new' && (
                <CreateCampaignWizard
                  onCancel={() => navigate('/campaigns')}
                  onCampaignCreated={(id) => navigate(`/campaigns/${id}`)}
                />
              )}

              {activeCampaignId && (
                <CampaignWorkspace
                  campaignId={activeCampaignId}
                  onBack={() => navigate('/campaigns')}
                  onNavigate={navigate}
                />
              )}

              {currentPath === '/tasks' && (
                <GlobalTasksPage
                  onOpenCampaign={(id) => navigate(`/campaigns/${id}`)}
                  onNavigate={navigate}
                />
              )}

              {currentPath === '/content' && (
                <GlobalContentPage
                  onOpenCampaign={(id) => navigate(`/campaigns/${id}`)}
                  onNavigate={navigate}
                />
              )}

              {currentPath === '/assistant' && (
                <GlobalAssistantPage onNavigate={navigate} />
              )}

              {currentPath === '/memory' && (
                <GlobalMemoryPage onOpenCampaign={(id) => navigate(`/campaigns/${id}`)} />
              )}

              {currentPath === '/analytics' && (
                <AnalyticsPage />
              )}

              {currentPath === '/admin/evaluations' && (
                <AdminEvaluationsPage />
              )}

              {currentPath === '/settings' && (
                <SettingsPage />
              )}
            </main>
          </div>
        </div>
      )}
    </ToastProvider>
  );
}
