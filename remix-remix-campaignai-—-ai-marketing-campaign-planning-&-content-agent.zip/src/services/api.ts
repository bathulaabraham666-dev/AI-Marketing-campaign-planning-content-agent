import type {
  Campaign,
  CampaignStrategy,
  CampaignTask,
  CampaignContent,
  ContentEvaluation,
  CampaignMemory,
  WorkflowRun,
  ChatMessage,
  UserProfile,
  AnalyticsSummary,
} from '../types.js';

async function request<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    headers: {
      'Content-Type': 'application/json',
      ...options?.headers,
    },
    ...options,
  });
  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error || `Request failed with status ${res.status}`);
  }
  return res.json();
}

export const api = {
  // Auth
  getCurrentUser: () => request<UserProfile>('/api/auth/me'),
  login: (email: string) => request<{ success: boolean; user: UserProfile }>('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email }),
  }),
  signup: (data: { name: string; email: string; businessName: string }) =>
    request<{ success: boolean; user: UserProfile }>('/api/auth/signup', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  // Settings
  getSettings: () => request<UserProfile>('/api/settings'),
  updateSettings: (data: Partial<UserProfile>) =>
    request<UserProfile>('/api/settings', {
      method: 'PUT',
      body: JSON.stringify(data),
    }),

  // Campaigns
  getCampaigns: () => request<Campaign[]>('/api/campaigns'),
  getCampaign: (id: string) => request<Campaign>(`/api/campaigns/${id}`),
  createCampaign: (data: Omit<Campaign, 'id' | 'createdAt' | 'updatedAt' | 'progressPercentage'>) =>
    request<Campaign>('/api/campaigns', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  updateCampaign: (id: string, data: Partial<Campaign>) =>
    request<Campaign>(`/api/campaigns/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),
  deleteCampaign: (id: string) =>
    request<{ success: boolean }>(`/api/campaigns/${id}`, {
      method: 'DELETE',
    }),

  // Strategy
  getStrategy: (campaignId: string) => request<CampaignStrategy | null>(`/api/campaigns/${campaignId}/strategy`),
  generateStrategy: (campaignId: string) =>
    request<CampaignStrategy>(`/api/campaigns/${campaignId}/strategy/generate`, {
      method: 'POST',
    }),
  updateStrategy: (campaignId: string, data: Partial<CampaignStrategy>) =>
    request<CampaignStrategy>(`/api/campaigns/${campaignId}/strategy`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),

  // Tasks
  getTasks: (campaignId?: string) =>
    request<CampaignTask[]>(campaignId ? `/api/campaigns/${campaignId}/tasks` : '/api/tasks'),
  createTask: (campaignId: string, data: Omit<CampaignTask, 'id' | 'campaignId' | 'createdAt' | 'updatedAt'>) =>
    request<CampaignTask>(`/api/campaigns/${campaignId}/tasks`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  decomposeTasks: (campaignId: string) =>
    request<CampaignTask[]>(`/api/campaigns/${campaignId}/tasks/decompose`, {
      method: 'POST',
    }),
  updateTask: (campaignId: string, taskId: string, data: Partial<CampaignTask>) =>
    request<CampaignTask>(`/api/campaigns/${campaignId}/tasks/${taskId}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),
  deleteTask: (campaignId: string, taskId: string) =>
    request<{ success: boolean }>(`/api/campaigns/${campaignId}/tasks/${taskId}`, {
      method: 'DELETE',
    }),

  // Content
  getContent: (campaignId?: string) =>
    request<CampaignContent[]>(campaignId ? `/api/campaigns/${campaignId}/content` : '/api/content'),
  generateContent: (campaignId: string, data: any) =>
    request<CampaignContent>(`/api/campaigns/${campaignId}/content/generate`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  updateContent: (campaignId: string, contentId: string, data: Partial<CampaignContent>) =>
    request<CampaignContent>(`/api/campaigns/${campaignId}/content/${contentId}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),
  deleteContent: (campaignId: string, contentId: string) =>
    request<{ success: boolean }>(`/api/campaigns/${campaignId}/content/${contentId}`, {
      method: 'DELETE',
    }),
  evaluateContent: (campaignId: string, contentId: string) =>
    request<ContentEvaluation>(`/api/campaigns/${campaignId}/content/${contentId}/evaluate`, {
      method: 'POST',
    }),
  improveContent: (campaignId: string, contentId: string, instruction?: string) =>
    request<CampaignContent>(`/api/campaigns/${campaignId}/content/${contentId}/improve`, {
      method: 'POST',
      body: JSON.stringify({ instruction }),
    }),

  // Memory
  getMemories: (campaignId?: string) =>
    request<CampaignMemory[]>(campaignId ? `/api/campaigns/${campaignId}/memory` : '/api/memory'),
  createMemory: (campaignId: string, data: Omit<CampaignMemory, 'id' | 'campaignId' | 'createdAt'>) =>
    request<CampaignMemory>(`/api/campaigns/${campaignId}/memory`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  deleteMemory: (campaignId: string, memoryId: string) =>
    request<{ success: boolean }>(`/api/campaigns/${campaignId}/memory/${memoryId}`, {
      method: 'DELETE',
    }),

  // Chat
  getChat: (campaignId: string) => request<ChatMessage[]>(`/api/campaigns/${campaignId}/chat`),
  sendMessage: (campaignId: string, message: string) =>
    request<ChatMessage>(`/api/campaigns/${campaignId}/chat`, {
      method: 'POST',
      body: JSON.stringify({ message }),
    }),
  clearChat: (campaignId: string) =>
    request<{ success: boolean }>(`/api/campaigns/${campaignId}/chat/clear`, {
      method: 'POST',
    }),

  // Workflow
  getWorkflow: (campaignId: string) => request<WorkflowRun>(`/api/campaigns/${campaignId}/workflow`),
  runWorkflow: (campaignId: string) =>
    request<WorkflowRun>(`/api/campaigns/${campaignId}/workflow/run`, {
      method: 'POST',
    }),

  // Analytics & Admin
  getAnalytics: () => request<AnalyticsSummary>('/api/analytics'),
  getAdminEvaluations: () => request<any>('/api/admin/evaluations'),

  // Export
  getExportUrl: (campaignId: string, format: 'markdown' | 'json' = 'markdown') =>
    `/api/campaigns/${campaignId}/export?format=${format}`,
};
