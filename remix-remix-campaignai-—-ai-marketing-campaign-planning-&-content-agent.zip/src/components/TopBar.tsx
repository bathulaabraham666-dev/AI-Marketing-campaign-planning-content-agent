import React from 'react';
import { Menu, Search, Sparkles, Plus } from 'lucide-react';
import type { UserProfile } from '../types.js';

interface TopBarProps {
  title: string;
  subtitle?: string;
  onOpenMobileMenu: () => void;
  onNavigate: (path: string) => void;
  user: UserProfile | null;
  searchQuery?: string;
  onSearchChange?: (q: string) => void;
}

export function TopBar({
  title,
  subtitle,
  onOpenMobileMenu,
  onNavigate,
  user,
  searchQuery,
  onSearchChange,
}: TopBarProps) {
  return (
    <header className="h-16 bg-white border-b border-slate-200 sticky top-0 z-30 px-4 md:px-8 flex items-center justify-between">
      {/* Zone 1: Mobile toggle & Breadcrumb Title */}
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenMobileMenu}
          className="p-1.5 -ml-1 text-slate-600 hover:text-slate-900 md:hidden rounded-lg hover:bg-slate-100"
          aria-label="Open navigation menu"
        >
          <Menu className="w-5 h-5" />
        </button>
        <div>
          <h1 className="text-sm font-bold text-slate-900 leading-tight tracking-tight">
            {title}
          </h1>
          {subtitle && (
            <p className="text-[11px] text-slate-500 font-normal">{subtitle}</p>
          )}
        </div>
      </div>

      {/* Zone 2: Interactive search & actions */}
      <div className="flex items-center gap-3">
        {onSearchChange !== undefined && (
          <div className="relative hidden sm:block w-48 lg:w-64">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search campaigns, tasks..."
              value={searchQuery || ''}
              onChange={(e) => onSearchChange(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:bg-white focus:outline-hidden focus:ring-1 focus:ring-indigo-500 transition-all text-slate-800 placeholder-slate-400"
            />
          </div>
        )}

        {/* AI System Badge */}
        <div className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 bg-indigo-50/60 rounded-md text-[11px] font-medium text-indigo-700">
          <Sparkles className="w-3 h-3 text-indigo-500" />
          <span>Gemini 3.8 Flash</span>
        </div>

        {/* Primary CTA */}
        <button
          onClick={() => onNavigate('/campaigns/new')}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-md shadow-2xs transition-colors cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">New Campaign</span>
        </button>

        {/* Profile Avatar */}
        <button
          onClick={() => onNavigate('/settings')}
          className="w-8 h-8 rounded-full bg-slate-100 hover:ring-2 hover:ring-indigo-500 transition-all flex items-center justify-center text-slate-800 font-semibold text-xs border border-slate-200"
          title="Account Settings"
        >
          {user?.name ? user.name.slice(0, 2).toUpperCase() : 'AI'}
        </button>
      </div>
    </header>
  );
}
