import React from 'react';
import {
  LayoutDashboard,
  Target,
  CheckSquare,
  PenTool,
  Bot,
  BarChart3,
  Brain,
  Settings,
  ShieldCheck,
  Plus,
  ExternalLink,
  LogOut,
  Sparkles,
} from 'lucide-react';
import type { UserProfile } from '../types.js';

interface SidebarProps {
  currentPath: string;
  onNavigate: (path: string) => void;
  user: UserProfile | null;
  onLogout: () => void;
  isMobileOpen?: boolean;
  onCloseMobile?: () => void;
}

export function Sidebar({
  currentPath,
  onNavigate,
  user,
  onLogout,
  isMobileOpen = false,
  onCloseMobile,
}: SidebarProps) {
  const navItems = [
    { label: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
    { label: 'Campaigns', path: '/campaigns', icon: Target },
    { label: 'Tasks', path: '/tasks', icon: CheckSquare },
    { label: 'Content Studio', path: '/content', icon: PenTool },
    { label: 'AI Assistant', path: '/assistant', icon: Bot },
    { label: 'Analytics', path: '/analytics', icon: BarChart3 },
    { label: 'Memory Bank', path: '/memory', icon: Brain },
    { label: 'System Tests', path: '/admin/evaluations', icon: ShieldCheck },
    { label: 'Settings', path: '/settings', icon: Settings },
  ];

  const handleNav = (path: string) => {
    onNavigate(path);
    if (onCloseMobile) onCloseMobile();
  };

  return (
    <>
      {/* Mobile backdrop */}
      {isMobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-900/50 backdrop-blur-xs md:hidden"
          onClick={onCloseMobile}
        />
      )}

      <aside
        className={`fixed top-0 bottom-0 left-0 z-40 w-64 bg-white border-r border-slate-200 flex flex-col justify-between transition-transform duration-200 ease-in-out md:translate-x-0 ${
          isMobileOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
      >
        <div>
          {/* Brand header */}
          <div className="h-16 px-6 flex items-center justify-between border-b border-slate-100">
            <button
              onClick={() => handleNav('/dashboard')}
              className="flex items-center gap-2.5 text-left focus:outline-hidden"
            >
              <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white shadow-xs">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <span className="font-bold text-base tracking-tight text-slate-900 block leading-tight">
                  CampaignAI
                </span>
                <span className="text-[10px] text-slate-500 font-medium block tracking-wide">
                  STRATEGIC AGENT
                </span>
              </div>
            </button>
          </div>

          {/* Quick Create CTA */}
          <div className="p-4">
            <button
              onClick={() => handleNav('/campaigns/new')}
              className="w-full flex items-center justify-center gap-2 px-3.5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>New Campaign</span>
            </button>
          </div>

          {/* Nav Links */}
          <nav className="px-3 space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive =
                currentPath === item.path ||
                (item.path === '/campaigns' && currentPath.startsWith('/campaigns/'));

              return (
                <button
                  key={item.path}
                  onClick={() => handleNav(item.path)}
                  className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-medium transition-colors text-left cursor-pointer ${
                    isActive
                      ? 'bg-indigo-50 text-indigo-700 font-semibold'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <Icon
                    className={`w-4 h-4 shrink-0 ${
                      isActive ? 'text-indigo-600' : 'text-slate-400'
                    }`}
                  />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Bottom Profile & Utilities */}
        <div className="p-3 border-t border-slate-100 space-y-2">
          <button
            onClick={() => handleNav('/')}
            className="w-full flex items-center justify-between px-3 py-1.5 text-xs text-slate-500 hover:text-slate-900 hover:bg-slate-50 rounded-md transition-colors"
          >
            <span className="flex items-center gap-2">
              <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
              <span>Public Landing Page</span>
            </span>
          </button>

          <div className="pt-2 border-t border-slate-100 flex items-center justify-between px-2">
            <div className="flex items-center gap-2.5 overflow-hidden">
              <div className="w-7 h-7 rounded-full bg-slate-900 text-white flex items-center justify-center font-bold text-xs shrink-0">
                {user?.name ? user.name.charAt(0) : 'U'}
              </div>
              <div className="truncate">
                <span className="block text-xs font-semibold text-slate-900 truncate">
                  {user?.name || 'User'}
                </span>
                <span className="block text-[11px] text-slate-400 truncate">
                  {user?.businessName || 'CampaignAI'}
                </span>
              </div>
            </div>
            <button
              onClick={onLogout}
              title="Sign out"
              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors"
              aria-label="Logout"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
}
