export type CampaignStatus = 'draft' | 'planning' | 'in_progress' | 'review' | 'completed' | 'archived';

export type CampaignGoal = 
  | 'Brand Awareness'
  | 'Lead Generation'
  | 'Sales'
  | 'Product Launch'
  | 'Website Traffic'
  | 'Engagement'
  | 'Customer Retention'
  | 'Other';

export type BrandVoice = 
  | 'Professional'
  | 'Friendly'
  | 'Bold'
  | 'Educational'
  | 'Luxury'
  | 'Playful'
  | 'Minimal'
  | 'Custom';

export type MarketingChannel = 
  | 'Instagram'
  | 'Facebook'
  | 'LinkedIn'
  | 'YouTube'
  | 'X'
  | 'Email'
  | 'Google Ads'
  | 'Blog'
  | 'Website';

export interface CampaignStrategy {
  id: string;
  campaignId: string;
  objective: string;
  targetAudience: string;
  valueProposition: string;
  positioning: string;
  coreMessage: string;
  campaignTheme: string;
  marketingFunnel: {
    top: string;
    middle: string;
    bottom: string;
  };
  contentPillars: string[];
  recommendedChannels: MarketingChannel[];
  ctaStrategy: string;
  kpis: string[];
  updatedAt: string;
}

export type TaskPriority = 'low' | 'medium' | 'high' | 'urgent';
export type TaskStatus = 'todo' | 'in_progress' | 'review' | 'done';

export interface CampaignTask {
  id: string;
  campaignId: string;
  title: string;
  description: string;
  priority: TaskPriority;
  status: TaskStatus;
  dueDate: string;
  aiGenerated: boolean;
  dependencies: string[];
  assignee: string;
  relatedContentType?: string;
  createdAt: string;
  updatedAt: string;
}

export type ContentCategory = 'social' | 'marketing';

export type ContentType = 
  | 'Instagram Post'
  | 'Instagram Reel'
  | 'Instagram Story'
  | 'LinkedIn Post'
  | 'Facebook Post'
  | 'X Post'
  | 'Ad Copy'
  | 'Email'
  | 'Landing Page'
  | 'Blog Article'
  | 'Product Description'
  | 'Headline'
  | 'CTA';

export interface ContentEvaluation {
  id: string;
  contentId: string;
  clarity: number;         // 0 - 100
  brandAlignment: number;  // 0 - 100
  audienceFit: number;     // 0 - 100
  platformFit: number;     // 0 - 100
  ctaStrength: number;     // 0 - 100
  readability: number;     // 0 - 100
  overallScore: number;    // average
  strengths: string[];
  issues: string[];
  suggestions: string[];
  evaluatedAt: string;
}

export interface ContentVersion {
  id: string;
  versionNumber: number;
  body: string;
  title: string;
  headline?: string;
  callToAction?: string;
  createdAt: string;
  note?: string;
}

export interface CampaignContent {
  id: string;
  campaignId: string;
  category: ContentCategory;
  type: ContentType;
  title: string;
  body: string;
  headline?: string;
  callToAction?: string;
  targetAudience?: string;
  tone?: string;
  platform?: string;
  status: 'draft' | 'pending_review' | 'approved';
  versions: ContentVersion[];
  evaluation?: ContentEvaluation;
  createdAt: string;
  updatedAt: string;
}

export type MemoryCategory = 'user' | 'campaign' | 'conversation';

export interface CampaignMemory {
  id: string;
  campaignId?: string;
  userId?: string;
  category: MemoryCategory;
  key: string;
  content: string;
  source: string;
  createdAt: string;
}

export type WorkflowStepStatus = 'PENDING' | 'RUNNING' | 'COMPLETED' | 'FAILED' | 'WAITING_FOR_USER';

export interface WorkflowStep {
  id: string;
  name: string;
  description: string;
  status: WorkflowStepStatus;
  input?: any;
  output?: any;
  startTime?: string;
  endTime?: string;
  errorMessage?: string;
}

export interface WorkflowRun {
  id: string;
  campaignId: string;
  status: 'RUNNING' | 'COMPLETED' | 'FAILED';
  currentStepIndex: number;
  steps: WorkflowStep[];
  startedAt: string;
  completedAt?: string;
}

export interface Campaign {
  id: string;
  userId: string;
  name: string;
  description: string;
  businessName: string;
  website?: string;
  industry: string;
  productName: string;
  productDescription: string;
  valueProposition: string;
  goal: CampaignGoal;
  primaryObjective: string;
  audienceAgeRange: string;
  audienceLocation: string;
  audienceOccupation: string;
  audienceInterests: string;
  audiencePainPoints: string;
  audienceBuyingBehavior: string;
  audienceDescription: string;
  budget: string;
  durationDays: number;
  startDate: string;
  endDate: string;
  primaryChannel: MarketingChannel;
  secondaryChannels: MarketingChannel[];
  brandVoice: BrandVoice;
  customBrandVoice?: string;
  status: CampaignStatus;
  progressPercentage: number;
  createdAt: string;
  updatedAt: string;
  // Relationships aggregated for convenience
  strategy?: CampaignStrategy;
  taskCount?: number;
  contentCount?: number;
  evaluationAvg?: number;
}

export interface ChatMessage {
  id: string;
  campaignId?: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
  suggestedActions?: string[];
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  businessName?: string;
  industry?: string;
  website?: string;
  defaultBrandVoice?: BrandVoice;
  defaultAudience?: string;
  aiModel?: string;
}

export interface AnalyticsSummary {
  activeCampaigns: number;
  completedCampaigns: number;
  totalTasks: number;
  tasksCompleted: number;
  contentGenerated: number;
  contentApproved: number;
  avgAiQualityScore: number;
  workflowSuccessRate: number;
  channelBreakdown: { channel: string; count: number }[];
  goalBreakdown: { goal: string; count: number }[];
}

export interface EvaluationTestCase {
  id: string;
  scenario: string;
  goal: CampaignGoal;
  inputs: Record<string, any>;
  strategyPassed: boolean;
  taskDecompositionPassed: boolean;
  contentSchemaPassed: boolean;
  evaluationScore: number;
  latencyMs: number;
  status: 'passed' | 'failed';
  timestamp: string;
}
