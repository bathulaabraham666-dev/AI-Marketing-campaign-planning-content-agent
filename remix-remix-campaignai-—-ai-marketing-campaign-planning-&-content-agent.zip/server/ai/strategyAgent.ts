import { getGeminiClient } from './geminiClient.js';
import type { Campaign, CampaignStrategy } from '../../src/types.js';

export async function generateCampaignStrategy(campaign: Campaign): Promise<Omit<CampaignStrategy, 'id' | 'campaignId' | 'updatedAt'>> {
  const ai = getGeminiClient();

  if (ai) {
    try {
      const prompt = `You are a world-class CMO and senior marketing strategist.
Analyze the following business and campaign requirements, and generate a comprehensive, highly tactical marketing strategy.

BUSINESS DETAILS:
- Business Name: ${campaign.businessName}
- Industry: ${campaign.industry}
- Product/Service: ${campaign.productName}
- Description: ${campaign.productDescription}
- Value Proposition: ${campaign.valueProposition}

CAMPAIGN PARAMETERS:
- Name: ${campaign.name}
- Goal: ${campaign.goal}
- Primary Objective: ${campaign.primaryObjective}
- Target Audience Details: Age: ${campaign.audienceAgeRange}, Location: ${campaign.audienceLocation}, Occupation: ${campaign.audienceOccupation}, Interests: ${campaign.audienceInterests}, Pain Points: ${campaign.audiencePainPoints}, Buying Behavior: ${campaign.audienceBuyingBehavior}
- Audience Narrative: ${campaign.audienceDescription}
- Budget: ${campaign.budget}
- Duration: ${campaign.durationDays} days (${campaign.startDate} to ${campaign.endDate})
- Primary Channel: ${campaign.primaryChannel}
- Secondary Channels: ${campaign.secondaryChannels.join(', ')}
- Brand Voice: ${campaign.brandVoice} ${campaign.customBrandVoice ? `(${campaign.customBrandVoice})` : ''}

Respond with pure JSON conforming to this schema:
{
  "objective": "A sharp, specific 1-2 sentence statement of the marketing outcome",
  "targetAudience": "Synthesized persona summary focusing on motivations and triggers",
  "valueProposition": "Refined customer-centric promise tailored for this campaign",
  "positioning": "Strategic market positioning relative to alternatives",
  "coreMessage": "The memorable central tagline and narrative anchor",
  "campaignTheme": "The creative thematic wrapper (e.g. 'Unleash Your Morning Potential')",
  "marketingFunnel": {
    "top": "Tactics and hook to generate high-intent awareness (TOFU)",
    "middle": "Nurturing, social proof, and consideration mechanics (MOFU)",
    "bottom": "Conversion triggers, friction-reducing offers, and closing mechanics (BOFU)"
  },
  "contentPillars": [
    "Pillar 1 with brief tactical angle",
    "Pillar 2 with brief tactical angle",
    "Pillar 3 with brief tactical angle",
    "Pillar 4 with brief tactical angle"
  ],
  "recommendedChannels": ["Channel 1", "Channel 2", "Channel 3"],
  "ctaStrategy": "Prescriptive multi-step Call To Action guidance",
  "kpis": [
    "Measurable KPI 1 with target metric",
    "Measurable KPI 2 with target metric",
    "Measurable KPI 3 with target metric",
    "Measurable KPI 4 with target metric"
  ]
}`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.7,
        },
      });

      const text = response.text?.trim() || '';
      const parsed = JSON.parse(text);
      return {
        objective: parsed.objective || campaign.primaryObjective,
        targetAudience: parsed.targetAudience || campaign.audienceDescription,
        valueProposition: parsed.valueProposition || campaign.valueProposition,
        positioning: parsed.positioning || `Leading high-impact ${campaign.industry} solution`,
        coreMessage: parsed.coreMessage || `${campaign.productName}: Engineered for remarkable results.`,
        campaignTheme: parsed.campaignTheme || `${campaign.name} Activation`,
        marketingFunnel: {
          top: parsed.marketingFunnel?.top || 'Audience discovery via viral social hooks and high-reach video previews.',
          middle: parsed.marketingFunnel?.middle || 'Educational case studies, interactive product demos, and peer reviews.',
          bottom: parsed.marketingFunnel?.bottom || 'Time-sensitive pilot offer and streamlined friction-free onboarding.',
        },
        contentPillars: Array.isArray(parsed.contentPillars) ? parsed.contentPillars : [
          'Product Innovation & Differentiators',
          'Customer Success & Transformation Stories',
          'Industry Insights & Tactical How-Tos',
          'Behind-the-Scenes & Community Culture'
        ],
        recommendedChannels: (Array.isArray(parsed.recommendedChannels) && parsed.recommendedChannels.length > 0)
          ? parsed.recommendedChannels
          : [campaign.primaryChannel, ...campaign.secondaryChannels],
        ctaStrategy: parsed.ctaStrategy || 'Drive early adopters to interactive demo with zero-risk trial guarantee.',
        kpis: Array.isArray(parsed.kpis) ? parsed.kpis : [
          'Target 15% conversion on primary campaign landing page',
          'Achieve 4.8% engagement rate on core social activations',
          'Generate 450+ qualified inbound leads in first 30 days',
          'Attain CAC under target budget allocation'
        ],
      };
    } catch (err) {
      console.warn('Gemini strategy generation failed, using intelligent domain fallback:', err);
    }
  }

  // Domain-rich fallback strategist
  return {
    objective: `Drive measurable ${campaign.goal.toLowerCase()} for ${campaign.productName} by engaging ${campaign.audienceOccupation || 'qualified professionals'} with a ${campaign.brandVoice.toLowerCase()} narrative across ${campaign.primaryChannel}.`,
    targetAudience: `${campaign.audienceAgeRange || '25-45'} ${campaign.audienceOccupation || 'professionals'} facing ${campaign.audiencePainPoints || 'productivity barriers'}, motivated by ${campaign.audienceInterests || 'growth and modern tools'}.`,
    valueProposition: campaign.valueProposition || `${campaign.productName} delivers faster, predictable outcomes without the operational overhead.`,
    positioning: `The modern standard for ${campaign.industry}, bridging high-performance capability with intuitive workflow velocity.`,
    coreMessage: `Experience what happens when ${campaign.productName} eliminates friction and unlocks your team's real momentum.`,
    campaignTheme: `The Next Leap: Modern ${campaign.industry} Made Actionable`,
    marketingFunnel: {
      top: `High-visibility thought leadership on ${campaign.primaryChannel} highlighting the hidden costs of outdated workflows.`,
      middle: `Deep-dive product breakdowns, comparative benchmarks, and user outcome showcases via ${campaign.secondaryChannels[0] || 'Email'}.`,
      bottom: `Targeted conversion sequence featuring customer proofs and limited onboarding incentives.`,
    },
    contentPillars: [
      `The Core Problem: Why traditional approaches fail in ${campaign.industry}`,
      `Practical Mastery: Step-by-step frameworks our audience can apply today`,
      `Product in Action: Live workflow walkthroughs and friction-free results`,
      `Customer Proof: Real teams sharing their measured ROI`
    ],
    recommendedChannels: [campaign.primaryChannel, ...campaign.secondaryChannels.slice(0, 3)],
    ctaStrategy: `Anchor primary touchpoints with "Start Your Free Growth Sprint", backed by zero-commitment interactive walkthroughs.`,
    kpis: [
      `18.5% Click-through-rate across primary ${campaign.primaryChannel} activations`,
      `320+ MQLs generated within first ${campaign.durationDays} days`,
      `$0.82 Average cost-per-engagement across secondary channels`,
      `42% Lead-to-demo booking conversion rate`
    ],
  };
}
