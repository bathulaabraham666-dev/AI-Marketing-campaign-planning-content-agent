import { getGeminiClient } from './geminiClient.js';
import type { Campaign, CampaignStrategy, ContentType } from '../../src/types.js';

export interface GenerateContentInput {
  campaign: Campaign;
  strategy?: CampaignStrategy;
  type: ContentType;
  platform?: string;
  targetAudience?: string;
  tone?: string;
  length?: 'short' | 'medium' | 'long';
  callToAction?: string;
  keywords?: string[];
  additionalInstructions?: string;
}

export interface GeneratedContentOutput {
  title: string;
  headline: string;
  body: string;
  callToAction: string;
}

export async function generateMarketingContent(
  input: GenerateContentInput
): Promise<GeneratedContentOutput> {
  const ai = getGeminiClient();
  const { campaign, strategy, type, targetAudience, tone, length, callToAction, keywords, additionalInstructions } = input;

  const toneToUse = tone || campaign.brandVoice;
  const audienceToUse = targetAudience || campaign.audienceDescription;
  const ctaToUse = callToAction || strategy?.ctaStrategy || 'Explore Now';

  if (ai) {
    try {
      const prompt = `You are an elite creative copywriter and direct-response marketing specialist.
Write exceptional, publication-ready copy for a: ${type}.

CAMPAIGN CONTEXT:
- Product/Service: ${campaign.productName} (${campaign.businessName})
- Value Proposition: ${campaign.valueProposition}
- Campaign Goal: ${campaign.goal}
- Brand Voice / Tone: ${toneToUse}
- Target Audience: ${audienceToUse}
- Strategic Core Message: ${strategy?.coreMessage || campaign.valueProposition}
- Campaign Theme: ${strategy?.campaignTheme || campaign.name}
- Desired CTA: ${ctaToUse}
- Length Constraint: ${length || 'medium'}
- Target Keywords: ${keywords?.join(', ') || 'N/A'}
- Additional Instructions: ${additionalInstructions || 'N/A'}

PLATFORM SPECIFIC REQUIREMENTS FOR "${type}":
- If Social (Instagram/LinkedIn/X): Include punchy hook, engaging line breaks, high-retention formatting, and relevant hashtags where appropriate.
- If Email: Include subject line + preview hook, warm greeting, compelling narrative, clear value exchange, and persuasive CTA button copy.
- If Ad Copy: Include Primary Hook, 3 value drivers, friction-killer, and high-CTR CTA.
- If Landing Page: Include Hero Header, sub-headline, 3 benefit clusters, social proof placeholder, and conversion trigger.

Return pure JSON matching this exact structure:
{
  "title": "Descriptive internal title for this asset",
  "headline": "Compelling primary hook or headline",
  "body": "The complete, formatted copy formatted with clean markdown / paragraph breaks",
  "callToAction": "The exact button or concluding action text"
}`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.75,
        },
      });

      const text = response.text?.trim() || '';
      const parsed = JSON.parse(text);
      if (parsed.body) {
        return {
          title: parsed.title || `${type} — ${campaign.name}`,
          headline: parsed.headline || `${campaign.productName} for ${campaign.audienceOccupation || 'Leaders'}`,
          body: parsed.body,
          callToAction: parsed.callToAction || ctaToUse,
        };
      }
    } catch (err) {
      console.warn('Gemini content generation failed, using fallback generator:', err);
    }
  }

  // Domain fallback copy generator tailored to content type
  if (type === 'Instagram Post' || type === 'Instagram Reel') {
    return {
      title: `${type} Announcement Hook`,
      headline: `Stop compromising on ${campaign.industry.toLowerCase()} velocity.`,
      body: `Most ${campaign.audienceOccupation || 'teams'} waste hours wrestling with outdated tools.

Here is the secret: It doesn't have to be complicated.

When we designed ${campaign.productName}, we focused on one thing: ${campaign.valueProposition}

Here is what happens on day one:
1. Friction disappears from your daily workflow
2. Your turnaround time drops by 60%
3. You get back to doing what actually drives growth

Tap the link in bio to see the interactive breakdown before our launch window closes.

#${campaign.industry.replace(/\s+/g, '')} #${campaign.businessName.replace(/\s+/g, '')} #Innovation #GrowthStrategy`,
      callToAction: `Tap link in bio to try ${campaign.productName}`,
    };
  }

  if (type === 'Email') {
    return {
      title: `Campaign Welcome & Value Sprint Email`,
      headline: `Subject: Why traditional ${campaign.industry} approaches are costing you time`,
      body: `Hi there,

If you are like most ${campaign.audienceOccupation || 'operators'}, you've probably noticed that traditional workflows just don't scale.

You spend more time managing logistics than actually executing on your core strategy.

That is exactly why we built ${campaign.productName}.

With ${campaign.productName}:
• ${campaign.valueProposition}
• Built specifically for ${audienceToUse}
• Deploys in minutes with zero onboarding headache

We've opened up early access for this campaign cycle. Claim your spot below and experience the difference yourself.`,
      callToAction: `Claim Your Early Access Sprint`,
    };
  }

  if (type === 'Ad Copy') {
    return {
      title: `High-Intent Conversion Ad Matrix`,
      headline: `Finally: ${campaign.productName} Built for Real Impact.`,
      body: `Tired of clunky workarounds and slow turnarounds?

${campaign.productName} is the all-in-one solution for ${audienceToUse}.
Get ${campaign.valueProposition.toLowerCase()} without the typical complexity.

✓ Trusted by industry innovators
✓ Instant setup in under 5 minutes
✓ 100% money-back guarantee during launch week`,
      callToAction: `Get Started Free — No Credit Card Required`,
    };
  }

  if (type === 'Landing Page') {
    return {
      title: `Core Campaign Landing Page Hero & Proof`,
      headline: `The Modern Way to Master ${campaign.industry}.`,
      body: `## Hero Section
**Main Headline:** ${campaign.valueProposition}
**Subheadline:** Discover how ${campaign.productName} empowers ${audienceToUse} to eliminate bottlenecks and accelerate real-world results.

### 3 Core Pillars:
1. **Effortless Precision:** Automate manual overhead and focus on high-leverage strategic outcomes.
2. **Built for Collaboration:** Keep your entire team aligned with real-time clarity and unified intelligence.
3. **Measurable ROI:** Track quantifiable performance gains from day one.

### What Users Are Saying:
*"Switching to ${campaign.productName} was the highest ROI decision we made this quarter."*`,
      callToAction: `Start Your Free Campaign Sprint Today`,
    };
  }

  return {
    title: `${type} Piece for ${campaign.name}`,
    headline: `${campaign.productName}: ${campaign.valueProposition}`,
    body: `Designed specifically for ${audienceToUse}, ${campaign.productName} delivers exceptional speed and reliability across every touchpoint.

Key highlights:
- ${campaign.valueProposition}
- Aligned directly with our ${campaign.goal.toLowerCase()} objectives
- Tailored for high-impact ${campaign.primaryChannel} delivery`,
    callToAction: ctaToUse,
  };
}
