import type { WorkflowStep, WorkflowRun, Campaign } from '../../src/types.js';
import { generateCampaignStrategy } from './strategyAgent.js';
import { decomposeStrategyIntoTasks } from './taskPlannerAgent.js';
import { generateMarketingContent } from './contentAgent.js';
import { evaluateContent } from './evaluatorAgent.js';

export function initializeWorkflowRun(campaignId: string): WorkflowRun {
  const steps: WorkflowStep[] = [
    {
      id: 'step_1_validate',
      name: 'Validate Campaign Inputs',
      description: 'Audit campaign goals, audience parameters, timeline, and budget allocations for feasibility.',
      status: 'PENDING',
    },
    {
      id: 'step_2_research',
      name: 'Market & Competitive Research',
      description: 'Analyze industry landscape, competitor positioning, and category benchmarks.',
      status: 'PENDING',
    },
    {
      id: 'step_3_audience',
      name: 'Audience Persona Synthesis',
      description: 'Synthesize demographic, psychographic, and emotional buying triggers into target customer models.',
      status: 'PENDING',
    },
    {
      id: 'step_4_strategy',
      name: 'Campaign Strategy Generation',
      description: 'Synthesize full marketing funnel, content pillars, positioning, and core messaging framework.',
      status: 'PENDING',
    },
    {
      id: 'step_5_tasks',
      name: 'Smart Task Decomposition',
      description: 'Deconstruct strategy into prioritized, actionable operational workstreams and milestones.',
      status: 'PENDING',
    },
    {
      id: 'step_6_content_planning',
      name: 'Content Architecture & Planning',
      description: 'Map content formats to funnel stages across primary and secondary distribution channels.',
      status: 'PENDING',
    },
    {
      id: 'step_7_content_gen',
      name: 'Creative Content Generation',
      description: 'Generate high-converting copy assets across primary touchpoints with customized tone and brand voice.',
      status: 'PENDING',
    },
    {
      id: 'step_8_evaluation',
      name: 'Quality & Conversion Evaluation',
      description: 'Score clarity, brand alignment, audience fit, platform resonance, and CTA power using AI metrics.',
      status: 'PENDING',
    },
    {
      id: 'step_9_review',
      name: 'Human Review & Approval',
      description: 'Stage assets for editorial review, revisions, and executive sign-off.',
      status: 'PENDING',
    },
    {
      id: 'step_10_complete',
      name: 'Campaign Activation Ready',
      description: 'Consolidate campaign intelligence into persistent memory and prepare export manifest.',
      status: 'PENDING',
    },
  ];

  return {
    id: `wf_${Date.now()}`,
    campaignId,
    status: 'RUNNING',
    currentStepIndex: 0,
    steps,
    startedAt: new Date().toISOString(),
  };
}
