import { getGeminiClient } from './geminiClient.js';
import type { Campaign, CampaignStrategy, CampaignTask } from '../../src/types.js';

export async function decomposeStrategyIntoTasks(
  campaign: Campaign,
  strategy: CampaignStrategy
): Promise<Array<Omit<CampaignTask, 'id' | 'campaignId' | 'createdAt' | 'updatedAt'>>> {
  const ai = getGeminiClient();

  if (ai) {
    try {
      const prompt = `You are an agile marketing operations lead and project manager.
Decompose the following marketing strategy into 6 to 8 highly actionable, concrete tasks.
Distribute them across priorities (urgent, high, medium, low) and indicate dependencies, assignees, and related content types.

CAMPAIGN:
- Name: ${campaign.name}
- Goal: ${campaign.goal}
- Duration: ${campaign.durationDays} days
- Primary Channel: ${campaign.primaryChannel}

STRATEGY:
- Objective: ${strategy.objective}
- Theme: ${strategy.campaignTheme}
- Funnel Top: ${strategy.marketingFunnel.top}
- Funnel Middle: ${strategy.marketingFunnel.middle}
- Funnel Bottom: ${strategy.marketingFunnel.bottom}
- Pillars: ${strategy.contentPillars.join(', ')}
- CTA Strategy: ${strategy.ctaStrategy}

Return pure JSON array of tasks matching this schema:
[
  {
    "title": "Actionable verb-led task title",
    "description": "Specific execution steps, deliverables, and acceptance criteria",
    "priority": "urgent" | "high" | "medium" | "low",
    "status": "todo" | "in_progress",
    "dueDate": "YYYY-MM-DD",
    "aiGenerated": true,
    "dependencies": ["Task dependency title if applicable"],
    "assignee": "Role or team member, e.g. Content Lead, Growth Designer, Copywriter",
    "relatedContentType": "Instagram Reel, Email, Landing Page, Ad Copy, etc."
  }
]`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.6,
        },
      });

      const text = response.text?.trim() || '';
      const parsed = JSON.parse(text);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.map((item) => ({
          title: item.title || 'Execute marketing initiative',
          description: item.description || 'Deliver tactical asset on schedule.',
          priority: ['urgent', 'high', 'medium', 'low'].includes(item.priority) ? item.priority : 'medium',
          status: ['todo', 'in_progress', 'review', 'done'].includes(item.status) ? item.status : 'todo',
          dueDate: item.dueDate || new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0],
          aiGenerated: true,
          dependencies: Array.isArray(item.dependencies) ? item.dependencies : [],
          assignee: item.assignee || 'Marketing Operations',
          relatedContentType: item.relatedContentType,
        }));
      }
    } catch (err) {
      console.warn('Gemini task decomposition failed, using fallback planner:', err);
    }
  }

  // High-fidelity domain fallback tasks
  const start = new Date();
  const plusDays = (days: number) => {
    const d = new Date(start);
    d.setDate(d.getDate() + days);
    return d.toISOString().split('T')[0];
  };

  return [
    {
      title: `Finalize Campaign Messaging & Narrative Anchor`,
      description: `Refine core campaign hooks, proof points, and tone guidelines aligned with "${strategy.campaignTheme}".`,
      priority: 'urgent',
      status: 'in_progress',
      dueDate: plusDays(2),
      aiGenerated: true,
      dependencies: [],
      assignee: 'Head of Content',
      relatedContentType: 'Headline',
    },
    {
      title: `Draft High-Converting Landing Page Copy`,
      description: `Structure the hero value prop, customer objection handling, feature highlights, and primary conversion CTA for ${campaign.productName}.`,
      priority: 'high',
      status: 'todo',
      dueDate: plusDays(4),
      aiGenerated: true,
      dependencies: ['Finalize Campaign Messaging & Narrative Anchor'],
      assignee: 'Conversion Copywriter',
      relatedContentType: 'Landing Page',
    },
    {
      title: `Produce 3 High-Energy Social Video Teasers`,
      description: `Script and storyboard 3 short-form videos tailored for ${campaign.primaryChannel} highlighting the before-and-after user transformation.`,
      priority: 'high',
      status: 'todo',
      dueDate: plusDays(6),
      aiGenerated: true,
      dependencies: ['Finalize Campaign Messaging & Narrative Anchor'],
      assignee: 'Video & Creative Lead',
      relatedContentType: 'Instagram Reel',
    },
    {
      title: `Configure 3-Part Automated Email Nurture Sequence`,
      description: `Set up the welcome, social proof breakdown, and limited-time offer triggers in marketing automation platform.`,
      priority: 'medium',
      status: 'todo',
      dueDate: plusDays(8),
      aiGenerated: true,
      dependencies: ['Draft High-Converting Landing Page Copy'],
      assignee: 'Lifecycle Marketing Manager',
      relatedContentType: 'Email',
    },
    {
      title: `Launch Paid Acquisition Creative Matrix`,
      description: `Set up ad variations across headline angles, visual assets, and audience lookalikes targeting ${campaign.audienceOccupation || 'core segments'}.`,
      priority: 'medium',
      status: 'todo',
      dueDate: plusDays(10),
      aiGenerated: true,
      dependencies: ['Draft High-Converting Landing Page Copy'],
      assignee: 'Performance Marketer',
      relatedContentType: 'Ad Copy',
    },
    {
      title: `Set Up KPI Tracking & Conversion Telemetry`,
      description: `Verify Google Analytics 4 event tags, UTM parameters, and custom conversion goals for ${strategy.kpis[0] || 'primary objective'}.`,
      priority: 'low',
      status: 'todo',
      dueDate: plusDays(12),
      aiGenerated: true,
      dependencies: [],
      assignee: 'Marketing Ops',
    },
  ];
}
