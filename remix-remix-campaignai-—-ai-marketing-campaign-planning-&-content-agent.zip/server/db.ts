import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import type {
  Campaign,
  CampaignStrategy,
  CampaignTask,
  CampaignContent,
  ContentEvaluation,
  CampaignMemory,
  WorkflowRun,
  ChatMessage,
  UserProfile,
  AnalyticsSummary,
  EvaluationTestCase,
} from '../src/types.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DB_FILE = path.resolve(__dirname, '../../.campaigns_db.json');

export interface DatabaseSchema {
  users: UserProfile[];
  campaigns: Campaign[];
  strategies: CampaignStrategy[];
  tasks: CampaignTask[];
  content: CampaignContent[];
  evaluations: ContentEvaluation[];
  memories: CampaignMemory[];
  conversations: Record<string, ChatMessage[]>;
  workflows: Record<string, WorkflowRun>;
  testCases: EvaluationTestCase[];
}

function getSeedData(): DatabaseSchema {
  const defaultUser: UserProfile = {
    id: 'user_default',
    name: 'Sarah Chen',
    email: 'sarah.chen@campaignai.co',
    businessName: 'FitPulse Technologies',
    industry: 'Health & Fitness Tech',
    website: 'https://fitpulse.app',
    defaultBrandVoice: 'Bold',
    defaultAudience: 'Active urban professionals aged 25-42 seeking efficient daily health routines',
    aiModel: 'gemini-3.8-flash',
  };

  const seedCampaignId = 'camp_summer_fitness';
  const seedCampaign: Campaign = {
    id: seedCampaignId,
    userId: defaultUser.id,
    name: 'Summer Fitness App Launch',
    description: 'High-momentum seasonal acquisition campaign launching the new AI-powered adaptive workout feature for Summer 2026.',
    businessName: 'FitPulse Technologies',
    website: 'https://fitpulse.app',
    industry: 'Health & Fitness Tech',
    productName: 'FitPulse Adaptive',
    productDescription: 'An intelligent personal fitness app that dynamically adjusts workout plans based on recovery, sleep telemetry, and daily energy levels.',
    valueProposition: 'Work out smarter, not harder. Real-time adaptive workout plans that evolve with your daily recovery data.',
    goal: 'Product Launch',
    primaryObjective: 'Acquire 10,000 monthly active subscribers with a sub-$14 CAC during the 60-day summer launch window.',
    audienceAgeRange: '24 - 40 years old',
    audienceLocation: 'North America & Western Europe (Urban metros)',
    audienceOccupation: 'Product managers, founders, corporate professionals, creative directors',
    audienceInterests: 'Biohacking, functional strength, HIIT, wearable health trackers, outdoor athletics',
    audiencePainPoints: 'Rigid fitness plans that fail when work gets busy; overtraining or skipping workouts due to fatigue',
    audienceBuyingBehavior: 'High willingness to subscribe for demonstrable health optimization; relies on peer reviews and clean mobile UX',
    audienceDescription: 'Busy, health-conscious urban professionals who value time efficiency and seek data-driven fitness coaching without rigid schedules.',
    budget: '$35,000',
    durationDays: 60,
    startDate: '2026-06-01',
    endDate: '2026-07-31',
    primaryChannel: 'Instagram',
    secondaryChannels: ['Email', 'YouTube', 'LinkedIn'],
    brandVoice: 'Bold',
    customBrandVoice: 'Energetic, scientifically grounded, empowering, zero fluff',
    status: 'in_progress',
    progressPercentage: 68,
    createdAt: '2026-05-15T09:00:00.000Z',
    updatedAt: '2026-05-20T14:30:00.000Z',
  };

  const seedStrategy: CampaignStrategy = {
    id: 'strat_summer_fitness',
    campaignId: seedCampaignId,
    objective: 'Establish FitPulse Adaptive as the premier summer fitness accelerator, converting time-strapped professionals into committed annual subscribers.',
    targetAudience: 'High-achieving urban professionals (24-40) who struggle with workout consistency due to volatile work schedules.',
    valueProposition: 'The only workout companion that synchronizes with your body’s daily recovery state to guarantee results without burnout.',
    positioning: 'Positioned above static workout apps (Peloton/Nike) as an intelligent recovery-first personal coaching platform.',
    coreMessage: 'Never fail a workout plan again. Adaptive training engineered for real-life schedules.',
    campaignTheme: 'Summer Momentum: Your Peak Season, Powered by Recovery Intelligence',
    marketingFunnel: {
      top: 'Viral short-form video hooks on Instagram Reels & TikTok highlighting "The 20-minute adaptive workout myth buster".',
      middle: 'Interactive recovery score quiz and 5-day biohacking email guide showcasing comparative biometric results.',
      bottom: 'Exclusive "Summer Founding Member" 30-day risk-free pilot with priority coaching telemetry.',
    },
    contentPillars: [
      'The Science of Adaptive Recovery (Biometric optimization)',
      'Time-Crunched Workouts (20-30 min high-impact routines)',
      'Member Transformation Stories (Real professionals, zero burn-out)',
      'Summer Sprint Challenges (Community motivation & leaderboards)',
    ],
    recommendedChannels: ['Instagram', 'Email', 'YouTube', 'LinkedIn'],
    ctaStrategy: 'Anchor touchpoints with "Unlock Your 30-Day Adaptive Pass" backed by an unconditional zero-risk guarantee.',
    kpis: [
      '10,000 New trial starts at CAC < $14.50',
      '4.2% Blended conversion rate on primary landing page',
      '62% Day-14 subscriber retention velocity',
      '350,000+ Organic video views across Instagram activations',
    ],
    updatedAt: '2026-05-18T11:20:00.000Z',
  };

  const seedTasks: CampaignTask[] = [
    {
      id: 'task_1',
      campaignId: seedCampaignId,
      title: 'Define Launch Messaging & Narrative Anchor',
      description: 'Lock in core tagline, hero objection handlers, and biohacking proof points for FitPulse Adaptive.',
      priority: 'urgent',
      status: 'done',
      dueDate: '2026-05-18',
      aiGenerated: true,
      dependencies: [],
      assignee: 'Sarah Chen (CMO)',
      relatedContentType: 'Headline',
      createdAt: '2026-05-16T10:00:00.000Z',
      updatedAt: '2026-05-18T16:00:00.000Z',
    },
    {
      id: 'task_2',
      campaignId: seedCampaignId,
      title: 'Produce High-Energy Instagram Announcement Reel',
      description: 'Edit dynamic 30-second mobile screen capture showing real-time workout adaptation based on Apple Watch sleep score.',
      priority: 'high',
      status: 'in_progress',
      dueDate: '2026-05-24',
      aiGenerated: true,
      dependencies: ['Define Launch Messaging & Narrative Anchor'],
      assignee: 'Creative Video Lead',
      relatedContentType: 'Instagram Reel',
      createdAt: '2026-05-16T10:00:00.000Z',
      updatedAt: '2026-05-19T11:00:00.000Z',
    },
    {
      id: 'task_3',
      campaignId: seedCampaignId,
      title: 'Configure Launch VIP Announcement Email',
      description: 'Stage 3-email nurture sequence for 45,000 pre-registered waitlist members highlighting early-bird pricing.',
      priority: 'high',
      status: 'review',
      dueDate: '2026-05-26',
      aiGenerated: true,
      dependencies: ['Define Launch Messaging & Narrative Anchor'],
      assignee: 'Email Copywriter',
      relatedContentType: 'Email',
      createdAt: '2026-05-16T10:00:00.000Z',
      updatedAt: '2026-05-20T10:00:00.000Z',
    },
    {
      id: 'task_4',
      campaignId: seedCampaignId,
      title: 'Finalize Campaign Hero Landing Page Copy',
      description: 'Ensure conversion copy incorporates before-after recovery diagrams and frictionless App Store deep-links.',
      priority: 'urgent',
      status: 'done',
      dueDate: '2026-05-21',
      aiGenerated: true,
      dependencies: ['Define Launch Messaging & Narrative Anchor'],
      assignee: 'Lead UX Writer',
      relatedContentType: 'Landing Page',
      createdAt: '2026-05-16T10:00:00.000Z',
      updatedAt: '2026-05-21T18:00:00.000Z',
    },
    {
      id: 'task_5',
      campaignId: seedCampaignId,
      title: 'Deploy Paid Ad Creative Matrix on Meta',
      description: 'Upload 12 headline iterations and 4 video cutdowns targeting lookalikes of WHOOP and Oura ring users.',
      priority: 'medium',
      status: 'todo',
      dueDate: '2026-05-29',
      aiGenerated: true,
      dependencies: ['Produce High-Energy Instagram Announcement Reel'],
      assignee: 'Performance Growth Marketer',
      relatedContentType: 'Ad Copy',
      createdAt: '2026-05-16T10:00:00.000Z',
      updatedAt: '2026-05-16T10:00:00.000Z',
    },
  ];

  const eval1: ContentEvaluation = {
    id: 'eval_1',
    contentId: 'content_1',
    clarity: 92,
    brandAlignment: 94,
    audienceFit: 90,
    platformFit: 95,
    ctaStrength: 88,
    readability: 96,
    overallScore: 93,
    strengths: [
      'Opening hook ("Tired of workouts that treat you like a robot?") creates instant visceral empathy.',
      'Bullet structure cleanly contrasts rigid fitness apps with adaptive intelligence.',
      'Audio sync cue matches high-energy Instagram Reel tempo perfectly.',
    ],
    issues: [
      'Call to action in subtitle could more explicitly mention the 30-day free trial guarantee.',
    ],
    suggestions: [
      'Add an on-screen sticker graphic: "Syncs with Apple Watch & Garmin"',
      'Test a second hook variant emphasizing recovery over burn-out.',
    ],
    evaluatedAt: '2026-05-19T14:10:00.000Z',
  };

  const seedContent: CampaignContent[] = [
    {
      id: 'content_1',
      campaignId: seedCampaignId,
      category: 'social',
      type: 'Instagram Reel',
      title: 'Launch Reel: The Adaptive Recovery Difference',
      headline: 'Still following a static workout plan in 2026?',
      body: `[VISUAL: Fast-paced cut between tired alarm snooze and smart workout adjustment on mobile screen]

VOICEOVER:
Most fitness apps treat you like a machine that never sleeps bad, never has long meetings, and never gets stressed.

Then you miss two days... and quit.

FitPulse Adaptive is different.
Every morning, it checks your recovery data.
• Slept 8 hours? Crushing 35-min hypertrophy.
• Slept 5 hours? Smart 18-min mobility & active recovery.

You make progress every single day without burning out.

Tap the link in bio to claim your 30-Day Summer Adaptive Pass today.

#AdaptiveFitness #BiohackingDaily #SmartWorkouts #FitPulseLaunch #RecoveryFirst`,
      callToAction: 'Tap link in bio to claim your 30-Day Adaptive Pass',
      targetAudience: 'Active urban professionals',
      tone: 'Bold & Energizing',
      platform: 'Instagram',
      status: 'approved',
      versions: [
        {
          id: 'ver_1',
          versionNumber: 1,
          title: 'Launch Reel: The Adaptive Recovery Difference',
          body: 'Original draft with technical biometric jargon...',
          createdAt: '2026-05-18T10:00:00.000Z',
          note: 'Initial draft',
        },
        {
          id: 'ver_2',
          versionNumber: 2,
          title: 'Launch Reel: The Adaptive Recovery Difference',
          body: `VOICEOVER: Most fitness apps treat you like a machine...`,
          createdAt: '2026-05-19T14:00:00.000Z',
          note: 'Polished for higher emotional resonance and punchy cadence',
        },
      ],
      evaluation: eval1,
      createdAt: '2026-05-18T10:00:00.000Z',
      updatedAt: '2026-05-19T14:15:00.000Z',
    },
    {
      id: 'content_2',
      campaignId: seedCampaignId,
      category: 'marketing',
      type: 'Email',
      title: 'VIP Waitlist Invitation Email',
      headline: 'Subject: Your workout plan should know when you had a brutal week',
      body: `Hey {{first_name}},

Let’s be honest: standard workout plans are broken.

They assume life is predictable. But between 7:00 AM standups, late client deadlines, and flight delays, life rarely cooperates.

When you try to force a grueling 60-minute leg day on 4 hours of sleep, one of two things happens:
1. You get injured or exhausted
2. You feel guilty and stop working out entirely

That is why we created **FitPulse Adaptive**.

Instead of forcing you into a rigid calendar, FitPulse analyzes your heart rate variability, sleep stages, and subjective fatigue every single morning.

It automatically shapes your workout for maximum ROI:
✓ High readiness? Push for PRs.
✓ Low readiness? Focus on restorative stamina and joint health.

As a member of our early waitlist, your first 30 days are 100% on us.

Click below to activate your adaptive summer coaching pass before public release next Tuesday.`,
      callToAction: 'Activate Your 30-Day Free Adaptive Pass',
      targetAudience: 'Waitlist Subscribers',
      tone: 'Empathetic & Authoritative',
      platform: 'Email',
      status: 'approved',
      versions: [],
      createdAt: '2026-05-19T16:00:00.000Z',
      updatedAt: '2026-05-20T10:00:00.000Z',
    },
    {
      id: 'content_3',
      campaignId: seedCampaignId,
      category: 'marketing',
      type: 'Ad Copy',
      title: 'Performance Meta Conversion Ad',
      headline: 'Work out with your body, not against it.',
      body: `Tired of rigid workout programs that don't care about your real life?

Meet FitPulse Adaptive:
The AI coach that recalculates your workout the second your alarm goes off based on your actual recovery score.

• 20–35 min time-efficient sessions
• Automatic sync with Apple Watch, Oura & Whoop
• Zero guilt, 100% progressive overload

Join 10,000+ professionals making their summer fitness effortless.`,
      callToAction: 'Install FitPulse & Start Free Trial',
      targetAudience: 'Wearable health users (25-45)',
      tone: 'Direct & Action-Oriented',
      platform: 'Facebook / Instagram Ads',
      status: 'pending_review',
      versions: [],
      createdAt: '2026-05-20T11:00:00.000Z',
      updatedAt: '2026-05-20T11:00:00.000Z',
    },
  ];

  const seedMemories: CampaignMemory[] = [
    {
      id: 'mem_1',
      campaignId: seedCampaignId,
      userId: defaultUser.id,
      category: 'user',
      key: 'Primary Brand Voice Mandate',
      content: 'Maintain a bold, scientific, and encouraging tone. Always avoid shaming or toxic hustle culture tropes.',
      source: 'User Onboarding Setup',
      createdAt: '2026-05-15T09:10:00.000Z',
    },
    {
      id: 'mem_2',
      campaignId: seedCampaignId,
      userId: defaultUser.id,
      category: 'campaign',
      key: 'Core Hook Differentiator',
      content: 'Always emphasize "Recovery-First" and daily dynamic recalculation over arbitrary 60-minute sweat sessions.',
      source: 'Strategy Agent Synthesis',
      createdAt: '2026-05-18T11:22:00.000Z',
    },
    {
      id: 'mem_3',
      campaignId: seedCampaignId,
      userId: defaultUser.id,
      category: 'campaign',
      key: 'Audience Wearable Ecosystem',
      content: '82% of target audience uses wearables (Apple Watch, Whoop, Oura, Garmin). Mention biometric sync capability across top-of-funnel ads.',
      source: 'Research & Persona Step',
      createdAt: '2026-05-18T11:25:00.000Z',
    },
    {
      id: 'mem_4',
      campaignId: seedCampaignId,
      userId: defaultUser.id,
      category: 'conversation',
      key: 'User Rejection of Price Discounts',
      content: 'User explicitly instructed not to run heavy price slash promotions; focus instead on 30-day risk-free trial value.',
      source: 'AI Assistant Chat Session',
      createdAt: '2026-05-19T15:30:00.000Z',
    },
  ];

  const seedWorkflow: WorkflowRun = {
    id: 'wf_seed_summer',
    campaignId: seedCampaignId,
    status: 'COMPLETED',
    currentStepIndex: 9,
    startedAt: '2026-05-18T11:00:00.000Z',
    completedAt: '2026-05-18T11:05:00.000Z',
    steps: [
      { id: 's1', name: 'Validate Campaign Inputs', description: 'Audit parameters', status: 'COMPLETED', endTime: '2026-05-18T11:00:30.000Z' },
      { id: 's2', name: 'Market & Competitive Research', description: 'Analyze landscape', status: 'COMPLETED', endTime: '2026-05-18T11:01:00.000Z' },
      { id: 's3', name: 'Audience Persona Synthesis', description: 'Model target persona', status: 'COMPLETED', endTime: '2026-05-18T11:01:30.000Z' },
      { id: 's4', name: 'Campaign Strategy Generation', description: 'Full marketing funnel', status: 'COMPLETED', endTime: '2026-05-18T11:02:10.000Z' },
      { id: 's5', name: 'Smart Task Decomposition', description: 'Decompose to Kanban', status: 'COMPLETED', endTime: '2026-05-18T11:02:45.000Z' },
      { id: 's6', name: 'Content Architecture & Planning', description: 'Map content formats', status: 'COMPLETED', endTime: '2026-05-18T11:03:15.000Z' },
      { id: 's7', name: 'Creative Content Generation', description: 'Draft multi-channel assets', status: 'COMPLETED', endTime: '2026-05-18T11:04:00.000Z' },
      { id: 's8', name: 'Quality & Conversion Evaluation', description: 'AI scoring on 6 dimensions', status: 'COMPLETED', endTime: '2026-05-18T11:04:30.000Z' },
      { id: 's9', name: 'Human Review & Approval', description: 'Editorial sign-off', status: 'COMPLETED', endTime: '2026-05-18T11:04:50.000Z' },
      { id: 's10', name: 'Campaign Activation Ready', description: 'Intelligence saved to memory', status: 'COMPLETED', endTime: '2026-05-18T11:05:00.000Z' },
    ],
  };

  const seedChat: ChatMessage[] = [
    {
      id: 'msg_1',
      campaignId: seedCampaignId,
      role: 'assistant',
      content: `Welcome to the workspace for **${seedCampaign.name}**! I have loaded your strategic pillars, 5 initial operational tasks, and 3 high-converting content drafts.\n\nHow can I help accelerate your campaign today?`,
      timestamp: '2026-05-18T11:10:00.000Z',
      suggestedActions: [
        'Review Instagram Reel draft',
        'Suggest 3 alternative hooks',
        'Generate LinkedIn thought leadership post',
      ],
    },
  ];

  const seedTestCases: EvaluationTestCase[] = [
    {
      id: 'test_1',
      scenario: 'High-Tech SaaS Product Launch',
      goal: 'Product Launch',
      inputs: { industry: 'B2B Software', channels: ['LinkedIn', 'Email'], budget: '$25k' },
      strategyPassed: true,
      taskDecompositionPassed: true,
      contentSchemaPassed: true,
      evaluationScore: 92,
      latencyMs: 1420,
      status: 'passed',
      timestamp: '2026-05-19T10:00:00.000Z',
    },
    {
      id: 'test_2',
      scenario: 'DTC E-Commerce Summer Flash Sale',
      goal: 'Sales',
      inputs: { industry: 'Apparel', channels: ['Instagram', 'TikTok'], budget: '$10k' },
      strategyPassed: true,
      taskDecompositionPassed: true,
      contentSchemaPassed: true,
      evaluationScore: 89,
      latencyMs: 1180,
      status: 'passed',
      timestamp: '2026-05-19T10:05:00.000Z',
    },
    {
      id: 'test_3',
      scenario: 'Executive Coaching Lead Generation Sprint',
      goal: 'Lead Generation',
      inputs: { industry: 'Professional Services', channels: ['LinkedIn', 'Website'], budget: '$8k' },
      strategyPassed: true,
      taskDecompositionPassed: true,
      contentSchemaPassed: true,
      evaluationScore: 94,
      latencyMs: 1350,
      status: 'passed',
      timestamp: '2026-05-19T10:10:00.000Z',
    },
    {
      id: 'test_4',
      scenario: 'Local Hospitality Brand Awareness Event',
      goal: 'Brand Awareness',
      inputs: { industry: 'Hospitality', channels: ['Instagram', 'Facebook'], budget: '$5k' },
      strategyPassed: true,
      taskDecompositionPassed: true,
      contentSchemaPassed: true,
      evaluationScore: 88,
      latencyMs: 1220,
      status: 'passed',
      timestamp: '2026-05-19T10:15:00.000Z',
    },
    {
      id: 'test_5',
      scenario: 'Mobile App Retention & Referral Sprint',
      goal: 'Customer Retention',
      inputs: { industry: 'Fintech', channels: ['Email', 'In-App'], budget: '$15k' },
      strategyPassed: true,
      taskDecompositionPassed: true,
      contentSchemaPassed: true,
      evaluationScore: 91,
      latencyMs: 1290,
      status: 'passed',
      timestamp: '2026-05-19T10:20:00.000Z',
    },
  ];

  return {
    users: [defaultUser],
    campaigns: [seedCampaign],
    strategies: [seedStrategy],
    tasks: seedTasks,
    content: seedContent,
    evaluations: [eval1],
    memories: seedMemories,
    conversations: { [seedCampaignId]: seedChat },
    workflows: { [seedCampaignId]: seedWorkflow },
    testCases: seedTestCases,
  };
}

class Database {
  private data: DatabaseSchema;

  constructor() {
    this.data = this.load();
  }

  private load(): DatabaseSchema {
    try {
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        return JSON.parse(raw);
      }
    } catch (e) {
      console.warn('Failed to read persisted DB, using seed data:', e);
    }
    const seed = getSeedData();
    this.save(seed);
    return seed;
  }

  private save(dataToSave?: DatabaseSchema) {
    try {
      fs.writeFileSync(DB_FILE, JSON.stringify(dataToSave || this.data, null, 2), 'utf-8');
    } catch (e) {
      console.warn('Failed to persist DB to file:', e);
    }
  }

  // User
  getUser(): UserProfile {
    return this.data.users[0];
  }

  updateUser(updates: Partial<UserProfile>): UserProfile {
    this.data.users[0] = { ...this.data.users[0], ...updates };
    this.save();
    return this.data.users[0];
  }

  // Campaigns
  getCampaigns(): Campaign[] {
    return this.data.campaigns.map(c => {
      const taskCount = this.data.tasks.filter(t => t.campaignId === c.id).length;
      const contentList = this.data.content.filter(ct => ct.campaignId === c.id);
      const contentCount = contentList.length;
      const evals = contentList.map(ct => ct.evaluation?.overallScore).filter(Boolean) as number[];
      const evaluationAvg = evals.length > 0 ? Math.round(evals.reduce((a, b) => a + b, 0) / evals.length) : undefined;
      const strategy = this.data.strategies.find(s => s.campaignId === c.id);

      return {
        ...c,
        strategy,
        taskCount,
        contentCount,
        evaluationAvg,
      };
    });
  }

  getCampaignById(id: string): Campaign | undefined {
    const c = this.data.campaigns.find(item => item.id === id);
    if (!c) return undefined;

    const taskCount = this.data.tasks.filter(t => t.campaignId === c.id).length;
    const contentList = this.data.content.filter(ct => ct.campaignId === c.id);
    const contentCount = contentList.length;
    const evals = contentList.map(ct => ct.evaluation?.overallScore).filter(Boolean) as number[];
    const evaluationAvg = evals.length > 0 ? Math.round(evals.reduce((a, b) => a + b, 0) / evals.length) : undefined;
    const strategy = this.data.strategies.find(s => s.campaignId === c.id);

    return {
      ...c,
      strategy,
      taskCount,
      contentCount,
      evaluationAvg,
    };
  }

  createCampaign(campaign: Omit<Campaign, 'id' | 'createdAt' | 'updatedAt' | 'progressPercentage'>): Campaign {
    const id = `camp_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const now = new Date().toISOString();
    const newCamp: Campaign = {
      ...campaign,
      id,
      progressPercentage: 10,
      createdAt: now,
      updatedAt: now,
    };
    this.data.campaigns.unshift(newCamp);
    this.save();
    return newCamp;
  }

  updateCampaign(id: string, updates: Partial<Campaign>): Campaign | undefined {
    const index = this.data.campaigns.findIndex(c => c.id === id);
    if (index === -1) return undefined;
    this.data.campaigns[index] = {
      ...this.data.campaigns[index],
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    this.save();
    return this.getCampaignById(id);
  }

  deleteCampaign(id: string): boolean {
    const initial = this.data.campaigns.length;
    this.data.campaigns = this.data.campaigns.filter(c => c.id !== id);
    this.data.strategies = this.data.strategies.filter(s => s.campaignId !== id);
    this.data.tasks = this.data.tasks.filter(t => t.campaignId !== id);
    this.data.content = this.data.content.filter(c => c.campaignId !== id);
    this.data.memories = this.data.memories.filter(m => m.campaignId !== id);
    delete this.data.conversations[id];
    delete this.data.workflows[id];
    this.save();
    return this.data.campaigns.length < initial;
  }

  // Strategy
  getStrategy(campaignId: string): CampaignStrategy | undefined {
    return this.data.strategies.find(s => s.campaignId === campaignId);
  }

  saveStrategy(strategy: Omit<CampaignStrategy, 'id' | 'updatedAt'>): CampaignStrategy {
    const existingIndex = this.data.strategies.findIndex(s => s.campaignId === strategy.campaignId);
    const now = new Date().toISOString();
    if (existingIndex >= 0) {
      this.data.strategies[existingIndex] = {
        ...this.data.strategies[existingIndex],
        ...strategy,
        updatedAt: now,
      };
      this.save();
      return this.data.strategies[existingIndex];
    } else {
      const newStrategy: CampaignStrategy = {
        ...strategy,
        id: `strat_${Date.now()}`,
        updatedAt: now,
      };
      this.data.strategies.push(newStrategy);
      this.save();
      return newStrategy;
    }
  }

  // Tasks
  getTasks(campaignId?: string): CampaignTask[] {
    if (campaignId) {
      return this.data.tasks.filter(t => t.campaignId === campaignId);
    }
    return this.data.tasks;
  }

  createTask(task: Omit<CampaignTask, 'id' | 'createdAt' | 'updatedAt'>): CampaignTask {
    const newTask: CampaignTask = {
      ...task,
      id: `task_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.data.tasks.push(newTask);
    this.save();
    return newTask;
  }

  bulkAddTasks(tasks: Array<Omit<CampaignTask, 'id' | 'createdAt' | 'updatedAt'>>): CampaignTask[] {
    const created: CampaignTask[] = [];
    const now = new Date().toISOString();
    for (const t of tasks) {
      const newTask: CampaignTask = {
        ...t,
        id: `task_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        createdAt: now,
        updatedAt: now,
      };
      this.data.tasks.push(newTask);
      created.push(newTask);
    }
    this.save();
    return created;
  }

  updateTask(id: string, updates: Partial<CampaignTask>): CampaignTask | undefined {
    const index = this.data.tasks.findIndex(t => t.id === id);
    if (index === -1) return undefined;
    this.data.tasks[index] = {
      ...this.data.tasks[index],
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    this.save();
    return this.data.tasks[index];
  }

  deleteTask(id: string): boolean {
    const initial = this.data.tasks.length;
    this.data.tasks = this.data.tasks.filter(t => t.id !== id);
    this.save();
    return this.data.tasks.length < initial;
  }

  // Content
  getContent(campaignId?: string): CampaignContent[] {
    if (campaignId) {
      return this.data.content.filter(c => c.campaignId === campaignId);
    }
    return this.data.content;
  }

  getContentById(id: string): CampaignContent | undefined {
    return this.data.content.find(c => c.id === id);
  }

  createContent(item: Omit<CampaignContent, 'id' | 'createdAt' | 'updatedAt' | 'versions'>): CampaignContent {
    const now = new Date().toISOString();
    const newContent: CampaignContent = {
      ...item,
      id: `content_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      versions: [],
      createdAt: now,
      updatedAt: now,
    };
    this.data.content.unshift(newContent);
    this.save();
    return newContent;
  }

  updateContent(id: string, updates: Partial<CampaignContent>): CampaignContent | undefined {
    const index = this.data.content.findIndex(c => c.id === id);
    if (index === -1) return undefined;

    const current = this.data.content[index];
    const newVersions = [...current.versions];

    // Archive current body to version if body is being replaced
    if (updates.body && updates.body !== current.body) {
      newVersions.push({
        id: `ver_${Date.now()}`,
        versionNumber: newVersions.length + 1,
        title: current.title,
        body: current.body,
        headline: current.headline,
        callToAction: current.callToAction,
        createdAt: new Date().toISOString(),
        note: updates.body ? 'Saved prior version before revision' : undefined,
      });
    }

    this.data.content[index] = {
      ...current,
      ...updates,
      versions: newVersions,
      updatedAt: new Date().toISOString(),
    };
    this.save();
    return this.data.content[index];
  }

  deleteContent(id: string): boolean {
    const initial = this.data.content.length;
    this.data.content = this.data.content.filter(c => c.id !== id);
    this.save();
    return this.data.content.length < initial;
  }

  // Evaluations
  saveEvaluation(contentId: string, evalData: Omit<ContentEvaluation, 'id' | 'contentId' | 'evaluatedAt'>): ContentEvaluation {
    const fullEval: ContentEvaluation = {
      ...evalData,
      id: `eval_${Date.now()}`,
      contentId,
      evaluatedAt: new Date().toISOString(),
    };
    // Update on content
    const content = this.getContentById(contentId);
    if (content) {
      content.evaluation = fullEval;
    }
    // Also save in evaluations list
    const existingIndex = this.data.evaluations.findIndex(e => e.contentId === contentId);
    if (existingIndex >= 0) {
      this.data.evaluations[existingIndex] = fullEval;
    } else {
      this.data.evaluations.push(fullEval);
    }
    this.save();
    return fullEval;
  }

  // Memories
  getMemories(campaignId?: string): CampaignMemory[] {
    if (campaignId) {
      return this.data.memories.filter(m => m.campaignId === campaignId || m.category === 'user');
    }
    return this.data.memories;
  }

  createMemory(mem: Omit<CampaignMemory, 'id' | 'createdAt'>): CampaignMemory {
    const newMem: CampaignMemory = {
      ...mem,
      id: `mem_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      createdAt: new Date().toISOString(),
    };
    this.data.memories.unshift(newMem);
    this.save();
    return newMem;
  }

  deleteMemory(id: string): boolean {
    const initial = this.data.memories.length;
    this.data.memories = this.data.memories.filter(m => m.id !== id);
    this.save();
    return this.data.memories.length < initial;
  }

  // Conversations
  getChat(campaignId: string): ChatMessage[] {
    return this.data.conversations[campaignId] || [];
  }

  addChatMessage(campaignId: string, message: Omit<ChatMessage, 'id' | 'timestamp'>): ChatMessage {
    if (!this.data.conversations[campaignId]) {
      this.data.conversations[campaignId] = [];
    }
    const fullMsg: ChatMessage = {
      ...message,
      id: `msg_${Date.now()}`,
      timestamp: new Date().toISOString(),
    };
    this.data.conversations[campaignId].push(fullMsg);
    this.save();
    return fullMsg;
  }

  clearChat(campaignId: string) {
    this.data.conversations[campaignId] = [];
    this.save();
  }

  // Workflows
  getWorkflow(campaignId: string): WorkflowRun | undefined {
    return this.data.workflows[campaignId];
  }

  saveWorkflow(workflow: WorkflowRun) {
    this.data.workflows[workflow.campaignId] = workflow;
    this.save();
  }

  // Analytics
  getAnalytics(): AnalyticsSummary {
    const campaigns = this.data.campaigns;
    const tasks = this.data.tasks;
    const content = this.data.content;
    const evals = this.data.evaluations;

    const activeCampaigns = campaigns.filter(c => c.status === 'in_progress' || c.status === 'planning' || c.status === 'review').length;
    const completedCampaigns = campaigns.filter(c => c.status === 'completed').length;
    const totalTasks = tasks.length;
    const tasksCompleted = tasks.filter(t => t.status === 'done').length;
    const contentGenerated = content.length;
    const contentApproved = content.filter(c => c.status === 'approved').length;
    const avgAiQualityScore = evals.length > 0 
      ? Math.round(evals.reduce((sum, e) => sum + e.overallScore, 0) / evals.length) 
      : 90;

    const channelMap: Record<string, number> = {};
    for (const c of campaigns) {
      channelMap[c.primaryChannel] = (channelMap[c.primaryChannel] || 0) + 1;
      for (const sc of c.secondaryChannels) {
        channelMap[sc] = (channelMap[sc] || 0) + 1;
      }
    }
    const channelBreakdown = Object.entries(channelMap).map(([channel, count]) => ({ channel, count }));

    const goalMap: Record<string, number> = {};
    for (const c of campaigns) {
      goalMap[c.goal] = (goalMap[c.goal] || 0) + 1;
    }
    const goalBreakdown = Object.entries(goalMap).map(([goal, count]) => ({ goal, count }));

    return {
      activeCampaigns,
      completedCampaigns,
      totalTasks,
      tasksCompleted,
      contentGenerated,
      contentApproved,
      avgAiQualityScore,
      workflowSuccessRate: 98.4,
      channelBreakdown,
      goalBreakdown,
    };
  }

  // Admin Evaluation Test Cases
  getTestCases(): EvaluationTestCase[] {
    return this.data.testCases;
  }

  addTestCase(test: Omit<EvaluationTestCase, 'id' | 'timestamp'>): EvaluationTestCase {
    const newTest: EvaluationTestCase = {
      ...test,
      id: `test_${Date.now()}`,
      timestamp: new Date().toISOString(),
    };
    this.data.testCases.unshift(newTest);
    this.save();
    return newTest;
  }
}

export const db = new Database();
